<?php


/*
* $Id: ht_mm_menu.php
* $Loc: /includes/modules/header_tags/
*
* Name: zipurMenuMasterLite
* Version: 1.2.0
* Release Date: 01/08/2022
* Author: Preston Lord
* 	 phoenixaddons.com / @zipurman / plord@inetx.ca
*
* License: Commercial License
* 
* Cannot be distributed
*  
* Commercial use allowed
*  
* Cannot modify source-code for any purpose (cannot create derivative works)
*
* Comments: Copyright (c) 2021: Preston Lord - @zipurman - Intricate Networks Inc.
* 
* All rights reserved.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
* (Packaged with Zipur Bundler v2.0.2)
*/





  class ht_mm_menu extends abstract_module {

    const CONFIG_KEY_BASE = 'MODULE_HEADER_TAGS_MM_MENU_';

    protected $group = 'header_tags';

    function execute() {
      global $oscTemplate, $product_info;

        spl_autoload_register( [ $this, 'zipur_mm_autoloader' ] );

        $mmDraw = new menuMasterDraw();
        $mmDraw->css_only = 1;
        $mmDraw->loadJSON();

        if (!empty($mmDraw->menus->menus)) {
            foreach ( $mmDraw->menus->menus as $menu ) {
                $style  = '<link rel="stylesheet" href="' . HTTP_SERVER . DIR_WS_CATALOG . 'includes/apps/menu_master/css/mm-cached-' . $menu->menu_id . '.css" />' . PHP_EOL;
                $blocks = $oscTemplate->getBlocks( 'header_tags' );
                if ( strpos( $blocks, $style ) === false ) {
                    $oscTemplate->addBlock( $style, 'header_tags' );
                }
            }
        }

    }

      /**
       * @param $class
       */
      private function zipur_mm_autoloader( $class ) {

          $path = DIR_FS_CATALOG . 'includes/apps/menu_master/classes/';
          if ( substr( $class, 0, 10 ) == 'menuMaster' ) {
              $file = $path . $class . '.php';
              if ( file_exists( $file ) ) {
                  include $file;
              }
          }

      }


    protected function get_parameters() {
      return [
        'MODULE_HEADER_TAGS_MM_MENU_STATUS' => [
          'title' => 'Enable Menu Master Module',
          'value' => 'True',
          'desc' => 'Do you want to allow Menu Master tags to be added to the page header This is required for all menus to work?',
          'set_func' => "tep_cfg_select_option(['True', 'False'], ",
        ],
        'MODULE_HEADER_TAGS_MM_MENU_SORT_ORDER' => [
          'title' => 'Sort Order',
          'value' => '990',
          'desc' => 'Sort order of display. Lowest is displayed first.',
        ],
      ];
    }

  }
