<?php
    

/*
* $Id: nb_mm_menu.php
* $Loc: /includes/modules/navbar/
*
* Name: zipurMenuMasterLite
* Version: 1.2.0
* Release Date: 01/08/2022
* Author: Preston Lord
* 	 phoenixaddons.com / @zipurman / plord@inetx.ca
*
* License: Commercial License
* 
* Cannot be distributed
*  
* Commercial use allowed
*  
* Cannot modify source-code for any purpose (cannot create derivative works)
*
* Comments: Copyright (c) 2021: Preston Lord - @zipurman - Intricate Networks Inc.
* 
* All rights reserved.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
* (Packaged with Zipur Bundler v2.0.2)
*/





    /**
     * Class nb_mm_menu
     */
    class nb_mm_menu extends abstract_block_module {

        const CONFIG_KEY_BASE = 'MODULE_NAVBAR_MM_MENU_';

        public $group = 'navbar_modules_left';

        function getOutput() {

            spl_autoload_register( [ $this, 'zipur_mm_autoloader' ] );
            $tpl_data = [ 'group' => $this->group, 'file' => __FILE__ ];
            include 'includes/modules/block_template.php';
        }

        /**
         * @param $class
         */
        private function zipur_mm_autoloader( $class ) {

            $path = DIR_FS_CATALOG . 'includes/apps/menu_master/classes/';
            if ( substr( $class, 0, 10 ) == 'menuMaster' ) {
                $file = $path . $class . '.php';
                if ( file_exists( $file ) ) {
                    include $file;
                }
            }

        }

        /**
         * @return string[][]
         */
        public function get_parameters() {

            return [
                'MODULE_NAVBAR_MM_MENU_STATUS'            => [
                    'title'    => 'Enable Module',
                    'value'    => 'True',
                    'desc'     => 'Do you want to add the module to your Navbar?',
                    'set_func' => "tep_cfg_select_option(['True', 'False'], ",
                ],
                'MODULE_NAVBAR_MM_MENU_CONTENT_PLACEMENT' => [
                    'title'    => 'Content Placement Group',
                    'value'    => 'Left',
                    'desc'     => 'This is a special module that must be placed in the Home Group.  Lowest is loaded first, per Group.',
                    'set_func' => "tep_cfg_select_option(['Left', 'Center', 'Right'], ",
                ],
                'MODULE_NAVBAR_MM_MENU_SORT_ORDER'        => [
                    'title' => 'Sort Order',
                    'value' => '800',
                    'desc'  => 'Sort order of display. Lowest is displayed first.',
                ],
            ];
        }

    }
