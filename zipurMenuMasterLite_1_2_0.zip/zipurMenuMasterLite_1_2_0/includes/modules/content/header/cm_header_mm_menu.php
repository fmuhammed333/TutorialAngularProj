<?php
    

/*
* $Id: cm_header_mm_menu.php
* $Loc: /includes/modules/content/header/
*
* Name: zipurMenuMasterLite
* Version: 1.2.0
* Release Date: 01/08/2022
* Author: Preston Lord
* 	 phoenixaddons.com / @zipurman / plord@inetx.ca
*
* License: Commercial License
* 
* Cannot be distributed
*  
* Commercial use allowed
*  
* Cannot modify source-code for any purpose (cannot create derivative works)
*
* Comments: Copyright (c) 2021: Preston Lord - @zipurman - Intricate Networks Inc.
* 
* All rights reserved.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
* (Packaged with Zipur Bundler v2.0.2)
*/





    /**
     * Class cm_header_mm_menu
     */
    class cm_header_mm_menu extends abstract_executable_module {

        const CONFIG_KEY_BASE = 'MODULE_CONTENT_HEADER_MM_MENU_';

        public function __construct() {

            parent::__construct( __FILE__ );
        }

        public function execute() {

            spl_autoload_register( [ $this, 'zipur_mm_autoloader' ] );
            $tpl_data = [ 'group' => $this->group, 'file' => __FILE__ ];
            include 'includes/modules/content/cm_template.php';

        }

        /**
         * @param $class
         */
        private function zipur_mm_autoloader( $class ) {

            $path = DIR_FS_CATALOG . 'includes/apps/menu_master/classes/';
            if ( substr( $class, 0, 10 ) == 'menuMaster' ) {
                $file = $path . $class . '.php';
                if ( file_exists( $file ) ) {
                    include $file;
                }
            }

        }

        protected function get_parameters() {

            return [
                'MODULE_CONTENT_HEADER_MM_MENU_STATUS'        => [
                    'title'    => 'Enable Header Menu Master Module',
                    'value'    => 'True',
                    'desc'     => 'Do you want to enable the Menu Master content module?',
                    'set_func' => "tep_cfg_select_option(['True', 'False'], ",
                ],
                'MODULE_CONTENT_HEADER_MM_MENU_CONTENT_WIDTH' => [
                    'title'    => 'Content Width',
                    'value'    => '12',
                    'desc'     => 'What width container should the content be shown in?',
                    'set_func' => "tep_cfg_select_option(['12', '11', '10', '9', '8', '7', '6', '5', '4', '3', '2', '1'], ",
                ],
                'MODULE_CONTENT_HEADER_MM_MENU_SORT_ORDER'    => [
                    'title' => 'Sort Order',
                    'value' => '5',
                    'desc'  => 'Sort order of display. Lowest is displayed first.',
                ],
            ];
        }

    }

