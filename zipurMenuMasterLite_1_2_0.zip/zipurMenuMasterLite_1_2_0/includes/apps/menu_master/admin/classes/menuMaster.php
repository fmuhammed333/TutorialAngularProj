<?php

    

/*
* $Id: menuMaster.php
* $Loc: /includes/apps/menu_master/admin/classes/
*
* Name: zipurMenuMasterLite
* Version: 1.2.0
* Release Date: 01/08/2022
* Author: Preston Lord
* 	 phoenixaddons.com / @zipurman / plord@inetx.ca
*
* License: Commercial License
* 
* Cannot be distributed
*  
* Commercial use allowed
*  
* Cannot modify source-code for any purpose (cannot create derivative works)
*
* Comments: Copyright (c) 2021: Preston Lord - @zipurman - Intricate Networks Inc.
* 
* All rights reserved.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
* (Packaged with Zipur Bundler v2.0.2)
*/




    class menuMaster {

        public $menus = null;
        public $menu = null;
        public $special_items = null;
        public $phoenix_pages = null;
        public $menu_locations = null;
        public $locations = [];
        public $used_locations = [];
        public $settings = [];
        public $languages = [];
        public $menu_lang = [];
        public $menuitem_lang = [];
        public $categories = [];
        public $products = [];
        public $json = [];
        public $publishyn = 0;
        public $importing = 0;

        public function __construct() {

            $this->menu = [
                'menu_id'   => 0,
                'menu_name' => '',
            ];

            $this->phoenix_pages  = $this->getPhoenixPages();
            $this->special_items  = $this->getSpecialItems();
            $this->menu_locations = $this->getMenuLocations();
            $this->languages      = tep_get_languages();
            $this->getSettings();

        }

        /**
         *
         */
        public function loadDefaultData() {

            $this->menu['menu_class']     = '';
            $this->menu['menu_status']    = 1;
            $this->menu['show_on_mobile'] = 1;
            $this->menu['sort_order']     = 0;
            $this->menu['menu_sticky']    = 0;
            $this->menu['menu_fill']      = 0;
            $this->menu['menu_align']     = 'left';
            $this->menu['color_type']     = 0;
            $this->menu['menu_style']     = '';

            $this->menu['menu_bar_bg_color']      = '#e9ecef';
            $this->menu['menu_bar_border_color']  = '#f5f5f5';
            $this->menu['menu_bar_padding']       = '2px 2px 2px 2px';
            $this->menu['menu_bar_margin']        = '2px 2px 2px 2px';
            $this->menu['menu_bar_border_radius'] = '0px 0px 0px 0px';
            $this->menu['border_radius']          = '0px 0px 0px 0px';
            $this->menu['menu_bar_border_width']  = '1px 1px 1px 1px';

            $this->menu['link_color'] = '#007bff';
            $this->menu['link_hover'] = '#024995';

            $this->menu['bg_color'] = '#e9ecef';
            $this->menu['bg_hover'] = '#f5f5f5';

            $this->menu['border_color'] = '#f5f5f5';
            $this->menu['border_hover'] = '#e9ecef';

            $this->menu['border_width'] = '1px 1px 1px 1px';
            $this->menu['padding']      = '2px 2px 2px 2px';
            $this->menu['margin']       = '2px 2px 2px 2px';

            $this->menu['child_link_color']    = '#eeeeee';
            $this->menu['child_link_hover']    = '#dddddd';
            $this->menu['child_bg_color']      = '#333333';
            $this->menu['child_bg_hover']      = '#666666';
            $this->menu['child_border_color']  = '#222222';
            $this->menu['child_border_hover']  = '#444444';
            $this->menu['child_border_width']  = '1px 1px 1px 1px';
            $this->menu['child_padding']       = '2px 2px 2px 2px';
            $this->menu['child_margin']        = '2px 0px 0px 0px';
            $this->menu['child_border_radius'] = '0px 0px 0px 0px';

        }

        public function getMenus() {

            $menu_query = tep_db_query( "SELECT * FROM menu_master ORDER BY sort_order, menu_name" );

            $this->menus = [];
            while ( $result = tep_db_fetch_array( $menu_query ) ) {
                $this->menus[ $result['menu_id'] ] = $result;
            }

        }

        /**
         * @param $mm_id
         */
        public function loadMenu( $mm_id ) {

            $query      = tep_db_query( "SELECT * FROM menu_master WHERE menu_id=$mm_id" );
            $this->menu = tep_db_fetch_array( $query );

            $this->menu_lang = [];
            $query           = tep_db_query( "SELECT * FROM menu_master_language WHERE menu_id=$mm_id" );
            while ( $result = tep_db_fetch_array( $query ) ) {
                $this->menu_lang[ $result['language_id'] ] = $result;
            }

            $this->loadLocations();

        }

        /**
         * @param $mm_name
         */
        public function newMenu( $mm_name ) {

            if ( ! empty( $mm_name ) ) {

                tep_db_query( "INSERT INTO menu_master (menu_name) VALUES ('$mm_name')" );

                $query      = tep_db_query( "SELECT * FROM menu_master ORDER BY menu_id DESC LIMIT 1" );
                $this->menu = tep_db_fetch_array( $query );

            }

        }

        /**
         * @param $menuid
         */
        public function deleteMenu( $menuid ) {

            tep_db_query( "DELETE FROM menu_master WHERE menu_id=$menuid AND menu_id={$this->menu['menu_id']}" );
            tep_db_query( "DELETE FROM menu_master_items WHERE menu_id=$menuid AND menu_id={$this->menu['menu_id']}" );
            tep_db_query( "DELETE FROM menu_master_to_location WHERE menu_id=$menuid AND menu_id={$this->menu['menu_id']}" );

            $query      = tep_db_query( "SELECT * FROM menu_master ORDER BY menu_id LIMIT 1" );
            $this->menu = tep_db_fetch_array( $query );
            if ( ! empty( $this->menu ) ) {
                $this->loadMenu( $this->menu['menu_id'] );
                $this->generateJSON();
            }

        }

        /**
         * @param $mm_name
         */
        public function dupeMenu( $mm_name ) {
            //requires upgrade
        }

        public function saveMenu() {

            if ( empty( $this->importing ) ) {
                tep_db_query( "DELETE FROM menu_master_language WHERE menu_id={$this->menu['menu_id']}" );

                foreach ( $this->languages as $language ) {
                    $this->menu[ 'label_text_' . $language['code'] ] = addslashes( $this->menu[ 'label_text_' . $language['code'] ] );
                    tep_db_query( "INSERT INTO menu_master_language (menu_id, language_id, label_text) VALUES ({$this->menu['menu_id']}, {$language['id']}, '{$this->menu['label_text_' . $language['code']]}')" );
                }
            }

            //support for older backups
            if ( empty( $this->menu['menu_icon_close'] ) ) {
                $this->menu['menu_icon_close'] = 'fa-plus';
            }
            if ( empty( $this->menu['menu_icon_open'] ) ) {
                $this->menu['menu_icon_open'] = 'fa-minus';
            }
            if ( empty( $this->menu['hamburger_code'] ) ) {
                $this->menu['hamburger_code'] = '<i class=&quot;fas fa-bars&quot;></i>';
            }

            $this->menu['customcss'] = addslashes( $this->menu['customcss'] );

            tep_db_query( "UPDATE menu_master SET 
                       
                       menu_name='{$this->menu['menu_name']}',
                       menu_class='{$this->menu['menu_class']}',
                       menu_status={$this->menu['menu_status']},
                       show_on_mobile={$this->menu['show_on_mobile']},
                       menu_sticky=0,
                       sort_order={$this->menu['sort_order']},
                       menu_fill={$this->menu['menu_fill']},
                       menu_align='{$this->menu['menu_align']}',
                       color_type={$this->menu['color_type']},
                       menu_style='{$this->menu['menu_style']}',
                       menu_bar_bg_color='{$this->menu['menu_bar_bg_color']}',
                       menu_bar_border_color='{$this->menu['menu_bar_border_color']}',
                       menu_bar_padding='{$this->menu['menu_bar_padding']}',
                       menu_bar_margin='{$this->menu['menu_bar_margin']}',
                       menu_bar_border_radius='{$this->menu['menu_bar_border_radius']}',
                       border_radius='{$this->menu['border_radius']}',
                       menu_bar_border_width='{$this->menu['menu_bar_border_width']}',
                       link_color='{$this->menu['link_color']}',
                       link_hover='{$this->menu['link_hover']}',
                       bg_color='{$this->menu['bg_color']}',
                       bg_hover='{$this->menu['bg_hover']}',
                       border_color='{$this->menu['border_color']}',
                       border_hover='{$this->menu['border_hover']}',
                       border_width='{$this->menu['border_width']}',
                       padding='{$this->menu['padding']}',
                       margin='{$this->menu['margin']}',
                       child_link_color='{$this->menu['child_link_color']}',
                       child_link_hover='{$this->menu['child_link_hover']}',
                       child_bg_color='{$this->menu['child_bg_color']}',
                       child_bg_hover='{$this->menu['child_bg_hover']}',
                       child_border_color='{$this->menu['child_border_color']}',
                       child_border_hover='{$this->menu['child_border_hover']}',
                       child_border_width='{$this->menu['child_border_width']}',
                       child_padding='{$this->menu['child_padding']}',
                       child_margin='{$this->menu['child_margin']}',
                       menu_font='{$this->menu['menu_font']}',
                       menu_font_size='{$this->menu['menu_font_size']}',
                       child_menu_font='{$this->menu['child_menu_font']}',
                       child_font_size='{$this->menu['child_font_size']}',
                       child_border_radius='{$this->menu['child_border_radius']}',
                       hamburger_color='{$this->menu['hamburger_color']}',
                       hamburger_bg_color='{$this->menu['hamburger_bg_color']}',
                       hamburger_placement='{$this->menu['hamburger_placement']}',
                       hamburger_breakpoint='{$this->menu['hamburger_breakpoint']}',
                       menu_icon_close='{$this->menu['menu_icon_close']}',
                       menu_icon_open='{$this->menu['menu_icon_open']}',
                       customcss='{$this->menu['customcss']}',
                       hamburger_code='{$this->menu['hamburger_code']}'
                       
                       WHERE menu_id={$this->menu['menu_id']}" );

            //reload data to make sure loading saved data
            $this->loadMenu( $this->menu['menu_id'] );
            $this->generateJSON();
        }

        /**
         * @return array
         */
        public function loadDeafaultItem() {

            return [
                'id'                   => 0,
                'menu_id'              => $this->menu['menu_id'],
                'menu_item_id'         => 0,
                'pages_id'             => 0,
                'phoenix_pages_id'     => 0,
                'special_items_id'     => 0,
                'categories_id'        => 0,
                'products_id'          => 0,
                'item_align'           => 'left',
                'item_valign'          => 'middle',
                'parent_uuid'          => '',
                'sort_order'           => 0,
                'menu_levels'          => 0,
                'item_url'             => '',
                'item_target'          => '_self',
                'item_class'           => '',
                'item_status'          => 1,
                'restrict_basket'      => 0,
                'restrict_loggedin'    => 0,
                'link_color'           => '',
                'link_hover'           => '',
                'bg_color'             => '',
                'bg_hover'             => '',
                'show_on_mobile'       => 1,
                'item_image'           => 0,
                'item_breakpoint_hide' => 'smmdlgxl',
                'fa_icon'              => '',
                'item_icon_show'       => 0,
                'mega_menu'            => 0,
                'uuid'                 => '',
            ];
        }

        /**
         * @param $data
         */
        public function saveItems( $data ) {

            if ( ! empty( $data ) && ! empty( $data->items ) && ! empty( $this->menu['menu_id'] ) ) {

                tep_db_query( "DELETE FROM menu_master_items WHERE menu_id={$this->menu['menu_id']}" );
                tep_db_query( "DELETE FROM menu_master_items_language WHERE menu_id={$this->menu['menu_id']}" );

                $this->menus['saved_sub_menus'] = [];
                $sort_order                     = 0;

                foreach ( $data->items as $itemlist ) {
                    foreach ( $itemlist->items as $item ) {

                        $i = $this->loadDeafaultItem();

                        if ( $item->type == '1' ) {
                            //Info Pages
                            $i['pages_id'] = $item->id;
                        } else if ( $item->type == '2' ) {
                            //Categories
                            $i['categories_id'] = $item->id;
                        } else if ( $item->type == '3' ) {
                            //Products
                            $i['products_id'] = $item->id;
                        } else if ( $item->type == '4' ) {
                            //Custom Links

                        } else if ( $item->type == '5' ) {
                            //Phoenix Pages
                            $i['phoenix_pages_id'] = $item->id;
                        } else if ( $item->type == '6' ) {
                            //Special Items
                            $i['special_items_id'] = $item->id;
                        }

                        $i['uuid']           = $item->uuid;
                        $i['item_url']       = $item->link;
                        $i['menu_levels']    = 1;
                        $i['sort_order']     = $sort_order;
                        $i['parent_uuid']    = $item->parent;
                        $i['item_class']     = '';
                        $i['item_align']     = $item->align;
                        $i['item_valign']    = $item->valign;
                        $i['fa_icon']        = '';
                        $i['item_icon_show'] = 0;
                        $i['link_color']     = '';
                        $i['link_hover']     = '';
                        $i['bg_color']       = '';
                        $i['bg_hover']       = '';
                        $i['item_image']     = '';

                        $i['item_breakpoint_hide'] = '';

                        $i['item_target']       = ( ! $item->target ) ? '_self' : '_blank';
                        $i['item_status']       = ( ! $item->status ) ? 0 : 1;
                        $i['show_on_mobile']    = ( ! $item->mobile ) ? 0 : 1;
                        $i['mega_menu']         = 0;
                        $i['restrict_loggedin'] = 0;
                        $i['restrict_basket']   = 0;

                        $this->menus['saved_sub_menus']["$item->parent"] = 1;

                        tep_db_query( "INSERT INTO menu_master_items
                            (menu_id, pages_id, categories_id, products_id, item_align, item_valign, parent_uuid, sort_order, item_url, item_target, item_class, item_status, link_color, link_hover, bg_color, bg_hover, show_on_mobile, item_image, item_breakpoint_hide, fa_icon, item_icon_show, mega_menu, uuid, phoenix_pages_id, special_items_id, restrict_loggedin, restrict_basket, menu_levels)
                            VALUES
                            ({$i['menu_id']}, {$i['pages_id']}, {$i['categories_id']}, {$i['products_id']}, '{$i['item_align']}','{$i['item_valign']}', '{$i['parent_uuid']}', {$i['sort_order']}, '{$i['item_url']}', '{$i['item_target']}',  '{$i['item_class']}', {$i['item_status']}, '{$i['link_color']}', '{$i['link_hover']}', '{$i['bg_color']}', '{$i['bg_hover']}', {$i['show_on_mobile']}, '{$i['item_image']}',  '{$i['item_breakpoint_hide']}',  '{$i['fa_icon']}',  {$i['item_icon_show']}, {$i['mega_menu']}, '{$i['uuid']}', {$i['phoenix_pages_id']}, {$i['special_items_id']}, {$i['restrict_loggedin']}, {$i['restrict_basket']}, {$i['menu_levels']})
                            " );

                        $query     = tep_db_query( "SELECT menu_item_id FROM menu_master_items WHERE uuid='{$i['uuid']}'" );
                        $this_item = tep_db_fetch_array( $query );

                        foreach ( $this->languages as $language ) {
                            $lland                                 = 'name_' . $language['code'];
                            $lland                                 = $item->$lland;
                            $i[ 'item_name_' . $language['code'] ] = $lland;
                            tep_db_query( "INSERT INTO menu_master_items_language (menu_id, menu_item_id, language_id, item_name) VALUES ({$this->menu['menu_id']}, {$this_item['menu_item_id']}, {$language['id']}, '$lland')" );
                        }

                        $sort_order ++;
                    }
                }

                foreach ( $this->menus['saved_sub_menus'] as $key => $saved_sub_menu ) {
                    tep_db_query( "UPDATE menu_master_items SET menu_has_children=1 WHERE uuid = ('$key');" );
                }

            }
            $this->generateJSON();
        }

        /**
         * @param $parent
         */
        public function drawItems( $parent ) {

            if ( ! empty( $this->menu['menu_id'] ) ) {

                $this->loadItemLanguages();

                if ( zipCheckDBTableExists( 'pages' ) ) {
                    $menu_query = tep_db_query( "SELECT 
                           *, 
                        pd.navbar_title,
                        prodd.products_name,
                        cd.categories_name,
                        mmil.item_name
                    FROM 
                         menu_master_items mmi
                            LEFT JOIN pages_description pd ON pd.pages_id = mmi.pages_id AND pd.languages_id={$_SESSION['languages_id']}
                            LEFT JOIN products_description prodd ON prodd.products_id = mmi.products_id AND prodd.language_id={$_SESSION['languages_id']}
                            LEFT JOIN categories_description cd ON cd.categories_id = mmi.categories_id AND cd.language_id={$_SESSION['languages_id']}
                            LEFT JOIN menu_master_items_language mmil ON mmil.menu_item_id = mmi.menu_item_id AND mmil.language_id={$_SESSION['languages_id']}
               
                    WHERE 
                          mmi.menu_id={$this->menu['menu_id']} AND 
                          mmi.parent_uuid='$parent' 
                    ORDER BY sort_order" );
                } else {
                    $menu_query = tep_db_query( "SELECT 
                           *, 
                        '' AS navbar_title,
                        prodd.products_name,
                        cd.categories_name,
                        mmil.item_name
                    FROM 
                         menu_master_items mmi
                            LEFT JOIN products_description prodd ON prodd.products_id = mmi.products_id AND prodd.language_id={$_SESSION['languages_id']}
                            LEFT JOIN categories_description cd ON cd.categories_id = mmi.categories_id AND cd.language_id={$_SESSION['languages_id']}
                            LEFT JOIN menu_master_items_language mmil ON mmil.menu_item_id = mmi.menu_item_id AND mmil.language_id={$_SESSION['languages_id']}
               
                    WHERE 
                          mmi.menu_id={$this->menu['menu_id']} AND 
                          mmi.parent_uuid='$parent' 
                    ORDER BY sort_order" );
                }
                $has_items = 0;
                while ( $item = tep_db_fetch_array( $menu_query ) ) {

                    $has_items = 1;

                    $data = [
                        'type'                 => 0,
                        'menu_item_id'         => $item['menu_item_id'],
                        'pages_id'             => $item['pages_id'],
                        'phoenix_pages_id'     => $item['phoenix_pages_id'],
                        'special_items_id'     => $item['special_items_id'],
                        'products_id'          => $item['products_id'],
                        'categories_id'        => $item['categories_id'],
                        'name'                 => $item['item_name'],
                        'item_url'             => $item['item_url'],
                        'menu_levels'          => $item['menu_levels'],
                        'item_target'          => $item['item_target'],
                        'item_class'           => $item['item_class'],
                        'item_status'          => $item['item_status'],
                        'restrict_basket'      => $item['restrict_basket'],
                        'restrict_loggedin'    => $item['restrict_loggedin'],
                        'item_align'           => $item['item_align'],
                        'item_valign'          => $item['item_valign'],
                        'fa_icon'              => $item['fa_icon'],
                        'item_icon_show'       => $item['item_icon_show'],
                        'mega_menu'            => 0,
                        'link_color'           => $item['link_color'],
                        'link_hover'           => $item['link_hover'],
                        'bg_color'             => $item['bg_color'],
                        'bg_hover'             => $item['bg_hover'],
                        'item_image'           => $item['item_image'],
                        'item_breakpoint_hide' => $item['item_breakpoint_hide'],
                        'show_on_mobile'       => $item['show_on_mobile'],
                        'navbar_title'         => $item['navbar_title'],
                        'products_name'        => $item['products_name'],
                        'categories_name'      => $item['categories_name'],
                        'phoenix_pages_name'   => $this->phoenix_pages[ $item['phoenix_pages_id'] ]['name'],
                        'specials_name'        => '',

                    ];

                    if ( ! empty( $item['pages_id'] ) ) {
                        $data['type'] = 1;
                    } else if ( ! empty( $item['categories_id'] ) ) {
                        $data['type'] = 2;
                    } else if ( ! empty( $item['products_id'] ) ) {
                        $data['type'] = 3;
                    } else if ( ! empty( $item['phoenix_pages_id'] ) ) {
                        $data['type'] = 5;
                    } else if ( ! empty( $item['special_items_id'] ) ) {
                        $data['type'] = 6;
                    } else {
                        $data['type'] = 4;
                    }

                    $this->addItem( $data, $item['uuid'], $item['menu_has_children'] );

                }

                if ( empty( $has_items ) ) {
                    ?>
                    <div class="p-4 m-4 border round bg-success text-light mm-empty-menu-message rounded">
                        <?= sprintf( MM_EMPTY_MENU, $this->menu['menu_name'] ) ?>
                    </div>
                    <?php
                }

            }
        }

        /**
         * @param        $data
         * @param string $uuid
         * @param int    $menu_has_children
         */
        public function addItem( $data, $uuid = '', $menu_has_children = 0 ) {

            $url    = [
                'type'      => 'text',
                'smalltext' => '',
            ];
            $levels = [
                'type'      => 'hidden',
                'smalltext' => '',
            ];

            $pagemark         = '';
            $placeholder_name = MM_MENU_ITEM_TEXT;
            $item_bar_title   = $data['name'];
            $hide_me          = [
                'text'   => '',
                'target' => '',
                'cart'   => '',
                'align'  => '',
                'link'   => '',
                'icon'   => '',
            ];

            if ( $data['type'] == 1 ) {
                //Info Pages
                if ( empty( $data['id'] ) ) {
                    $data['id'] = $data['pages_id'];
                }
                $identifier       = 'infopage' . $data['id'] . '-' . substr( str_shuffle( str_repeat( "0123456789abcdefghijklmnopqrstuvwxyz", 5 ) ), 0, 5 );
                $url['type']      = 'hidden';
                $url['smalltext'] = '(' . MM_MENU_ITEM_INFO_PAGE_LINKED . ') ';
                if ( ! empty( $data['navbar_title'] ) ) {
                    $url['smalltext'] .= '<span class="text-primary">' . $data['navbar_title'] . '</span>';
                    $placeholder_name = $data['navbar_title'];
                    $item_bar_title   = empty( $item_bar_title ) ? $placeholder_name : $data['name'];
                }
                $pagemark = MM_MENU_ITEM_INFO_PAGE;
            } else if ( $data['type'] == 2 ) {
                //Categories
                if ( empty( $data['id'] ) ) {
                    $data['id'] = $data['categories_id'];
                }
                $identifier       = 'category' . $data['id'] . '-' . substr( str_shuffle( str_repeat( "0123456789abcdefghijklmnopqrstuvwxyz", 5 ) ), 0, 5 );
                $levels['type']   = 'number';
                $url['type']      = 'hidden';
                $url['smalltext'] = '(' . MM_MENU_ITEM_CATEGORY_LINKED . ') ';
                if ( ! empty( $data['categories_name'] ) ) {
                    $url['smalltext'] .= '<span class="text-primary">' . $data['categories_name'] . '</span>';
                    $placeholder_name = $data['categories_name'];
                    $item_bar_title   = empty( $item_bar_title ) ? $placeholder_name : $data['name'];
                }
                $pagemark = MM_MENU_ITEM_CATEGORY;
            } else if ( $data['type'] == 3 ) {
                //Products
                if ( empty( $data['id'] ) ) {
                    $data['id'] = $data['products_id'];
                }
                $identifier       = 'product' . $data['id'] . '-' . substr( str_shuffle( str_repeat( "0123456789abcdefghijklmnopqrstuvwxyz", 5 ) ), 0, 5 );
                $url['type']      = 'hidden';
                $url['smalltext'] = '(' . MM_MENU_ITEM_PRODUCT_LINKED . ') ';
                if ( ! empty( $data['products_name'] ) ) {
                    $url['smalltext'] .= '<span class="text-primary">' . $data['products_name'] . '</span>';
                    $placeholder_name = $data['products_name'];
                    $item_bar_title   = empty( $item_bar_title ) ? $placeholder_name : $data['name'];
                }
                $pagemark = MM_MENU_ITEM_PRODUCT;
            } else if ( $data['type'] == 4 ) {
                //Custom Link
                $identifier = 'custom' . '-' . substr( str_shuffle( str_repeat( "0123456789abcdefghijklmnopqrstuvwxyz", 9 ) ), 0, 9 );
                $pagemark   = MM_MENU_ITEM_CUSTOM;
            } else if ( $data['type'] == 5 ) {
                //Phoenix Pages
                if ( empty( $data['id'] ) ) {
                    $data['id'] = $data['phoenix_pages_id'];
                }
                $identifier       = 'phoenix' . $data['id'] . '-' . substr( str_shuffle( str_repeat( "0123456789abcdefghijklmnopqrstuvwxyz", 5 ) ), 0, 5 );
                $url['type']      = 'hidden';
                $url['smalltext'] = '(' . MM_MENU_ITEM_PHOENIX_PAGE_LINKED . ') ';
                if ( ! empty( $data['phoenix_pages_name'] ) ) {
                    $url['smalltext'] .= '<span class="text-primary">' . $data['phoenix_pages_name'] . '</span>';
                    $placeholder_name = $data['phoenix_pages_name'];
                    $item_bar_title   = empty( $item_bar_title ) ? $placeholder_name : $data['name'];
                }
                $pagemark = MM_MENU_ITEM_PHOENIX_PAGE;
            } else if ( $data['type'] == 6 ) {
                //Special Items
                if ( empty( $data['id'] ) ) {
                    $data['id'] = $data['special_items_id'];
                }
                $hide_me['target'] = 'mm-hidden-item';
                $hide_me['link']   = 'mm-hidden-item';
                $hide_me['icon']   = 'mm-hidden-item';
                if ( $data['id'] != 2 ) {
                    $hide_me['text'] = 'mm-hidden-item';
                }
                $identifier       = 'special' . $data['id'] . '-' . substr( str_shuffle( str_repeat( "0123456789abcdefghijklmnopqrstuvwxyz", 5 ) ), 0, 5 );
                $url['type']      = 'hidden';
                $url['smalltext'] = '(' . MM_MENU_ITEM_SPECIAL_ITEM_LINKED . ') ';
                if ( ! empty( $data['specials_name'] ) ) {
                    $url['smalltext'] .= '<span class="text-primary">' . $data['specials_name'] . '</span>';
                    $placeholder_name = $data['specials_name'];
                    $item_bar_title   = empty( $item_bar_title ) ? $placeholder_name : $data['name'];

                }
                $pagemark = MM_MENU_ITEM_SPECIAL_ITEM;
            }

            if ( empty( $uuid ) ) {
                $uuid = uniqid( $this->menu['menu_id'] . '-' . $data['type'] . '-' );
            }

            $extra_title_class = ( empty( $data['item_status'] ) ) ? 'text-danger' : '';

            $extra_title_icons = ( empty( $data['show_on_mobile'] ) ) ? '<i class="fas fa-mobile-alt text-danger"></i>' : '';

            if ( $data['restrict_loggedin'] == 1 || $data['restrict_loggedin'] == 3 ) {
                $extra_title_icons .= '<i class="fas fa-key text-danger"></i>';
            }
            if ( $data['restrict_loggedin'] == 2 || $data['restrict_loggedin'] == 3 ) {
                $extra_title_icons .= '<i class="fas fa-key text-warning"></i>';
            }


            $extra_title_icons .= ( ! empty( $data['restrict_basket'] ) ) ? '<i class="fas fa-shopping-cart text-danger"></i>' : '';

            $extra_title_icons .= ! empty( $data['item_image'] ) ? '<i class="fas fa-image text-warning"></i>' : '';

            if ( empty( $data['id'] ) ) {
                $data['id'] = 0;
            }

            ?>
            <li class="card w-100" id="mm_item_card_<?= $identifier ?>" data-uuid="<?= $uuid ?>" data-id="<?= $data['id'] ?>" data-type="<?= $data['type'] ?>">
                <div class="card-header border p-0 mm-item" id="MenuItems<?= $identifier ?>">
                    <h2 class="mb-0">
                        <div class="btn btn-link btn-block text-left collapsed text-secondary" type="button" data-toggle="collapse" aria-expanded="false" aria-controls="menuCollapse<?= $identifier ?>">
                            <i class="fas fa-arrows-alt"></i>
                            <span class="<?= $extra_title_class ?>" id="MenuItemTitle<?= $identifier ?>"><?= $item_bar_title ?><div class="mm-icons"><?= $extra_title_icons ?></div></span>
                            <span class="mm-pagemark float-right mr-4"><?= $pagemark ?></span>
                            <i class="fa fadown collapsed" data-toggle="collapse" data-target="#menuCollapse<?= $identifier ?>"></i>
                        </div>
                    </h2>
                </div>
                <div id="menuCollapse<?= $identifier ?>" class="collapse" aria-labelledby="MenuItems<?= $identifier ?>" data-parent="#MenuItems">
                    <div class="card-body p-3">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-row align-items-center mb-2">
                                    <div class="col-12 m-2 m-md-0">
                                        <div class="input-group <?= $hide_me['text'] ?>">
                                            <label for="mm_item_name<?= $identifier ?>" class="text-muted mr-2"><small><?= MM_MENU_ITEM_FORM_TEXT ?>
                                                    :</small></label>
                                            <input type="text" data-toggle="tooltip" data-placement="bottom" title="<?= MM_MENU_ITEM_FORM_TEXT_TIP ?>" class="mm_item_name mm_item_name_block" id="mm_item_name<?= $identifier ?>" value="<?= $data['name'] ?>" onKeyUp="mm_update_item_title('<?= $identifier ?>');" placeholder="<?= $placeholder_name ?>" data-lang="<?= $_SESSION['languages_id'] ?>"/>

                                            <?php
                                                foreach ( $this->languages as $language ) {

                                                    $val = ! empty( $this->menuitem_lang[ $data['menu_item_id'] . '-' . $language['id'] ] ) ? $this->menuitem_lang[ $data['menu_item_id'] . '-' . $language['id'] ]['item_name'] : '';

                                                    //required for custom link language when first added
                                                    if ( ! empty( $data['name'] ) && empty( $val ) ) {
                                                        $val = $data['name'];
                                                    }

                                                    $iteminputclass = ( $_SESSION['languages_id'] == $language['id'] ) ? 'bg-dark text-light' : 'bg-light text-dark';
                                                    ?>
                                                    <input type="hidden" class="mm_item_name_block_hidden mm_item_name_block_hidden_<?= $identifier . '_' . $language['id'] ?>" id="mm_item_name<?= $identifier ?>_<?= $language['id'] ?>" value="<?= $val ?>" data-lang="<?= $language['code'] ?>"/>

                                                    <div onClick="mm_menu_item_lang_update('<?= $identifier ?>', <?= $language['id'] ?>);" class="input-group-append mm_item_name_block_append mm_item_name_block_append<?= $language['id'] ?>" data-toggle="tooltip" data-placement="right" title="<?= $language['name'] ?>">
                                                        <span class="input-group-text p-0 <?= $iteminputclass ?>" id="basic-addon<?= $identifier ?><?= $language['code'] ?>"><?= ' <small>(' . strtoupper( $language['code'] ) . ')</small>' ?></span>
                                                    </div>
                                                    <?php
                                                }

                                                $al_left   = ( $data['item_align'] == 'left' ) ? 'btn-secondary' : 'bg-light';
                                                $al_center = ( $data['item_align'] == 'center' ) ? 'btn-secondary' : 'bg-light';
                                                $al_right  = ( $data['item_align'] == 'right' ) ? 'btn-secondary' : 'bg-light';

                                                $al_top    = ( $data['item_valign'] == 'top' ) ? 'btn-secondary' : 'bg-light';
                                                $al_middle = ( $data['item_valign'] == 'middle' ) ? 'btn-secondary' : 'bg-light';
                                                $al_bottom = ( $data['item_valign'] == 'bottom' ) ? 'btn-secondary' : 'bg-light';

                                            ?>

                                            <div class="col-auto mt-3 mt-sm-0 mx-auto mx-sm-0">
                                                <div class="btn-group btn-group-sm" role="group" aria-label="Text Align">

                                                    <button id="mm_align_left_<?= $identifier ?>" onClick="mm_align_update('<?= $identifier ?>', 'left');" type="button" class="btn border <?= $al_left ?> mm_align_<?= $identifier ?>" data-toggle="tooltip" data-placement="bottom" title="<?= MM_MENU_ITEM_FORM_ALIGN_LEFT_TIP ?>">
                                                        <i class="fas fa-align-left"></i></button>

                                                    <button id="mm_align_center_<?= $identifier ?>" onClick="mm_align_update('<?= $identifier ?>', 'center');" type="button" class="btn border <?= $al_center ?> mm_align_<?= $identifier ?>" data-toggle="tooltip" data-placement="bottom" title="<?= MM_MENU_ITEM_FORM_ALIGN_CENTER_TIP ?>">
                                                        <i class="fas fa-align-center"></i></button>

                                                    <button id="mm_align_right_<?= $identifier ?>" onClick="mm_align_update('<?= $identifier ?>', 'right');" type="button" class="btn border <?= $al_right ?> mm_align_<?= $identifier ?>" data-toggle="tooltip" data-placement="bottom" title="<?= MM_MENU_ITEM_FORM_ALIGN_RIGHT_TIP ?>">
                                                        <i class="fas fa-align-right"></i></button>

                                                </div>

                                                <div class="btn-group btn-group-sm" style="display: none;">
                                                    <button id="mm_valign_top_<?= $identifier ?>" onClick="mm_valign_update('<?= $identifier ?>', 'top');" type="button" class="btn border <?= $al_top ?> mm_valign_<?= $identifier ?>" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_ITEM_FORM_VALIGN_TOP_TIP ?>">
                                                        <i class="fas fa-grip-lines grip-lines-top"></i></button>

                                                    <button id="mm_valign_middle_<?= $identifier ?>" onClick="mm_valign_update('<?= $identifier ?>', 'middle');" type="button" class="btn border <?= $al_middle ?> mm_valign_<?= $identifier ?>" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_ITEM_FORM_VALIGN_MIDDLE_TIP ?>">
                                                        <i class="fas fa-grip-lines"></i></button>

                                                    <button id="mm_valign_bottom_<?= $identifier ?>" onClick="mm_valign_update('<?= $identifier ?>', 'bottom');" type="button" class="btn border <?= $al_bottom ?> mm_valign_<?= $identifier ?>" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_ITEM_FORM_VALIGN_BOTTOM_TIP ?>">
                                                        <i class="fas fa-grip-lines grip-lines-bottom"></i></button>
                                                </div>


                                            </div>
                                            <input type="hidden" id="mm_item_valign<?= $identifier ?>" class="mm_item_valign" value="<?= $data['item_valign'] ?>"/>
                                            <input type="hidden" id="mm_item_align<?= $identifier ?>" class="mm_item_align" value="<?= $data['item_align'] ?>"/>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-row align-items-center mb-2">
                                    <div class="col-auto  flex-grow-1">
                                        <label for="mm_item_link<?= $identifier ?>" class="text-muted"><small><?= MM_MENU_ITEM_FORM_URL ?>
                                                :</small></label>
                                        <input type="<?= $url['type'] ?>" class="mm_item_link" id="mm_item_link<?= $identifier ?>" value="<?php if ( ! empty( $data['item_url'] ) ) {
                                            echo $data['item_url'];
                                        } ?>"/>
                                        <?php
                                            if ( ! empty( $url['smalltext'] ) ) {
                                                echo '<small>' . $url['smalltext'] . '</small>';
                                            }

                                        ?>
                                    </div>

                                    <div class="col-auto">
                                        <?php

                                            if ( $levels['type'] != 'hidden' ) {
                                                echo '<small>' . MM_MENU_ITEM_FORM_LEVELS . ':</small>';
                                            }
                                        ?>
                                        <input style="width: 50px;min-width: 50px; text-align: center;" maxlength="2" type="<?= $levels['type'] ?>" class="mm_menu_levels" id="mm_menu_levels<?= $identifier ?>" value="<?= $data['menu_levels'] ?>" min="0" max="5"/>
                                        <?php
                                            if ( ! empty( $levels['smalltext'] ) ) {
                                                echo '<small>' . $levels['smalltext'] . '</small>';
                                            }
                                        ?>
                                    </div>


                                </div>

                                <ul class="nav nav-tabs p-0 mb-0">
                                    <li class="nav-item p-0">
                                        <a href="#mm-classes-<?= $identifier ?>" class="nav-link active py-1 px-2" data-toggle="tab"><small><i class="fas fa-file-code text-muted mr-2"></i>
                                                <?= MM_MENU_ITEM_FORM_CLASSES ?></small></a>
                                    </li>
                                    <li class="nav-item p-0">
                                        <a href="#mm-colors-<?= $identifier ?>" class="nav-link py-1 px-2" data-toggle="tab"><small><i class="fas fa-palette text-muted mr-2"></i>
                                                <?= MM_MENU_ITEM_FORM_COLORS ?></small></a>
                                    </li>
                                    <li class="nav-item p-0">
                                        <a href="#mm-image-<?= $identifier ?>" class="nav-link py-1 px-2" data-toggle="tab"><small><i class="fas fa-image text-muted mr-2"></i>
                                                <?= MM_MENU_ITEM_FORM_IMAGE ?></small></a>
                                    </li>
                                    <li class="nav-item p-0">
                                        <a href="#mm-breakpoints-<?= $identifier ?>" class="nav-link py-1 px-2" data-toggle="tab"><small><i class="fas fa-arrows-alt-h text-muted mr-2"></i>
                                                <?= MM_MENU_ITEM_FORM_SCREEN_SIZES ?></small></a>
                                    </li>
                                </ul>
                                <div class="tab-content border p-2 mt-0">
                                    <div class="tab-pane fade show active" id="mm-classes-<?= $identifier ?>">

                                        <?= mm_upgrade_this_pro_box() ?>

                                    </div>
                                    <div class="tab-pane fade" id="mm-colors-<?= $identifier ?>">

                                        <?= mm_upgrade_this_pro_box() ?>

                                    </div>
                                    <div class="tab-pane fade" id="mm-image-<?= $identifier ?>">

                                        <?= mm_upgrade_this_pro_box() ?>

                                    </div>
                                    <div class="tab-pane fade" id="mm-breakpoints-<?= $identifier ?>">

                                        <?= mm_upgrade_this_pro_box() ?>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12 text-right mt-2">
                                <div class="row">
                                    <div class="col-auto ml-4 custom-control custom-switch text-left text-lg-center <?= $hide_me['link'] ?>" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_ITEM_FORM_NEW_TAB_TIP ?>">
                                        <input type="checkbox" class="custom-control-input mm_item_target" id="mm_item_target<?= $identifier ?>" name="mm_item_target<?= $identifier ?>" value="1" <?php if ( $data['item_target'] == '_blank' ) {
                                            echo 'CHECKED';
                                        } ?>>
                                        <label class="custom-control-label" for="mm_item_target<?= $identifier ?>"><small><?= MM_MENU_ITEM_FORM_NEW_TAB ?></small></label>
                                    </div>

                                    <div class="col-auto ml-4 custom-control custom-switch text-left text-lg-center" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_ITEM_FORM_GUEST_TIP ?>">
                                        <input onChange="mm_update_restrict_loggedin('<?= $identifier ?>');" type="checkbox" class="custom-control-input mm_restrict_loggedin-2" id="mm_restrict_loggedin-2<?= $identifier ?>" name="mm_restrict_loggedin-2<?= $identifier ?>" value="2" <?php if ( empty( $data['restrict_loggedin'] ) || $data['restrict_loggedin'] == 1 ) {
                                            echo 'CHECKED';
                                        } ?> disabled>
                                        <label class="custom-control-label" for="mm_restrict_loggedin-2<?= $identifier ?>"><small><?= MM_MENU_ITEM_FORM_GUEST ?></small></label>
                                    </div>

                                    <div class="col-auto ml-4 custom-control custom-switch text-left" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_ITEM_FORM_USER_TIP ?>">
                                        <input onChange="mm_update_restrict_loggedin('<?= $identifier ?>');" type="checkbox" class="custom-control-input mm_restrict_loggedin-1" id="mm_restrict_loggedin-1<?= $identifier ?>" name="mm_restrict_loggedin-1<?= $identifier ?>" value="1" <?php if ( empty( $data['restrict_loggedin'] ) || $data['restrict_loggedin'] == 2 ) {
                                            echo 'CHECKED';
                                        } ?> disabled>
                                        <label class="custom-control-label" for="mm_restrict_loggedin-1<?= $identifier ?>"><small><?= MM_MENU_ITEM_FORM_USER ?></small></label>
                                    </div>

                                    <div class="col-auto ml-4 custom-control custom-switch text-left" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_ITEM_FORM_CART_TIP ?>">
                                        <input onChange="mm_update_restrict_basket('<?= $identifier ?>');" type="checkbox" class="custom-control-input mm_restrict_basket" id="mm_restrict_basket<?= $identifier ?>" name="mm_restrict_basket<?= $identifier ?>" value="1" <?php if ( ! empty( $data['restrict_basket'] ) ) {
                                            echo 'CHECKED';
                                        } ?> disabled>
                                        <label class="custom-control-label" for="mm_restrict_basket<?= $identifier ?>"><small><?= MM_MENU_ITEM_FORM_CART ?></small></label>
                                    </div>

                                    <div class="col-auto ml-4 custom-control custom-switch text-left mm_mega_menu-control" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_ITEM_FORM_MEGA_TIP ?>">
                                        <input onChange="mm_update_mega_menu('<?= $identifier ?>');" type="checkbox" class="custom-control-input mm_mega_menu" id="mm_mega_menu<?= $identifier ?>" name="mm_mega_menu<?= $identifier ?>" value="1" <?php if ( ! empty( $data['mega_menu'] ) ) {
                                            echo 'CHECKED';
                                        } ?> disabled>
                                        <label class="custom-control-label" for="mm_mega_menu<?= $identifier ?>"><small><?= MM_MENU_ITEM_FORM_MEGA ?></small></label>
                                    </div>


                                    <div class="col-auto ml-4 custom-control custom-switch text-left" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_ITEM_FORM_MOBILE_TIP ?>">
                                        <input onChange="mm_update_item_mobile('<?= $identifier ?>');" type="checkbox" class="custom-control-input mm_item_mobile" id="mm_item_mobile<?= $identifier ?>" name="mm_item_mobile<?= $identifier ?>" value="1" <?php if ( ! empty( $data['show_on_mobile'] ) ) {
                                            echo 'CHECKED';
                                        } ?>>
                                        <label class="custom-control-label" for="mm_item_mobile<?= $identifier ?>"><small><?= MM_MENU_ITEM_FORM_MOBILE ?></small></label>
                                    </div>

                                    <div class="col-auto ml-4 custom-control custom-switch text-left" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_ITEM_FORM_ENABLED_TIP ?>">
                                        <input onChange="mm_update_item_status('<?= $identifier ?>');" type="checkbox" class="custom-control-input mm_item_status" id="mm_item_status<?= $identifier ?>" name="mm_item_status<?= $identifier ?>" value="1" <?php if ( ! empty( $data['item_status'] ) ) {
                                            echo 'CHECKED';
                                        } ?>>
                                        <label class="custom-control-label" for="mm_item_status<?= $identifier ?>"><small><?= MM_MENU_ITEM_FORM_ENABLED ?></small></label>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="col-12 text-left p-0 m-0">
                            <a href="javascript: mm_delete_item('<?= $identifier ?>');" class="text-danger" title="<?= MM_MENU_ITEM_FORM_DELETE_TIP ?>"><small><?= MM_MENU_ITEM_FORM_DELETE ?></small></a>
                        </div>
                    </div>
                </div>
                <?php
                    if ( ! empty( $menu_has_children ) ) {
                        echo '<ul>';
                        $this->drawItems( $uuid );
                        echo '</ul>';
                    }
                ?>
            </li>
            <?php
        }

        /**
         * @param $location
         */
        public function addLocation( $location ) {

            tep_db_query( "DELETE FROM menu_master_to_location WHERE menu_id = {$this->menu['menu_id']} AND menu_location=$location;" );
            tep_db_query( "INSERT INTO menu_master_to_location (menu_id, menu_location) VALUES ({$this->menu['menu_id']}, $location);" );
            $this->generateJSON();
        }

        /**
         * @param $location
         */
        public function removeLocation( $location ) {

            tep_db_query( "DELETE FROM menu_master_to_location WHERE menu_id = {$this->menu['menu_id']} AND menu_location=$location;" );
            $this->generateJSON();
        }

        public function loadLocations() {

            $this->locations = [];
            if ( ! empty( $this->menu['menu_id'] ) ) {
                $location_query = tep_db_query( "SELECT 
                           *
                    FROM 
                         menu_master_to_location
                    WHERE 
                          menu_id={$this->menu['menu_id']} 
                    ORDER BY menu_location" );
                while ( $item = tep_db_fetch_array( $location_query ) ) {
                    $this->locations[] = $item;
                }
            }
        }

        /**
         * @return array[]
         */
        public function getMenuLocations() {

            return [
                1  => [ 'id' => 1, 'name' => MM_MENU_LOCATION_1, ],
                2  => [ 'id' => 2, 'name' => MM_MENU_LOCATION_2, ],
                3  => [ 'id' => 3, 'name' => MM_MENU_LOCATION_3, ],
                12 => [ 'id' => 12, 'name' => MM_MENU_LOCATION_12, ],
                7  => [ 'id' => 7, 'name' => MM_MENU_LOCATION_7, ],
            ];

        }

        public function drawMenuLocations() {

            $location_html = '<small data-toggle="tooltip" data-placement="top" title="' . MM_MENU_ADD_LOCATION_TIP . '">' . MM_MENU_ADD_LOCATION . ':</small> ';

            if ( empty( $this->locations ) ) {
                $location_html .= '<small class="text-danger">None</small>';
            } else {

                foreach ( $this->locations as $location ) {
                    $location_html                                      .= '<div class="text-success border border-success rounded" style="display: inline-block; padding: 0px 5px;"><small>' . $this->menu_locations[ $location['menu_location'] ]['name'] . ' <a href="javascript: mm_remove_location(' . $this->menu_locations[ $location['menu_location'] ]['id'] . ');" class="text-danger"><i class="fas fa-times"></i></a></small></div> ';
                    $this->used_locations[ $location['menu_location'] ] = 1;
                }
            }

            echo $location_html;

            $options = '';
            foreach ( $this->menu_locations as $menu_location ) {
                if ( empty( $this->used_locations[ $menu_location['id'] ] ) ) {
                    $options .= '<option value="' . $menu_location['id'] . '">' . $menu_location['name'] . '</option>';
                }
            }
            if ( ! empty( $options ) ) {
                ?>
                <select id="mm_locations" class="ml-4">
                    <?= $options ?>
                </select> <a href="javascript: mm_add_location();" class="text-success"><i class="fas fa-plus"></i></a>
                <?php
            }

        }

        public function getSettings() {

            $this->settings = [];

            $settings_query = tep_db_query( "SELECT * FROM menu_master_settings ORDER BY setting_key" );

            while ( $result = tep_db_fetch_array( $settings_query ) ) {
                $this->settings[ $result['setting_key'] ] = $result['setting_val'];
            }

        }

        /**
         * @param $key
         * @param $val
         */
        public function updateSetting( $key, $val ) {

            tep_db_query( "DELETE FROM menu_master_settings WHERE setting_key='$key'" );

            $key = strtoupper( $key );

            tep_db_query( "INSERT INTO menu_master_settings (setting_key, setting_val) VALUES  ('$key', '$val')" );

            $this->getSettings();

        }

        /**
         * @return array[]
         */
        public function getPhoenixPages() {

            $dir = DIR_WS_CATALOG;

            return [
                0  => [ 'id' => 0, 'url' => '', 'name' => '', ],
                1  => [ 'id' => 1, 'url' => $dir . 'account.php', 'name' => MM_MENU_PHOENIX_PAGE_ACCOUNT, ],
                2  => [
                    'id'   => 2,
                    'url'  => $dir . 'account_history.php',
                    'name' => MM_MENU_PHOENIX_PAGE_ACCOUNT_HISTORY,
                ],
                3  => [
                    'id'   => 3,
                    'url'  => $dir . 'account_newsletters.php',
                    'name' => MM_MENU_PHOENIX_PAGE_ACCOUNT_NEWSLETTERS,
                ],
                4  => [
                    'id'   => 4,
                    'url'  => $dir . 'account_notifications.php',
                    'name' => MM_MENU_PHOENIX_PAGE_ACCOUNT_NOTIFICATIONS,
                ],
                5  => [ 'id' => 5, 'url' => $dir . 'address_book.php', 'name' => MM_MENU_PHOENIX_PAGE_ADDRESS_BOOK, ],
                6  => [
                    'id'   => 6,
                    'url'  => $dir . 'advanced_search.php',
                    'name' => MM_MENU_PHOENIX_PAGE_ADVANCED_SEARCH,
                ],
                7  => [ 'id' => 7, 'url' => $dir . 'checkout_shipping.php', 'name' => MM_MENU_PHOENIX_PAGE_CHECKOUT, ],
                8  => [
                    'id'   => 8,
                    'url'  => $dir . 'create_account.php',
                    'name' => MM_MENU_PHOENIX_PAGE_CREATE_ACCOUNT,
                ],
                9  => [ 'id' => 9, 'url' => $dir . 'index.php', 'name' => MM_MENU_PHOENIX_PAGE_HOME, ],
                10 => [ 'id' => 10, 'url' => $dir . 'login.php', 'name' => MM_MENU_PHOENIX_PAGE_LOGIN, ],
                11 => [ 'id' => 11, 'url' => $dir . 'logoff.php', 'name' => MM_MENU_PHOENIX_PAGE_LOGOFF, ],
                12 => [
                    'id'   => 12,
                    'url'  => $dir . 'password_forgotten.php',
                    'name' => MM_MENU_PHOENIX_PASSWORD_RESET,
                ],
                13 => [ 'id' => 13, 'url' => $dir . 'shopping_cart.php', 'name' => MM_MENU_PHOENIX_SHOPPING_CART, ],
                14 => [ 'id' => 14, 'url' => $dir . 'specials.php', 'name' => MM_MENU_PHOENIX_SPECIALS, ],
                15 => [ 'id' => 15, 'url' => $dir . 'testimonials.php', 'name' => MM_MENU_PHOENIX_TESTIMONIALS, ],
            ];

        }

        /**
         * @return array[]
         */
        public function getSpecialItems() {

            return [];

        }

        /**
         * @param int $parent_id
         * @param int $last_parent
         */
        public function drawCategories( $parent_id = 0, $last_parent = 0 ) {

            echo '';

        }

        /**
         * @param $search
         */
        public function drawProducts( $search ) {

            echo '';

        }

        function loadItemLanguages() {

            $this->menuitem_lang = [];
            $query               = tep_db_query( "SELECT * FROM menu_master_items_language" );
            while ( $result = tep_db_fetch_array( $query ) ) {
                $this->menuitem_lang[ $result['menu_item_id'] . '-' . $result['language_id'] ] = $result;
            }
        }

        /**
         * @param int    $parentid
         * @param int    $depth
         * @param int    $levels
         * @param string $ancestors
         */
        function loadItemCategories( $parentid = 0, $depth = 0, $levels = 0, $ancestors = '' ) {

            $this->categories = [];

        }

        function loadItemProducts() {

            $this->products = [];

        }

        function generateJSON() {

            $this->getMenus();
            $this->json = [];

            if ( ! empty( $this->menus ) ) {
                $this->json['menus']         = $this->menus;
                $this->json['special_items'] = $this->special_items;
                $this->json['phoenix_pages'] = $this->phoenix_pages;
                $this->json['languages']     = $this->languages;
                $this->loadItemLanguages();
                $this->json['menuitem_lang'] = $this->menuitem_lang;
                $this->loadItemCategories();
                $this->json['categories'] = $this->categories;
                $this->loadItemProducts();
                $this->json['products']  = $this->products;
                $this->json['locations'] = [];

                $location_query = tep_db_query( "SELECT 
                           *
                    FROM 
                         menu_master_to_location mmtl, menu_master mm
                    WHERE mmtl.menu_id=mm.menu_id
                    ORDER BY menu_location, mm.sort_order" );
                while ( $item = tep_db_fetch_array( $location_query ) ) {
                    if ( empty( $this->json['locations'][ $item['menu_location'] ] ) ) {
                        $this->json['locations'][ $item['menu_location'] ] = [];
                    }
                    $this->json['locations'][ $item['menu_location'] ][] = $item['menu_id'];
                }

                $this->json['items'] = [];

                $items_query = tep_db_query( "SELECT 
                           *
                    FROM 
                         menu_master_items
                    ORDER BY menu_id, parent_uuid, sort_order" );
                while ( $item = tep_db_fetch_array( $items_query ) ) {
                    if ( empty( $this->json['items'][ $item['menu_id'] ] ) ) {
                        $this->json['items'][ $item['menu_id'] ] = [];
                    }
                    if ( empty( $this->json['items'][ $item['menu_id'] ][ $item['parent_uuid'] ] ) ) {
                        $this->json['items'][ $item['menu_id'] ][ $item['parent_uuid'] ] = [];
                    }

                    $this->json['items'][ $item['menu_id'] ][ $item['parent_uuid'] ][ $item['uuid'] ] = $item;


                }

                $this->json['menu_lang'] = [];
                $query                   = tep_db_query( "SELECT * FROM menu_master_language" );
                while ( $result = tep_db_fetch_array( $query ) ) {
                    if ( empty( $this->json['menu_lang'][ $result['menu_id'] ] ) ) {
                        $this->json['menu_lang'][ $result['menu_id'] ] = [];
                    }
                    $this->json['menu_lang'][ $result['menu_id'] ] [ $result['language_id'] ] = $result;
                }

                $this->json['info_pages'] = [];
                if ( zipCheckDBTableExists( 'pages' ) ) {
                    $query = tep_db_query( "SELECT p.pages_id, p.pages_status, p.slug, pd.navbar_title, pd.languages_id FROM pages p, pages_description pd WHERE p.pages_id=pd.pages_id" );
                    while ( $result = tep_db_fetch_array( $query ) ) {
                        if ( empty( $this->json['info_pages'][ $result['pages_id'] ] ) ) {
                            $this->json['info_pages'][ $result['pages_id'] ] = [];
                        }
                        $this->json['info_pages'][ $result['pages_id'] ][ $result['languages_id'] ] = $result;
                    }
                }

            }

            $temp_cache_dir = DIR_FS_CATALOG . 'includes/apps/menu_master/cache/';

            if ( ! file_exists( $temp_cache_dir ) ) {
                mkdir( $temp_cache_dir, 0755 );
            }

            $temp_cache_file = DIR_FS_CATALOG . 'includes/apps/menu_master/cache/temp_menu_master.cache';

            $json = json_encode( $this->json );

            if ( ! empty( $this->publishyn ) ) {
                if (!empty($result['menu_id'])) {
                    $this->clearScriptFiles( $result['menu_id'] );
                }
                $cache_file = DIR_FS_CATALOG . 'includes/apps/menu_master/cache/menu_master.cache';
                if ( file_exists( $cache_file ) ) {
                    unlink( $cache_file );
                }
                file_put_contents( $cache_file, $json );
            }

            if ( file_exists( $temp_cache_file ) ) {
                unlink( $temp_cache_file );
            }

            file_put_contents( $temp_cache_file, $json );

        }


        /**
         * @param $menu_id
         */
        private function clearScriptFiles( $menu_id ) {

            $js_files = DIR_FS_CATALOG . 'includes/apps/menu_master/js/';
            if ( is_dir( $js_files ) ) {
                $dir_handle = opendir( $js_files );

                while ( $file = readdir( $dir_handle ) ) {
                    if ( $file != "." && $file != ".." ) {
                        if ( ! is_dir( $js_files . "/" . $file ) ) {
                            if ( substr( $file, 0, 10 ) == 'mm-cached-' ) {
                                if ( file_exists( $js_files . $file ) ) {
                                    unlink( $js_files . $file );
                                }
                            }
                        }
                    }
                }
                closedir( $dir_handle );
            }

            $css_files = DIR_FS_CATALOG . 'includes/apps/menu_master/css/';
            if ( is_dir( $css_files ) ) {
                $dir_handle = opendir( $css_files );
                while ( $file = readdir( $dir_handle ) ) {
                    if ( $file != "." && $file != ".." ) {
                        if ( ! is_dir( $css_files . "/" . $file ) ) {
                            if ( substr( $file, 0, 10 ) == 'mm-cached-' ) {
                                if ( file_exists( $css_files . $file ) ) {
                                    unlink( $css_files . $file );
                                }
                            }
                        }
                    }
                }
                closedir( $dir_handle );
            }

        }

    }
