<?php

    

/*
* $Id: functions.php
* $Loc: /includes/apps/menu_master/admin/functions/
*
* Name: zipurMenuMasterLite
* Version: 1.2.0
* Release Date: 01/08/2022
* Author: Preston Lord
* 	 phoenixaddons.com / @zipurman / plord@inetx.ca
*
* License: Commercial License
* 
* Cannot be distributed
*  
* Commercial use allowed
*  
* Cannot modify source-code for any purpose (cannot create derivative works)
*
* Comments: Copyright (c) 2021: Preston Lord - @zipurman - Intricate Networks Inc.
* 
* All rights reserved.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
* (Packaged with Zipur Bundler v2.0.2)
*/





    /**
     * @param $class
     */
    function zipur_mm_autoloader( $class ) {

        $path = DIR_FS_CATALOG . 'includes/apps/menu_master/admin/classes/';
        if ( substr( $class, 0, 10 ) == 'menuMaster' ) {
            $file = $path . $class . '.php';
            if ( file_exists( $file ) ) {
                include $file;
            }
        }

        $path = DIR_FS_CATALOG . 'includes/apps/menu_master/classes/';
        if ( substr( $class, 0, 10 ) == 'menuMaster' ) {
            $file = $path . $class . '.php';
            if ( file_exists( $file ) ) {
                include $file;
            }
        }

    }

    spl_autoload_register( 'zipur_mm_autoloader' );

    /** Copied from core to adjust behaviors on errors
     *
     * @param string $server
     * @param string $username
     * @param string $password
     * @param string $database
     * @param string $link
     *
     * @return mixed
     */
    function zip_db_connect( $server = DB_SERVER, $username = DB_SERVER_USERNAME, $password = DB_SERVER_PASSWORD, $database = DB_DATABASE, $link = 'db_link' ) {

        global $$link;
        $$link = mysqli_connect( $server, $username, $password, $database );
        if ( ! mysqli_connect_errno() ) {
            mysqli_set_charset( $$link, 'utf8' );
        }
        @mysqli_query( $$link, 'SET SESSION sql_mode=""' );

        return $$link;
    }

    /** Copied from core to adjust behaviors on errors
     *
     * @param        $query
     * @param string $link
     *
     * @return bool|mysqli_result
     */
    function zip_db_query( $query, $link = 'db_link' ) {

        global $$link, $logger;

        return mysqli_query( $$link, $query );
    }

    /**
     * @param $name
     *
     * @return string
     */
    function zipVarCheck4Pixel($name){

        return  zipVarCheck( $name . '_t', 0, 'FILTER_VALIDATE_INT', 0  ) . 'px ' . zipVarCheck( $name . '_r', 0, 'FILTER_VALIDATE_INT', 0  ) . 'px ' . zipVarCheck( $name . '_b', 0, 'FILTER_VALIDATE_INT', 0  ) . 'px ' . zipVarCheck( $name . '_l', 0, 'FILTER_VALIDATE_INT', 0 ) . 'px';

    }

    /**
     * Function to check POST/GET/COOKIE/SESSION vars and validate if needed with defaults
     *
     * @param        $var_to_check
     * @param        $default_value
     * @param string $checkformat
     * @param string $if_invalid_value
     * @param null   $current_val
     *
     * @return int|null
     */
    function zipVarCheck( $var_to_check, $default_value, $checkformat = "", $if_invalid_value = "", $current_val = null ) {

        if ( $current_val != null && $default_value == $current_val ) {
            $y = $current_val;
        } else if ( $current_val != "" && $current_val != null ) {
            $y = $current_val;
        } else {
            if ( isset( $_GET[ $var_to_check ] ) ) {
                $y = $_GET[ $var_to_check ];
            } elseif ( isset( $_POST[ $var_to_check ] ) ) {
                $y = $_POST[ $var_to_check ];
            } elseif ( isset( $_COOKIE[ $var_to_check ] ) ) {
                $y = $_COOKIE[ $var_to_check ];
            }  else {
                $y = $default_value;
            }
        }
        $checkformat = (string) $checkformat;
        if ( strpos( "$checkformat", "FILTER_VALIDATE_INT" ) !== false ) {
            if ( filter_var( $y, FILTER_VALIDATE_INT ) === 0 || ! filter_var( $y, FILTER_VALIDATE_INT ) === false ) {
                //all okay with $y
            } else {
                $y = $if_invalid_value;
            }
        } else if ( strpos( "$checkformat", "FILTER_VALIDATE_PIN" ) !== false ) {
            $opt = [ "options" => [ "regexp" => "/^[0-9]{4,8}$/" ] ];
            if ( filter_var( $y, FILTER_VALIDATE_REGEXP, $opt ) === false ) {
                $y = $if_invalid_value;
            }
        } else if ( strpos( "$checkformat", "FILTER_VALIDATE_FLOAT" ) !== false ) {
            $y = (float) $y;
            if ( ! filter_var( $y, FILTER_VALIDATE_FLOAT ) ) {
                $y = $if_invalid_value;
            }
        } else if ( strpos( "$checkformat", "FILTER_VALIDATE_DATE" ) !== false ) {
            if ( ! validateDate( $y, 'm/d/Y' ) ) {
                $y = $if_invalid_value;
            }
            //double check date length as weird values like 08/14/-18343974928 return true
            if ( strlen( $y ) != '10' ) {
                $y = $if_invalid_value;
            }

        } else if ( strpos( "$checkformat", "FILTER_VALIDATE_EMAIL" ) !== false ) {
            if ( ! filter_var( $y, FILTER_VALIDATE_EMAIL ) ) {
                $y = $if_invalid_value;
            }
        } else if ( strpos( "$checkformat", "FILTER_VALIDATE_URL" ) !== false ) {
            if ( ! filter_var( $y, FILTER_VALIDATE_URL ) ) {
                $y = $if_invalid_value;
            }
        } else if ( strpos( "$checkformat", "FILTER_VALIDATE_ARRAY" ) !== false ) {
            if ( ! is_array( $y ) ) {
                if ( is_array( $if_invalid_value ) ) {
                    $y = $if_invalid_value;
                } else {
                    $y = [ $if_invalid_value ];
                }
            }
        }

        return $y;
    }

    /**
     * @param        $date
     * @param string $format
     *
     * @return bool
     */
    function validateDate( $date, $format = 'Y-m-d H:i:s' ) {

        $d = DateTime::createFromFormat( $format, $date, new DateTimeZone( CFG_TIME_ZONE ) );

        return $d && $d->format( $format ) == $date;
    }

    /**
     * @param $filename
     *
     * @return array|string|string[]|null
     */
    function zipGetFileVersion( $filename ) {

        //get this tool version number from above content block. Dynamically created by Update Creator.
        $getcheckfile  = file_get_contents( $filename );
        $checkstartloc = strpos( $getcheckfile, 'Version' );
        $checkendloc   = strpos( $getcheckfile, "\n", $checkstartloc );
        $versiontext   = substr( $getcheckfile, $checkstartloc, $checkendloc - $checkstartloc + 2 );

        return preg_replace( '/[^0-9.]/', '', $versiontext );
    }

    /**
     * Ass banner to top of zipur addons for easy support, docs, etc.
     */
    function zipAdBanner() {

        ?>
        <div style="text-align: right; padding: 0px 40px; margin-bottom: 10px;">
            This tool created by @zipurman (<a href="https://PhoenixAddons.com" target="_blank">PhoenixAddons.com</a>)
        </div>
        <?php
    }

    /**
     * @param $tablename
     *
     * @return bool
     */
    function zipCheckDBTableExists( $tablename ) {

        $check_query = tep_db_query( "show tables like \"$tablename\";" );
        $data        = [];
        while ( $result = tep_db_fetch_array( $check_query ) ) {
            $data[] = $result;
        }

        return ! empty( $data );
    }

    /**
     * @param        $text
     * @param string $class
     */
    function zipAlert( $text, $class = 'warning' ) {

        ?>
        <div class="alert alert-<?= $class ?> p-1 m-1" role="alert">
            <?= $text ?>
        </div>
        <?php
    }

    function zipCEPBanner() {

        global $version, $zipFileVersion, $osprod, $menuMaster, $mm_version, $mm_is_installed;
        ?>
        <div class="bg-dark text-light p-4 mx-0 my-2 mw-100 rounded">
            <div class="row">
                <div class="col-sm">
                    <a href="https://phoenixaddons.com" target="_blank"><img
                                src="https://phoenixaddons.com/wp-content/uploads/2020/08/CE-Phoenix_Addons_logo2.png"
                                style="width: 220px; margin-top: 14px;"></a>
                </div>
                <div class="col-sm text-center">
                    <h4 class="display-7 mb-2"><?php echo HEADING_TITLE . '<br/><small>(' . $zipFileVersion . ')</small>'; ?></h4>
                    <?php
                        if (((!empty($menuMaster) && $mm_version != $menuMaster->settings['VERSION'] )|| $mm_version != $zipFileVersion ) && !empty($mm_is_installed)){
                            echo '<a href="javascript: mm_upgrade();"><span class="text-danger">' . MM_MENU_UPGRADE_REQUIRED . '</span></a>';
                        }
                    ?>
                </div>
                <div class="col-sm text-center">
                    <strong class="display-8 mb-2"><?php echo '(' . $osprod . ' ' . TABLE_HEADING_VERSION . ' ' . $version . ')'; ?></strong>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * @param $upgrade
     */
    function zipVersionCleanUp($upgrade) {

        global $mm_version, $menuMaster, $uninstall, $menuuninstall;

        if ($menuMaster->settings['VERSION'] != $mm_version && empty($upgrade) && empty($uninstall)){
            tep_redirect( tep_href_link( 'zipur_menu_master.php', 'upgrade=1' ) );
        }

    }

    /**
     * @param        $name
     * @param        $value
     * @param int    $small
     * @param string $input_class
     */
    function zipColorPicker( $name, $value, $small = 0 , $input_class = '') {

        $extra_classes = '';
        if (!empty($small)){
            $extra_classes .= 'mmcolorpicker-small';
        }
        ?>
        <div class="input-group mb-3 mmcolorpicker <?= $extra_classes ?>">
            <input type="text" value="<?= $value ?>" id="<?= $name ?>" name="<?= $name ?>" class="<?= $input_class ?> form-control"/>
            <div class="input-group-append">
                <span class="input-group-text" id="<?= $name ?>-addon"><i style="background: <?= $value ?>;"></i></span>
            </div>
        </div>
        <?php
    }

    /**
     * @param $name
     * @param $value
     */
    function zip4Pixel( $name, $value ) {

        if (!is_array( $value)){
            if (!empty($value)){
                $value = str_replace( 'px', '', $value );
                $value = explode( ' ', $value );
            }
        }

        if (empty($value)){
            $value = [0,0,0,0];
        }

        ?>
        <div class="input-group mb-3 pixel4">
            <input type="text" value="<?= $value[0] ?>" id="<?= $name ?>_t" name="<?= $name ?>_t" class="form-control" placeholder="<?= MM_MENU_PX_TOP ?>" required data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_PX_TOP_TIP ?>"/>
            <div class="input-group-append">
                <span class="input-group-text" id="<?= $name ?>-addon_t">px</span>
            </div>
            <input type="text" value="<?= $value[1] ?>" id="<?= $name ?>_r" name="<?= $name ?>_r" class="form-control" placeholder="<?= MM_MENU_PX_RIGHT ?>" required data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_PX_RIGHT_TIP ?>"/>
            <div class="input-group-append">
                <span class="input-group-text" id="<?= $name ?>_r-addon">px</span>
            </div>
            <input type="text" value="<?= $value[2] ?>" id="<?= $name ?>_b" name="<?= $name ?>_b" class="form-control" placeholder="<?= MM_MENU_PX_BOTTOM ?>" required data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_PX_BOTTOM_TIP ?>"/>
            <div class="input-group-append">
                <span class="input-group-text" id="<?= $name ?>_b-addon">px</span>
            </div>
            <input type="text" value="<?= $value[3] ?>" id="<?= $name ?>_l" name="<?= $name ?>_l" class="form-control" placeholder="<?= MM_MENU_PX_LEFT ?>" required data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_PX_LEFT_TIP ?>"/>
            <div class="input-group-append">
                <span class="input-group-text" id="<?= $name ?>_l-addon">px</span>
            </div>
        </div>
        <?php
    }

    /**
     * @param $a
     * @param $b
     *
     * @return int
     */
    function sort_objects_by_order($a, $b) {
        if($a->sort_order == $b->sort_order){ return 0 ; }
        return ($a->sort_order < $b->sort_order) ? -1 : 1;
    }

    /**
     * @param $mod
     * @param $onoff
     */
    function mm_menu_install( $mod, $onoff ) {

        if ( $mod == 1 ) {
            $masterkey   = 'MODULE_CONTENT_NAVBAR_INSTALLED';
            $mastervalue = 'nb_mm_menu.php';
        } else if ( $mod == 2 ) {
            $masterkey   = 'MODULE_BOXES_INSTALLED';
            $mastervalue = 'bm_mm_menu_left.php';
        } else if ( $mod == 3 ) {
            $masterkey   = 'MODULE_BOXES_INSTALLED';
            $mastervalue = 'bm_mm_menu_right.php';
        } else if ( $mod == 4 ) {
            $masterkey   = 'MODULE_CONTENT_INSTALLED';
            $mastervalue = 'header/cm_header_mm_menu';//CM - no .php at the end
        } else if ( $mod == 5 ) {
            $masterkey   = 'MODULE_CONTENT_INSTALLED';
            $mastervalue = 'product_info/cm_pi_mm_menu';//CM - no .php at the end
        } else if ( $mod == 6 ) {
            $masterkey   = 'MODULE_CONTENT_INSTALLED';
            $mastervalue = 'shopping_cart/cm_sc_mm_menu';//CM - no .php at the end
        } else if ( $mod == 7 ) {
            $masterkey   = 'MODULE_CONTENT_INSTALLED';
            $mastervalue = 'checkout_success/cm_cs_mm_menu';//CM - no .php at the end
        } else if ( $mod == 8 ) {
            $masterkey   = 'MODULE_CONTENT_INSTALLED';
            $mastervalue = 'index_nested/cm_in_mm_menu';//CM - no .php at the end
        } else if ( $mod == 9 ) {
            $masterkey   = 'MODULE_CONTENT_INSTALLED';
            $mastervalue = 'index_products/cm_ip_mm_menu';//CM - no .php at the end
        } else if ( $mod == 10 ) {
            $masterkey   = 'MODULE_HEADER_TAGS_INSTALLED';
            $mastervalue = 'ht_mm_menu.php';
        }

        if ( ! empty( $masterkey ) ) {
            $mod_query = tep_db_query( "SELECT * FROM configuration WHERE configuration_key='$masterkey'" );
            $result    = tep_db_fetch_array( $mod_query );
            if ( ! empty( $result ) ) {
                $tags = explode( ';', $result['configuration_value'] );
                foreach ( $tags as $key => $tag ) {
                    if ( $tag == $mastervalue ) {
                        unset( $tags[ $key ] );
                    }
                }

                if ( ! empty( $onoff ) ) {
                    $tags[] = $mastervalue;
                }

                sort( $tags );

                $result['configuration_value'] = implode( ';', $tags );

                tep_db_query( "UPDATE configuration SET configuration_value='{$result['configuration_value']}' WHERE configuration_key='$masterkey'" );
            }
        }
    }

    /**
     * @param $files
     *
     * @return string
     */
    function mm_config_module_files( $files ) {

        $mod = '<i class="fas fa-check text-success"></i>';
        foreach ( $files as $file ) {
            if ( ! file_exists( DIR_FS_CATALOG . $file ) ) {
                $mod = '<i class="fas fa-exclamation-triangle text-danger" title="' . MM_MENU_CONFIG_MISSING_FILES . '"></i>';
            }
        }

        return $mod;
    }

    /**
     * @param $key
     * @param $modid
     *
     * @return string
     */
    function mm_config_module_status( $key, $modid ) {

        $mod_status = ' <span class="text-success">' . MM_MENU_CONFIG_ENABLED . '</span> <button onClick="mm_mod_change(' . $modid . ', 0);" type="button" class="btn btn-light border-secondary text-secondary btn-sm py-0">' . MM_MENU_CONFIG_DISABLE . '</button>';
        $mod1_query = tep_db_query( "SELECT * FROM configuration WHERE configuration_key='$key' AND configuration_value='True'" );
        $result     = tep_db_fetch_array( $mod1_query );
        if ( empty( $result ) ) {
            $mod_status = ' <span class="text-danger">' . MM_MENU_CONFIG_DISABLED . '</span>  <button onClick="mm_mod_change(' . $modid . ', 1);" type="button" class="btn btn-light border-secondary text-secondary btn-sm py-0">' . MM_MENU_CONFIG_ENABLE . '</button>';
        }

        return $mod_status;

    }

    /**
     * @param $key
     *
     * @return string
     */
    function mm_config_hook_status( $key ) {

        return file_exists( DIR_FS_CATALOG . 'includes/hooks/shop/' . $key . '.php' ) ? '<i class="fas fa-check text-success"></i>' : '<i class="fas fa-exclamation-triangle text-danger" title="' . MM_MENU_CONFIG_MISSING_FILES . '"></i>';

    }

    /**
     * @param $modid
     * @param $onoff
     * @param $key
     * @param $sort_key
     * @param $configvalues
     */
    function mm_config_configuration( $modid, $onoff, $key, $sort_key, $configvalues ) {

        if ( ! empty( $key ) ) {

            tep_db_query( "DELETE FROM configuration WHERE configuration_key LIKE '$key%'" );

            if ( $onoff == 1 ) {

                $mod_query = tep_db_query( "SELECT configuration_value FROM configuration WHERE configuration_key LIKE '$sort_key%_SORT_ORDER' ORDER BY configuration_value DESC LIMIT 1" );
                $result    = tep_db_fetch_array( $mod_query );
                $sort      = ! empty( $result ) ? (int) $result['configuration_value'] - 5 : 100;
                if ( $sort < 0 ) {
                    $sort = 10;
                }
                foreach ( $configvalues as $configvalue ) {

                    $configvalue['configuration_value'] = str_replace( '--sort--', $sort, $configvalue['configuration_value'] );
                    $configvalue['set_function'] = str_replace("'", "\'", $configvalue['set_function']);

                    tep_db_query( "INSERT INTO configuration 
                    (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function)
                    VALUES ('{$configvalue['configuration_title']}', '{$configvalue['configuration_key']}', '{$configvalue['configuration_value']}', '{$configvalue['configuration_description']}', {$configvalue['configuration_group_id']}, {$configvalue['sort_order']}, now(), now(), '', '{$configvalue['set_function']}')" );
                }

            }

        }

    }

    function mm_upgrade_pro(){
        return 'You can upgrade to the full version <a href="https://phoenixaddons.com/product/phoenix-menu-master/" target="_blank">here</a>.';
    }

    function mm_upgrade_pro_box(){

        return <<<BOX
<div class="border round p-3">
<i class="fas fa-download"></i> <a href="https://phoenixaddons.com/product/phoenix-menu-master/" target="_blank">Upgrade Today</a> for more great menu features.
</div>
BOX;
    }

    function mm_upgrade_this_pro_box(){

        return <<<BOX
<div class="border round p-3 text-muted">
<i class="fas fa-download"></i> This functionality requires the full version of Menu Master. <a href="https://phoenixaddons.com/product/phoenix-menu-master/" target="_blank">Upgrade Today</a>.
</div>
BOX;
    }
