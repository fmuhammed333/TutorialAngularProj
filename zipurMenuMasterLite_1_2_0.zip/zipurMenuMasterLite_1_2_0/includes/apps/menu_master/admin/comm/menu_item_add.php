<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $data = $menuMaster->loadDeafaultItem();

    $data['type']     = zipVarCheck( "mm_item_type", 0, 'FILTER_VALIDATE_INT', 0 );
    $data['id']       = zipVarCheck( "mm_item_id", 0, 'FILTER_VALIDATE_INT', 0 );
    $data['name']     = zipVarCheck( "mm_item_name", '' );
    $data['item_url'] = zipVarCheck( "mm_item_url", '' );

    if ( $data['type'] == 1 ) {

        //page
        $query = tep_db_query( "SELECT navbar_title FROM pages_description WHERE languages_id={$_SESSION['languages_id']} AND pages_id={$data['id']}" );
        $title = tep_db_fetch_array( $query );
        if ( ! empty( $title ) ) {
            $data['navbar_title'] = $title['navbar_title'];
        }

    } else if ( $data['type'] == 2 ) {
        //cat

        $query = tep_db_query( "SELECT categories_name FROM categories_description WHERE language_id={$_SESSION['languages_id']} AND categories_id={$data['id']}" );
        $title = tep_db_fetch_array( $query );
        if ( ! empty( $title ) ) {
            $data['categories_name'] = $title['categories_name'];
        }

    } else if ( $data['type'] == 3 ) {
        //prod

        $query = tep_db_query( "SELECT products_name FROM products_description WHERE language_id={$_SESSION['languages_id']} AND products_id={$data['id']}" );
        $title = tep_db_fetch_array( $query );
        if ( ! empty( $title ) ) {
            $data['products_name'] = $title['products_name'];
        }

    } else if ( $data['type'] == 5 ) {
        //phoneix
        $pages                      = $menuMaster->getPhoenixPages();
        $data['phoenix_pages_name'] = $pages[ $data['id'] ]['name'];

    } else if ( $data['type'] == 6 ) {
        //special
        $pages                = $menuMaster->getSpecialItems();
        $data['specials_name'] = $pages[ $data['id'] ]['name'];

    }

    $menuMaster->addItem( $data );
