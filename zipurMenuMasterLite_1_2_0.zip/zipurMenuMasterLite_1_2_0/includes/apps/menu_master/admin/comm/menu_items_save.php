<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $mm_menu_data          = zipVarCheck( "mm_menu_data", 0 );
    $menuMaster->publishyn = zipVarCheck( 'publishyn', 0, 'FILTER_VALIDATE_INT', 0 );

    $mm_menu_data = json_decode( $mm_menu_data );

    $menuMaster->saveItems( $mm_menu_data );

    $jsonarray = [
        'status' => 1,
    ];
    echo json_encode( $jsonarray );
