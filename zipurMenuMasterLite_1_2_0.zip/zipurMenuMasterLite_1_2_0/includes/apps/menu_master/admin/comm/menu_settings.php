<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $key = zipVarCheck( "key", '' );
    $val = zipVarCheck( "val", '' );
    $type = zipVarCheck( "type", '' );

    if ($type == 'checkbox'){
        $val = ( $val == 'true' ) ? 1 : 0;
    }
    echo $val;

    $menuMaster->updateSetting( $key, $val );
