<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $search = zipVarCheck( "search", '' );

    $menuMaster->drawProducts($search);
