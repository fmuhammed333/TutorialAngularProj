<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $location = zipVarCheck( "location", 0, 'FILTER_VALIDATE_INT', 0 );

    $menuMaster->addLocation( $location );
    $menuMaster->loadLocations();
    $menuMaster->drawMenuLocations();

