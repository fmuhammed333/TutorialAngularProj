<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    //If having trouble - make sure the includes/apps/menu_master/images/ directory is writable by the apache process user/group
    $uuid   = zipVarCheck( 'uuid', '' );
    if ( ! empty( $_FILES ) && !empty($uuid)) {
        foreach ( $_FILES as $value ) {
            $image = '';
            $path = DIR_FS_CATALOG . 'includes/apps/menu_master/images/';
            if ( ! empty( $value['name'] ) ) {
                $value['name'] = preg_replace( '/[^0-9a-zA-Z\-\.]/', '+', $value['name'] );
                if ( $value['type'] == 'image/jpeg' || $value['type'] == 'image/png' || $value['type'] == 'image/gif' ) {
                    if ( $value['size'] < 1 * 1024 * 1024 * 1024 ) {//1MB
                        if ( file_exists( $path . $value['name'] ) ) {
                            unlink( $path . $value['name'] );
                        }
                        if ( move_uploaded_file( $value['tmp_name'], $path . $value['name'] ) ) {
                            $image = $value['name'];
                        }
                    }
                }
            }
            if ( ! empty( $image ) ) {
                $jsonarray = [
                    'image'  => "{$image}",
                    'status' => 1,
                ];
            } else {
                $jsonarray = [
                    'status' => 0,
                ];
            }
            echo json_encode( $jsonarray );
        }
    }
