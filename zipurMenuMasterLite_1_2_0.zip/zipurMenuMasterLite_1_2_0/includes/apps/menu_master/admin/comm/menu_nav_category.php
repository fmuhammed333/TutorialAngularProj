<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $parentid = zipVarCheck( "parentid", 0, 'FILTER_VALIDATE_INT', 0 );
    $fromparentid = zipVarCheck( "fromparentid", 0, 'FILTER_VALIDATE_INT', 0 );

    $menuMaster->drawCategories($parentid, $fromparentid);
