<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $location = zipVarCheck( "location", 0, 'FILTER_VALIDATE_INT', 0 );

    $menuMaster->removeLocation( $location );
    $menuMaster->loadLocations();
    $menuMaster->drawMenuLocations();
