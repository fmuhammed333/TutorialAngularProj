<?php

    // Silence is golden!