<?php

    const MM_CONFIG_TITLE = 'Configuration of Phoenix Modules and Hooks';
    const MM_CONFIG_REQUIRED = 'Required Modules';
    const MM_CONFIG_REQUIRED_DESC = 'Enable each of the following modules to make sure your menus show as expected.';
