<?php

    

/*
* $Id: zipur_menu_master.php
* $Loc: /includes/apps/menu_master/admin/languages/english/
*
* Name: zipurMenuMasterLite
* Version: 1.2.0
* Release Date: 01/08/2022
* Author: Preston Lord
* 	 phoenixaddons.com / @zipurman / plord@inetx.ca
*
* License: Commercial License
* 
* Cannot be distributed
*  
* Commercial use allowed
*  
* Cannot modify source-code for any purpose (cannot create derivative works)
*
* Comments: Copyright (c) 2021: Preston Lord - @zipurman - Intricate Networks Inc.
* 
* All rights reserved.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
* (Packaged with Zipur Bundler v2.0.2)
*/





    const MM_EMPTY_MENU     = 'Welcome to your "%s" menu! You can add menu items using the tools in the toolbar.';
    const MM_MENU_ITEM_TEXT = 'Menu Item Text';

    const MM_MENU_ITEM_INFO_PAGE        = 'Info Page';
    const MM_MENU_ITEM_INFO_PAGE_LINKED = 'Linked to Info Page';

    const MM_MENU_ITEM_CATEGORY        = 'Category';
    const MM_MENU_ITEM_CATEGORY_LINKED = 'Linked to Category';

    const MM_MENU_ITEM_PRODUCT        = 'Product';
    const MM_MENU_ITEM_PRODUCT_LINKED = 'Linked to Product';

    const MM_MENU_ITEM_CUSTOM = 'Custom';

    const MM_MENU_ITEM_PHOENIX_PAGE        = 'Phoenix Page';
    const MM_MENU_ITEM_PHOENIX_PAGE_LINKED = 'Linked to Phoenix Page';

    const MM_MENU_ITEM_SPECIAL_ITEM        = 'Special Item';
    const MM_MENU_ITEM_SPECIAL_ITEM_LINKED = 'Special Item';

    const MM_MENU_ITEM_FORM_TEXT     = 'Item Text';
    const MM_MENU_ITEM_FORM_TEXT_TIP = 'This is the text that will be shown in the menu. If empty, any linked product, category, etc will be used as default text.';

    const MM_MENU_ITEM_FORM_ALIGN_LEFT_TIP   = 'Align Left';
    const MM_MENU_ITEM_FORM_ALIGN_CENTER_TIP = 'Align Center';
    const MM_MENU_ITEM_FORM_ALIGN_RIGHT_TIP  = 'Align Right';

    const MM_MENU_ITEM_FORM_VALIGN_TOP_TIP    = 'Vertical Align Top';
    const MM_MENU_ITEM_FORM_VALIGN_MIDDLE_TIP = 'Vertical Align Middle';
    const MM_MENU_ITEM_FORM_VALIGN_BOTTOM_TIP = 'Vertical Align Bottom';

    const MM_MENU_ITEM_FORM_URL          = 'Item URL';
    const MM_MENU_ITEM_FORM_LEVELS       = 'Levels';
    const MM_MENU_ITEM_FORM_CLASSES      = 'Classes';
    const MM_MENU_ITEM_FORM_COLORS       = 'Colors';
    const MM_MENU_ITEM_FORM_IMAGE        = 'Image';
    const MM_MENU_ITEM_FORM_SCREEN_SIZES = 'Screen Sizes';

    const MM_MENU_ITEM_FORM_EXTRA_CLASSES     = 'Extra Class(es)';
    const MM_MENU_ITEM_FORM_EXTRA_CLASSES_TIP = 'Adding extra classes will allow you to further style your menus using your own css.';
    const MM_MENU_ITEM_FORM_ICON_CLASS        = 'Icon Class';
    const MM_MENU_ITEM_FORM_ICON_CLASS_TIP    = 'Entering a font awesome icon class here will show an icon in your menu item. Example: far fa-lightbulb';
    const MM_MENU_ITEM_FORM_ICON_LIBRARY      = 'Icon Library';
    const MM_MENU_ITEM_FORM_ICON_TIP          = 'If an icon is set, these options allow you to display the icon as needed.';
    const MM_MENU_ITEM_FORM_ICON_TEXT         = 'Icon & Text';
    const MM_MENU_ITEM_FORM_ICON_ONLY_MOBILE  = 'Icon Only (Mobile)';
    const MM_MENU_ITEM_FORM_ICON_ONLY         = 'Icon Only';
    const MM_MENU_ITEM_FORM_LINK_COLOR        = 'Link Color';
    const MM_MENU_ITEM_FORM_LINK_HOVER        = 'Link Hover';
    const MM_MENU_ITEM_FORM_BACKGROUND        = 'Background';
    const MM_MENU_ITEM_FORM_BACKGROUND_HOVER  = 'Background Hover';
    const MM_MENU_ITEM_FORM_DISPLAY_SIZES     = 'Display on screen sizes';
    const MM_MENU_ITEM_FORM_NEW_TAB_TIP       = 'If enabled, this menu item will open in a new browser tab.';
    const MM_MENU_ITEM_FORM_NEW_TAB           = 'New Tab';
    const MM_MENU_ITEM_FORM_GUEST             = 'Guest';
    const MM_MENU_ITEM_FORM_GUEST_TIP         = 'Requires Upgrade! If disabled, guests will not see menu item.';
    const MM_MENU_ITEM_FORM_USER              = 'User';
    const MM_MENU_ITEM_FORM_USER_TIP          = 'Requires Upgrade! If disabled, guests will not see menu item.';
    const MM_MENU_ITEM_FORM_CART              = 'Cart';
    const MM_MENU_ITEM_FORM_CART_TIP          = 'Requires Upgrade! If enabled, this menu item will not show if the cart is empty.';
    const MM_MENU_ITEM_FORM_MEGA              = 'Mega';
    const MM_MENU_ITEM_FORM_MEGA_TIP          = 'Requires Upgrade! If enabled, this menu will act as a MEGA MENU.';
    const MM_MENU_ITEM_FORM_MOBILE            = 'Mobile';
    const MM_MENU_ITEM_FORM_MOBILE_TIP        = 'If disabled, this menu item will not show on the mobile menu.';
    const MM_MENU_ITEM_FORM_ENABLED           = 'Enabled';
    const MM_MENU_ITEM_FORM_ENABLED_TIP       = 'If disabled, the menu item will not show.';
    const MM_MENU_ITEM_FORM_DELETE            = 'Delete';
    const MM_MENU_ITEM_FORM_DELETE_TIP        = 'Clicking this will delete this menu item.';

    const MM_MENU_LOCATION_1  = 'Inside Navbar';
    const MM_MENU_LOCATION_2  = 'Left Bar';
    const MM_MENU_LOCATION_3  = 'Right Bar';
    const MM_MENU_LOCATION_7  = 'Above Footer';
    const MM_MENU_LOCATION_12 = 'Inside Header';

    const MM_MENU_ADD_LOCATION     = 'Location(s)';
    const MM_MENU_ADD_LOCATION_TIP = 'Add location(s) that you want your menu to be visible.';

    const MM_MENU_PHOENIX_PAGE_ACCOUNT               = 'Account';
    const MM_MENU_PHOENIX_PAGE_ACCOUNT_HISTORY       = 'Account History';
    const MM_MENU_PHOENIX_PAGE_ACCOUNT_NEWSLETTERS   = 'Account Newsletters';
    const MM_MENU_PHOENIX_PAGE_ACCOUNT_NOTIFICATIONS = 'Account Notifications';
    const MM_MENU_PHOENIX_PAGE_ADDRESS_BOOK          = 'Address Book';
    const MM_MENU_PHOENIX_PAGE_ADVANCED_SEARCH       = 'Advanced Search';
    const MM_MENU_PHOENIX_PAGE_CHECKOUT              = 'Checkout';
    const MM_MENU_PHOENIX_PAGE_CREATE_ACCOUNT        = 'Create Account';
    const MM_MENU_PHOENIX_PAGE_HOME                  = 'Home Page';
    const MM_MENU_PHOENIX_PAGE_LOGIN                 = 'Login';
    const MM_MENU_PHOENIX_PAGE_LOGOFF                = 'Logoff';
    const MM_MENU_PHOENIX_PASSWORD_RESET             = 'Password Reset';
    const MM_MENU_PHOENIX_SHOPPING_CART              = 'Shopping Cart';
    const MM_MENU_PHOENIX_SPECIALS                   = 'Specials';
    const MM_MENU_PHOENIX_TESTIMONIALS               = 'Testimonials';

    const MM_MENU_SPECIAL_HORIZONTAL_DIVIDER_NAME = 'Horizontal Divider';
    const MM_MENU_SPECIAL_HORIZONTAL_DIVIDER_TIP  = 'Horizontal Divider is placed in your menu to divide menu items.';

    const MM_MENU_SPECIAL_HEADING_NAME = 'Heading';
    const MM_MENU_SPECIAL_HEADING_TIP  = 'Adds a Heading to your menu. Works well with divider and custom classes.';

    const MM_MENU_SPECIAL_SEARCH_NAME = 'Search Tool';
    const MM_MENU_SPECIAL_SEARCH_TIP  = 'Adds the Phoenix Search Form to your menu.';

    const MM_MENU_SPECIAL_ALIGN_NAME = 'Menu Alignment';
    const MM_MENU_SPECIAL_ALIGN_TIP  = 'First instance changes item align between left items and right items for remaining items. Seconds instance changes items to align to the right for remain items. Only works in the main menu.';

    const MM_MENU_UPGRADE_REQUIRED = 'Upgrade Required As Some Files Do Not Match Installed Version';
    const MM_MENU_UPGRADE_TEXT     = 'Your Menu Master (Lite) database is version %s and the code you are using is version %s.';
    const MM_MENU_UPGRADE_VERSION  = 'Version';
    const MM_MENU_UPGRADE_UPGRADES = 'Upgrades';
    const MM_MENU_UPGRADE_NOW      = 'UPGRADE NOW';

    const MM_MENU_EMPTY_DATA = 'Menu Data Empty!!';

    const MM_BACK_TO_MM                = 'Back to Menu Master (Lite)';
    const MM_CANCEL                    = 'Cancel';
    const MM_SAVE_CHANGES              = 'Save Changes';
    const MM_SAVE_CHANGES_TIP          = 'You must click Save Changes to save anything that you have done with the menu below.';
    const MM_CLOSE                     = 'Close';
    const MM_MENU_BACK                 = 'Back';
    const MM_MENU_PX_TOP               = 'TOP';
    const MM_MENU_PX_TOP_TIP           = 'Top Value';
    const MM_MENU_PX_RIGHT             = 'RIGHT';
    const MM_MENU_PX_RIGHT_TIP         = 'Right Value';
    const MM_MENU_PX_BOTTOM            = 'BOTTOM';
    const MM_MENU_PX_BOTTOM_TIP        = 'Bottom Value';
    const MM_MENU_PX_LEFT              = 'LEFT';
    const MM_MENU_PX_LEFT_TIP          = 'Left Value';
    const MM_MENU_CONFIG_MISSING_FILES = 'Missing File(s)';
    const MM_MENU_CONFIG_ENABLED       = 'ENABLED';
    const MM_MENU_CONFIG_ENABLE        = 'ENABLE';
    const MM_MENU_CONFIG_DISABLE       = 'DISABLE';
    const MM_MENU_CONFIG_DISABLED      = 'DISABLED';
    const MM_MENU_SELECT               = 'Select a menu';
    const MM_MENU_TOOLTIPS             = 'Tooltips';
    const MM_MENU_TOOLTIPS_TIP         = 'If enabled, all items will have tooltips available to explain their usage.';
    const MM_MENU_NEW                  = 'New Menu';
    const MM_MENU_NEW_TIP              = 'Clicking this will allow you to create a new menu.';
    const MM_MENU_MODULES              = 'Modules';
    const MM_MENU_MODULES_MISSING      = 'Missing Modules';
    const MM_MENU_MODULES_TIP          = 'Enable/Disable Menu Master (Lite) Modules.';
    const MM_MENU_SELECTED             = 'Selected Menu';
    const MM_MENU_PUBLISH              = 'Publish Menus';
    const MM_MENU_PUBLISH_TIP          = 'By publishing your changes you will see them on your store.';
    const MM_MENU_PREVIEW              = 'Preview';
    const MM_MENU_PREVIEW_TIP          = 'Clicking this will preview the current menu.';
    const MM_MENU_PREVIEW_SELECTED     = 'Preview Selected Menu Only';
    const MM_MENU_PREVIEW_ALL          = 'Preview All Menus';
    const MM_MENU_PREVIEW_ALL_TIP      = 'Clicking this will preview all menus.';
    const MM_MENU_DUPLICATE            = 'Duplicate';
    const MM_MENU_DUPLICATE_TIP        = 'Clicking this will duplicate the current menu.';
    const MM_MENU_EXPORT               = 'Export';
    const MM_MENU_EXPORT_TIP           = 'Clicking this will export the current menu settings.';
    const MM_MENU_IMPORT               = 'Import';
    const MM_MENU_IMPORT_TIP           = 'Clicking this will import a config file that you upload to style your current menu settings.';
    const MM_MENU_SETTINGS             = 'Menu Settings';
    const MM_MENU_DELETE               = 'Delete Menu';
    const MM_MENU_DELETE_TIP           = 'Clicking this will delete this menu and all of it\'s items.';
    const MM_BACKUP_RESTORE            = 'Backup / Restore';
    const MM_BACKUP_RESTORE_TIP        = 'Manage your Menu Master (Lite) backup(s).';
    const MM_UNINSTALL                 = 'Uninstall Menu Master (Lite)';
    const MM_UNINSTALL_TIP             = 'Clicking this will allow you to uninstall Menu Master (Lite) from your store.';
    const MM_UNINSTALL_WARNING         = 'This will remove the database settings for Phoenix Menu Master (Lite) and will remove all menus from your store.';
    const MM_UNINSTALL_DONE            = 'MENU MASTER (Lite) was uninstalled!';

    const MM_ITEMS_ADD_TITLE          = 'Add Menu Items';
    const MM_ITEMS_INFO_PAGES         = 'Info Pages';
    const MM_ITEMS_SELECTED           = 'Selected';
    const MM_ITEMS_SELECT_ALL         = 'Select All';
    const MM_ITEMS_CATEGORIES         = 'Categories';
    const MM_ITEMS_PRODUCTS           = 'Products';
    const MM_ITEMS_SEARCH_PLACEHOLDER = 'Enter Search Text';
    const MM_ITEMS_SEARCH             = 'Search';
    const MM_ITEMS_CUSTOM             = 'Custom Links';
    const MM_ITEMS_TEXT               = 'Item Text';
    const MM_ITEMS_TEXT_TIP           = 'Menu Text';
    const MM_ITEMS_URL                = 'Item URL';
    const MM_ITEMS_ADD                = 'Add';
    const MM_ITEMS_PHOENIX_PAGES      = 'Phoenix Core Pages';
    const MM_ITEMS_SPECIAL_ITEMS      = 'Special Items';

    const MM_LAYOUT_WELCOME       = 'Welcome to Menu Master (Lite)!';
    const MM_LAYOUT_CHOOSE        = 'You must choose a menu from the list above, or create a new menu.';
    const MM_LAYOUT_HEADING       = 'Menu Layout';
    const MM_LAYOUT_TIP           = 'Drag Menu Items by the arrows (<i class="fas fa-arrows-alt"></i>) to position as required. Drag vertically to sort. Drag horizontally to indent to create levels for Mega Menu (Requires Upgrade!)(<i title="To create a Mega Menu style dropdown for a Menu Item, first enable Mega in that Menu Item. First indent level becomes columns. Second indent level becomes items of each column." data-toggle="tooltip" data-placement="bottom"  class="fas fa-question-circle"></i>).';
    const MM_LAYOUT_NONE_SELECTED = 'No menu selected.';

    const MM_SAVE_SUCCESS = 'Changes Saved';
    const MM_SAVE_FAIL    = 'Save Failed';

    const MM_SCRIPT_CFG_ERROR        = 'You must choose a cfg file to import.';
    const MM_SCRIPT_IMAGE_ERROR      = 'Image Upload Failed';
    const MM_SCRIPT_ADD_IMAGE        = 'Add Image';
    const MM_SCRIPT_UPLOAD_TEXT      = 'Upload an image to your menu item. <small>(jpg/png/gif &lt; 1MB)</small>';
    const MM_SCRIPT_PUBLISH_TEXT     = 'Would you like to publish your menus to your store?';
    const MM_SCRIPT_MENU_SAVED       = 'Menu Saved';
    const MM_SCRIPT_MENU_SAVE_FAIL   = 'Menu Saved Failed';
    const MM_SCRIPT_LOCATION_REMOVED = 'Menu Location Removed';
    const MM_SCRIPT_LOCATION_SAVED   = 'Menu Location Saved';
    const MM_SCRIPT_SETTING_SAVED    = 'Setting Updated';




