<?php

    const MM_WELCOME = 'Welcome to <span class="text-primary">Phoenix Menu Master (Lite)</span> !';

    const MM_WELCOME_DETAILS = <<<DETAILS
<div class="col-8">
    <strong>Phoenix Menu Master (Lite)</strong> will allow you to create stunning menus for your Phoenix
    Cart website.<br/><br/>
    Free Features Include:<br/><br/>
    <ul>
        <li>Manage multiple menus.</li>
        <li>Place menus in the header, footer, left/right bars of your site.</li>
        <li>No need to write code as Menu Master will allow you to style your menus.</li>
        <li>Easily link to pages and custom website urls.</li>
        <li>Mobile options.</li>
        <li>and more ...</li>
    </ul>
    
    Full Version Required: (<a href="https://phoenixaddons.com/product/phoenix-menu-master/" target="_blank">Upgrade Here</a>)<br/><br/>
    <ul>
        <li>Place menus in many other locations & specific pages of your site.</li>
        <li>Support for Sticky Menu, Mega Menu, Cart/User/Guest settings</li>
        <li>Easily link to categories, products and additional options.</li>
        <li>Use images and font-awesome in your menus.</li>
        <li>and many more unlocked features ...</li>
    </ul>

    <button type="button" class="btn btn-sm border text-primary border-primary bg-light mx-2" onClick="mm_new();">
        <i class="fas fa-plus"></i> Click Here to Create Your First Menu
    </button>

</div>
DETAILS;
;