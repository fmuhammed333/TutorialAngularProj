<?php

    const MM_DUPE_MENU = 'Duplicate Menu';
    const MM_DUPE_NEW_NAME = 'New Menu Name';
    const MM_DUPE_DUPLICATE_NOW = 'Duplicate Menu';
    const MM_DUPE_NEW_NAME_TIP = 'Enter a name for your menu and then click Duplicate Menu and a copy of the <strong>%s</strong> menu will be created.';
