<?php

    const MM_SETTING_IMPORT = 'IMPORT MENU TEMPLATE';
    const MM_SETTING_IMPORT_ALERT = 'If you import a menu configuration, it will overwrite your current menu styles but will not alter your menu items.';
    const MM_SETTING_IMPORT_SELECT_TEMPLATE = 'Select Template';
    const MM_SETTING_IMPORT_TIP = 'Clicking this will import a config file that you upload to style your current menu settings.';
    const MM_SETTING_IMPORT_NOW = 'Import Now';

    const MM_SETTING_MENU_SETTING_TITLE = 'Menu Settings';

    const MM_SETTING_MENU_NAME = 'Menu Name';
    const MM_SETTING_MENU_NAME_TIP = 'The name of your menu. This is not visible on the store.';

    const MM_SETTING_MENU_CLASSES = 'Menu Class(es)';
    const MM_SETTING_MENU_CLASSES_TIP = 'Menu Classes allow you to further style your menus with your own css.';

    const MM_SETTING_MENU_DISPLAY = 'Menu Display';
    const MM_SETTING_MENU_ENABLED_TIP = 'If disabled, your menu will not be visible on your store.';
    const MM_SETTING_MENU_ENABLED = 'Enabled';
    const MM_SETTING_MENU_STICKY_TIP = 'Requires Upgrade! If enabled, some menu styles will stick to the top of your store if scrolling down.';
    const MM_SETTING_MENU_STICKY = 'Sticky';
    const MM_SETTING_MENU_MOBILE_TIP = 'If disabled, this menu will not be visible on mobile devices.';
    const MM_SETTING_MENU_MOBILE = 'Mobile';

    const MM_SETTING_MENU_LABEL = 'Label Text';
    const MM_SETTING_MENU_LABEL_TIP = 'Label Text will show as a title/handle - beside/above your menu, depending on the menu type and placement.';

    const MM_SETTING_MENU_COLORS = 'Colors';
    const MM_SETTING_MENU_COLORS_TIP = 'You can contol the color codes by setting your preference. (Save & Refresh required)';

    const MM_SETTING_MENU_SORT = 'Sort Order';
    const MM_SETTING_MENU_SORT_TIP = 'If you are using more than one menu in a location, you can use this sort order to change the menu position.';

    const MM_SETTING_MENU_TYPE = 'Menu Type';
    const MM_SETTING_MENU_TYPE_REGULAR = 'Regular Menu';
    const MM_SETTING_MENU_TYPE_TREE = 'Left Tree Menu (can only be used on left bar)';

    const MM_SETTING_MENU_TREE_CLOSED = 'Tree Closed Icon';
    const MM_SETTING_MENU_TREE_CLOSED_TIP = 'Requires Upgrade! For tree menu, what font awesome icon to use for closed menu.';

    const MM_SETTING_MENU_TREE_OPENED = 'Tree Opened Icon';
    const MM_SETTING_MENU_TREE_OPENED_TIP = 'Requires Upgrade! For tree menu, what font awesome icon to use for opened menu.';

    const MM_SETTING_TAB_MENU = 'Menu';
    const MM_SETTING_TAB_MAIN = 'Main Menu Items';
    const MM_SETTING_TAB_CHILD = 'Child Menu Items';
    const MM_SETTING_TAB_CSS = 'Custom CSS';

    const MM_SETTING_BAR_BG = 'Bar Background Color';
    const MM_SETTING_BAR_BORDER_COLOR = 'Bar Border Color';
    const MM_SETTING_HAM_COLOR = 'Hamburger Menu Color';
    const MM_SETTING_HAM_BG = 'Hamburger Background';
    const MM_SETTING_HAM_CODE= 'Hamburger Menu Code';
    const MM_SETTING_HAM_CODE_TIP = 'Code to show text/icon for hamburger menu.';

    const MM_SETTING_PADDING = 'Padding';
    const MM_SETTING_MARGIN = 'Margin';
    const MM_SETTING_CORNER = 'Corner Radius';
    const MM_SETTING_BORDER = 'Border Width';
    const MM_SETTING_ALIGN = 'Align Items';
    const MM_SETTING_ALIGN_LEFT = 'Left';
    const MM_SETTING_ALIGN_CENTER = 'Center';
    const MM_SETTING_ALIGN_RIGHT = 'Right';

    const MM_SETTING_FONT = 'Menu Font';
    const MM_SETTING_FONT_TIP = 'If blank, default store font will be used.';
    const MM_SETTING_FONT_SIZE = 'Menu Font Size';
    const MM_SETTING_FONT_SIZE_TIP = 'If blank, default store font sizing will be used.';
    const MM_SETTING_COLOR = 'Link Color';
    const MM_SETTING_HOVER = 'Link Hover Color';
    const MM_SETTING_BG = 'Background Color';
    const MM_SETTING_BG_HOVER = 'Background Hover Color';
    const MM_SETTING_BORDER_COLOR = 'Border Color';
    const MM_SETTING_BORDER_HOVER_COLOR = 'Border Hover Color';
    const MM_SETTING_ITEM_WIDTH = 'Item Width';
    const MM_SETTING_ITEM_WIDTH_AUTO = 'Auto';
    const MM_SETTING_ITEM_WIDTH_FILL = 'Fill';
    const MM_SETTING_HAM_ALIGN = 'Align Hamburger Menu';
    const MM_SETTING_HAM_SHOW = 'Hamburger Show';
    const MM_SETTING_HAM_SHOW_NEVER = 'Never';
    const MM_SETTING_HAM_SHOW_SMALL = 'Small Screen Width';
    const MM_SETTING_HAM_SHOW_MEDIUM = 'Medium Screen Width';
    const MM_SETTING_HAM_SHOW_LARGE = 'Large Screen Width';
    const MM_SETTING_HAM_SHOW_XLARGE = 'Extra Large Screen Width';

    const MM_SETTING_SUB_FONT = 'Sub-Menu Font';
    const MM_SETTING_SUB_FONT_TIP = 'If blank, default store font will be used.';
    const MM_SETTING_SUB_FONT_SIZE = 'Sub-Menu Font Size';
    const MM_SETTING_SUB_FONT_SIZE_TIP = 'If blank, default store font sizing will be used.';

    const MM_SETTING_CSS_DESC = 'Enter custom css below and your code will be appended to the menu css.<br />Prepend your css assignments with the menu id';
