<?php

    const MM_PREVIEW_SINGLE_TITLE = 'Single Menu Preview';
    const MM_PREVIEW_ALL_TITLE = 'Preview All Active Menus';
    const MM_PREVIEW_NOTE = 'Note: If you do not see a menu, make sure you have added it to a location.';
    const TEXT_SEARCH_PLACEHOLDER = 'Search';
