<?php

    const MM_NEW_HEADING = 'Create New Menu';
    const MM_NEW_NAME = 'Menu Name';
    const MM_NEW_CREATE_NOW = 'Create Menu';
    const MM_NEW_TIP = 'Enter a name for your menu and then click Create Menu';