<?php

    const MM_BACKUP_BACKUPS = 'Backups';
    const MM_BACKUP_MENU_SELECT = 'Menu to backup';
    const MM_BACKUP_MENU_ALL = 'All Menus';
    const MM_BACKUP_NOW = 'Backup Now';
    const MM_BACKUP_EXISTING = 'Existing Backups';
    const MM_BACKUP_EXISTING_DESC = 'Restoring a backup will add the menu(s) to your current menus. No data will be overwritten, but menu(s) from the backup will be restored as new menus.';
    const MM_RESTORE_NOW = 'Restore Now';
