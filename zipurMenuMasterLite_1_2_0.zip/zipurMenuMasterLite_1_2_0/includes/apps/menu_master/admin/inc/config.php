<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $modnum = zipVarCheck( 'modnum', 0, 'FILTER_VALIDATE_INT', 0 );
    $onoff  = zipVarCheck( 'onoff', 0, 'FILTER_VALIDATE_INT', 0 );

?>
<script>
    function mm_mod_change(mod, onoff) {
        window.location.href = 'zipur_menu_master.php?config=1&modnum=' + mod + '&onoff=' + onoff;
    }
</script>
<?php

    if ( ! empty( $modnum ) ) {
        mm_menu_install( $modnum, $onoff );
    }

    if ( $modnum == 1 ) {
        mm_config_configuration( $modnum, $onoff, 'MODULE_NAVBAR_MM_MENU_', 'MODULE_NAVBAR_', [
            [
                'configuration_title'       => 'Enable Module',
                'configuration_key'         => 'MODULE_NAVBAR_MM_MENU_STATUS',
                'configuration_value'       => 'True',
                'configuration_description' => 'Do you want to add the module to your Navbar?',
                'configuration_group_id'    => 6,
                'sort_order'                => 1,
                'set_function'              => 'tep_cfg_select_option([\'True\', \'False\'],',
            ],
            [
                'configuration_title'       => 'Content Placement Group',
                'configuration_key'         => 'MODULE_NAVBAR_MM_MENU_CONTENT_PLACEMENT',
                'configuration_value'       => 'Left',
                'configuration_description' => 'This is a special module that must be placed in the Home Group. Lowest is loaded first, per Group.',
                'configuration_group_id'    => 6,
                'sort_order'                => 2,
                'set_function'              => 'tep_cfg_select_option([\'Left\', \'Center\', \'Right\'],',
            ],
            [
                'configuration_title'       => 'Sort Order',
                'configuration_key'         => 'MODULE_NAVBAR_MM_MENU_SORT_ORDER',
                'configuration_value'       => '--sort--',
                'configuration_description' => 'Sort order of display. Lowest is displayed first.',
                'configuration_group_id'    => 6,
                'sort_order'                => 3,
                'set_function'              => '',
            ],
        ] );
    } else if ( $modnum == 2 ) {
        mm_config_configuration( $modnum, $onoff, 'MODULE_BOXES_MM_MENU_LEFT_', 'MODULE_BOXES_', [

            [
                'configuration_title'       => 'Enable Menu Master Module',
                'configuration_key'         => 'MODULE_BOXES_MM_MENU_LEFT_STATUS',
                'configuration_value'       => 'True',
                'configuration_description' => 'Do you want to add the module to your shop?',
                'configuration_group_id'    => 6,
                'sort_order'                => 1,
                'set_function'              => 'tep_cfg_select_option([\'True\', \'False\'],',
            ],
            [
                'configuration_title'       => 'Content Placement',
                'configuration_key'         => 'MODULE_BOXES_MM_MENU_LEFT_CONTENT_PLACEMENT',
                'configuration_value'       => 'Left Column',
                'configuration_description' => 'Should the module be loaded in the left or right column?',
                'configuration_group_id'    => 6,
                'sort_order'                => 2,
                'set_function'              => 'tep_cfg_select_option([\'Left Column\'],',
            ],
            [
                'configuration_title'       => 'Sort Order',
                'configuration_key'         => 'MODULE_BOXES_MM_MENU_LEFT_SORT_ORDER',
                'configuration_value'       => '--sort--',
                'configuration_description' => 'Sort order of display. Lowest is displayed first.',
                'configuration_group_id'    => 6,
                'sort_order'                => 3,
                'set_function'              => '',
            ],
        ] );
    } else if ( $modnum == 3 ) {
        mm_config_configuration( $modnum, $onoff, 'MODULE_BOXES_MM_MENU_RIGHT_', 'MODULE_BOXES_', [
            [
                'configuration_title'       => 'Enable Menu Master Module',
                'configuration_key'         => 'MODULE_BOXES_MM_MENU_RIGHT_STATUS',
                'configuration_value'       => 'True',
                'configuration_description' => 'Do you want to add the module to your shop?',
                'configuration_group_id'    => 6,
                'sort_order'                => 1,
                'set_function'              => 'tep_cfg_select_option([\'True\', \'False\'],',
            ],
            [
                'configuration_title'       => 'Content Placement',
                'configuration_key'         => 'MODULE_BOXES_MM_MENU_RIGHT_CONTENT_PLACEMENT',
                'configuration_value'       => 'Right Column',
                'configuration_description' => 'Should the module be loaded in the left or right column?',
                'configuration_group_id'    => 6,
                'sort_order'                => 2,
                'set_function'              => 'tep_cfg_select_option([\'Right Column\'],',
            ],
            [
                'configuration_title'       => 'Sort Order',
                'configuration_key'         => 'MODULE_BOXES_MM_MENU_RIGHT_SORT_ORDER',
                'configuration_value'       => '--sort--',
                'configuration_description' => 'Sort order of display. Lowest is displayed first.',
                'configuration_group_id'    => 6,
                'sort_order'                => 3,
                'set_function'              => '',
            ],
        ] );
    } else if ( $modnum == 4 ) {
        mm_config_configuration( $modnum, $onoff, 'MODULE_CONTENT_HEADER_MM_MENU_', 'MODULE_CONTENT_HEADER_', [

            [
                'configuration_title'       => 'Enable Header Menu Master Module',
                'configuration_key'         => 'MODULE_CONTENT_HEADER_MM_MENU_STATUS',
                'configuration_value'       => 'True',
                'configuration_description' => 'Do you want to enable the Menu Master content module?',
                'configuration_group_id'    => 6,
                'sort_order'                => 1,
                'set_function'              => 'tep_cfg_select_option([\'True\', \'False\'],',
            ],
            [
                'configuration_title'       => 'Content Width',
                'configuration_key'         => 'MODULE_CONTENT_HEADER_MM_MENU_CONTENT_WIDTH',
                'configuration_value'       => '12',
                'configuration_description' => 'What width container should the content be shown in?',
                'configuration_group_id'    => 6,
                'sort_order'                => 2,
                'set_function'              => 'tep_cfg_select_option([\'12\', \'11\', \'10\', \'9\', \'8\', \'7\', \'6\', \'5\', \'4\', \'3\', \'2\', \'1\'],',
            ],
            [
                'configuration_title'       => 'Sort Order',
                'configuration_key'         => 'MODULE_CONTENT_HEADER_MM_MENU_SORT_ORDER',
                'configuration_value'       => '--sort--',
                'configuration_description' => 'Sort order of display. Lowest is displayed first.',
                'configuration_group_id'    => 6,
                'sort_order'                => 3,
                'set_function'              => '',
            ],
        ] );
    } else if ( $modnum == 10 ) {
        mm_config_configuration( $modnum, $onoff, 'MODULE_HEADER_TAGS_MM_MENU_', 'MODULE_HEADER_TAGS_', [

            [
                'configuration_title'       => 'Enable Menu Master Module',
                'configuration_key'         => 'MODULE_HEADER_TAGS_MM_MENU_STATUS',
                'configuration_value'       => 'True',
                'configuration_description' => 'Do you want to allow Menu Master tags to be added to the page header This is required for all menus to work?',
                'configuration_group_id'    => 6,
                'sort_order'                => 1,
                'set_function'              => 'tep_cfg_select_option([\'True\', \'False\'], ',
            ],
            [
                'configuration_title'       => 'Sort Order',
                'configuration_key'         => 'MODULE_HEADER_TAGS_MM_MENU_SORT_ORDER',
                'configuration_value'       => '990',
                'configuration_description' => 'Sort order of display. Lowest is displayed first.',
                'configuration_group_id'    => 6,
                'sort_order'                => 2,
                'set_function'              => '',
            ],
        ] );
    } else if ( $modnum == 99 ) {
        /*  mm_config_configuration( $modnum, $onoff, '', '', [

              [
                  'configuration_title'       => '',
                  'configuration_key'         => '',
                  'configuration_value'       => '',
                  'configuration_description' => '',
                  'configuration_group_id'    => 6,
                  'sort_order'                => 2,
                  'set_function'              => '',
              ],
          ] );*/
    }

    $mod1 = mm_config_module_files( [
        'includes/modules/navbar/nb_mm_menu.php',
        'includes/modules/navbar/templates/tpl_nb_mm_menu.php',
        'includes/languages/english/modules/navbar/nb_mm_menu.php',
    ] );
    $mod2 = mm_config_module_files( [
        'includes/modules/boxes/bm_mm_menu_left.php',
        'includes/modules/boxes/templates/tpl_bm_mm_menu_left.php',
        'includes/languages/english/modules/boxes/bm_mm_menu_left.php',
    ] );
    $mod3 = mm_config_module_files( [
        'includes/modules/boxes/bm_mm_menu_right.php',
        'includes/modules/boxes/templates/tpl_bm_mm_menu_right.php',
        'includes/languages/english/modules/boxes/bm_mm_menu_right.php',
    ] );
    $mod4 = mm_config_module_files( [
        'includes/modules/content/header/cm_header_mm_menu.php',
        'includes/modules/content/header/templates/tpl_cm_header_mm_menu.php',
        'includes/languages/english/modules/content/header/cm_header_mm_menu.php',
    ] );

    $mod10 = mm_config_module_files( [
        'includes/modules/header_tags/ht_mm_menu.php',
        'includes/languages/english/modules/header_tags/ht_mm_menu.php',
    ] );

    $mod1 .= mm_config_module_status( 'MODULE_NAVBAR_MM_MENU_STATUS', 1 );
    $mod2 .= mm_config_module_status( 'MODULE_BOXES_MM_MENU_LEFT_STATUS', 2 );
    $mod3 .= mm_config_module_status( 'MODULE_BOXES_MM_MENU_RIGHT_STATUS', 3 );
    $mod4 .= mm_config_module_status( 'MODULE_CONTENT_HEADER_MM_MENU_STATUS', 4 );
    $mod10 .= mm_config_module_status( 'MODULE_HEADER_TAGS_MM_MENU_STATUS', 10 );

    $hook8  = mm_config_hook_status( 'siteWide/mmMenuAboveFooter' );

?>
<div class="container p-4">
    <h3 class="text-primary"><?= MM_CONFIG_TITLE ?></h3>
    <div class="row">
        <div class="col-12 col-md-6">
            <h4 class="my-4"><?= MM_CONFIG_REQUIRED ?></h4>
            <div class="text-danger mb-4"><small><?= MM_CONFIG_REQUIRED_DESC ?></small></div>
            <ul class="m-0">
                <li class="mt-2 mb-4">Header Tag - Menu Master Module (required) <ul><li><?= $mod10 ?></li></ul></li>
                <li class="mt-2 mb-4">Navbar - Menu Master Module <ul><li><?= $mod1 ?></li></ul></li>
                <li class="mt-2 mb-4">Box - Left - Menu Master Module <ul><li><?= $mod2 ?></li></ul></li>
                <li class="mt-2 mb-4">Box - Right - Menu Master Module <ul><li><?= $mod3 ?></li></ul></li>
                <li class="mt-2 mb-4">Content - Header - Menu Master Module <ul><li><?= $mod4 ?></li></ul></li>
            </ul>
        </div>
        <div class="col-12 col-md-6">
            <h4 class="my-4">Required Hooks</h4>
            <ul>
                <li class="mt-2 mb-4">Menu Master Above Footer <?= $hook8 ?></li>
            </ul>

            <?= mm_upgrade_pro_box(); ?>
        </div>
    </div>


</div>