<?php

    

/*
* $Id: reg.php
* $Loc: /includes/apps/menu_master/admin/inc/
*
* Name: zipurMenuMasterLite
* Version: 1.2.0
* Release Date: 01/08/2022
* Author: Preston Lord
* 	 phoenixaddons.com / @zipurman / plord@inetx.ca
*
* License: Commercial License
* 
* Cannot be distributed
*  
* Commercial use allowed
*  
* Cannot modify source-code for any purpose (cannot create derivative works)
*
* Comments: Copyright (c) 2021: Preston Lord - @zipurman - Intricate Networks Inc.
* 
* All rights reserved.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
* (Packaged with Zipur Bundler v2.0.2)
*/





    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $osprod         = 'CE Phoenix';
    $version        = tep_get_version();
    $zipFileVersion = zipGetFileVersion( __FILE__ );

    $previewall  = zipVarCheck( 'previewall', 0, 'FILTER_VALIDATE_INT', 0 );
    $menuinstall = zipVarCheck( 'menuinstall', 0, 'FILTER_VALIDATE_INT', 0 );
    $save        = zipVarCheck( 'save', 0, 'FILTER_VALIDATE_INT', 0 );
    $delete      = zipVarCheck( 'delete', 0, 'FILTER_VALIDATE_INT', 0 );
    $savestat    = zipVarCheck( 'savestat', - 1, 'FILTER_VALIDATE_INT', - 1 );
    $new         = zipVarCheck( 'new', 0, 'FILTER_VALIDATE_INT', 0 );
    $config      = zipVarCheck( 'config', 0, 'FILTER_VALIDATE_INT', 0 );
    $dupe        = zipVarCheck( 'dupe', 0, 'FILTER_VALIDATE_INT', 0 );
    $update      = zipVarCheck( 'update', 0, 'FILTER_VALIDATE_INT', 0 );
    $settings    = zipVarCheck( 'settings', 0, 'FILTER_VALIDATE_INT', 0 );
    $mm_id       = zipVarCheck( 'mm_id', 0, 'FILTER_VALIDATE_INT', 0 );
    $preview     = zipVarCheck( 'preview', 0, 'FILTER_VALIDATE_INT', 0 );

    $this_lang_file = 'main.php';

    if (!empty($new)){
        $this_lang_file = 'new.php';
    } else if (!empty($config)){
        $this_lang_file = 'config.php';
    } else if (!empty($dupe)){
        $this_lang_file = 'dupe.php';
    } else if (!empty($update)){
        $this_lang_file = 'update.php';
    } else if (!empty($settings)){
        $this_lang_file = 'preview.php';
        if ( file_exists( DIR_FS_CATALOG . 'includes/apps/menu_master/admin/languages/' . $language . '/' . $this_lang_file ) ) {
            require( DIR_FS_CATALOG . 'includes/apps/menu_master/admin/languages/' . $language . '/' . $this_lang_file );
        }
        $this_lang_file = 'settings.php';
    } else if (!empty($preview)){
        $this_lang_file = 'preview.php';
    } else if (!empty($backup)){
        $this_lang_file = 'backup.php';
    } else if (!empty($install)){
        $this_lang_file = 'install.php';
    } else if (!empty($uninstall)){
        $this_lang_file = 'uninstall.php';
    }

    if ( file_exists( DIR_FS_CATALOG . 'includes/apps/menu_master/admin/languages/' . $language . '/' . $this_lang_file ) ) {
        require( DIR_FS_CATALOG . 'includes/apps/menu_master/admin/languages/' . $language . '/' . $this_lang_file );
    }

    if ( $mm_is_installed ) {

        if ( empty( $_SESSION['menumaster'] ) ) {
            $_SESSION['menumaster'] = [];
        }

        if ( ! empty( $mm_id ) ) {
            $_SESSION['menumaster']['id'] = $mm_id;
        }

        if ( ! empty( $_SESSION['menumaster']['id'] ) ) {
            $menuMaster->loadMenu( $_SESSION['menumaster']['id'] );
        }

        $menuMaster->getMenus();//to find out if any created for interface
    }
