<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

?>
    <div class="col-auto">
        <?php
            if ( $savestat == 0 ) {
                zipAlert( MM_SAVE_FAIL, 'danger' );
            } else if ( $savestat == 1 ) {
                zipAlert( MM_SAVE_SUCCESS, 'success' );
            }
        ?>
    </div>
<?php

