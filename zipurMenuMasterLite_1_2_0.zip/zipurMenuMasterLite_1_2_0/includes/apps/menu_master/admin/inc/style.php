<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

?>
<style>
    #MenuItems {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }
    #MenuItems .btn:hover {
        text-decoration: none;
    }
    #MenuItems ul {
        list-style-type: none;
        border: 0px !important;
        margin-bottom: 6px;
        margin-top: 2px;
    }
    #MenuItems li {
        border: 0px !important;
        border-radius: 2px !important;
        padding: 2px;
    }
    #MenuItems .card-header {
        border: 1px solid #ccc !important;
        border-radius: 2px !important;
        margin-top: 2px;
    }
    #MenuItems .card-body, #MenuItems .card-footer {
        border: 1px solid #ccc !important;
    }
    .mm-item i.fas {
        color: #ccc;
    }
    .mm-item i.fadown {
        position: absolute;
        right: 10px;
        top: 12px;
        font-size: 1.4em;
    }
    .fadown:before {
        content: "\f106";
    }
    .fadown.collapsed:before {
        content: "\f107";
    }
    input[type=text] {
        width: 60%;
        min-width: 140px;
        max-width: 99%;
    }
    select {
        width: 60% !important;
        min-width: 200px;
    }
    input::placeholder {
        color: #aaa !important;
    }
    .mmcolorpicker {
        width: 190px !important;
        min-width: 190px !important;
    }
    .mmcolorpicker input {
        width: 120px !important;
        min-width: 120px !important;
        font-size: 0.7em;
        letter-spacing: 0px;
        padding: 16px 1px !important;
    }
    .mmcolorpicker i {
        border: 1px solid #999;
        width: 16px;
        height: 16px;
    }
    .mmcolorpicker-small {
        width: 75px !important;
        min-width: 75px !important;

    }
    .mmcolorpicker-small input {
        width: 40px !important;
        min-width: 40px !important;
        font-size: 0.6em;
        padding: 0px 1px;
    }
    .mmcolorpicker-small i {
        border: 1px solid #999;
        width: 16px;
        height: 16px;
        padding: 0px;

    }
    .mmcolorpicker-small .input-group-append span {
        margin: 1px !important;
        padding: 3px !important;
    }
    .mm-image-clicker {
        border: 1px solid #ddd;
        color: #ddd;
        text-align: center;
        position: relative;
        width: 80px;
        height: 80px;
        font-size: 1em;
        padding: 16px;
        background-size: cover !important;
        background-repeat: no-repeat !important;
    }
    .mm-image-stat {
        position: absolute;
        left: 30px;
        top: 30px;
        width: 20px;
        height: 20px;
        border: 1px solid #ccc;
        color: #ccc;
        padding: 0px;
        line-height: 1em;
        background: #dddddddd;
        cursor: pointer;
    }
    .mm-image-text1 {
        position: absolute;
        top: 0px;
        background: #555;
        color: #ddd;
        padding: 0px;
        font-size: 0.6em;
        width: 100%;
        left: 0px;
    }
    .pixel4 {
        width: 100% !important;
        min-width: unset !important;
    }
    .pixel4 input {
        width: 40px !important;
        min-width: 40px !important;
        padding: 1px !important;
        text-align: center;

    }
    .mm-pagemark {
        color: #aaa;
        font-size: 0.8em;
    }
    .mm-icons {
        display: inline-block;
    }
    .mm-icons i {
        margin-left: 10px;
    }
    .pixel4 .form-control::placeholder {
        font-size: 0.5em;
    }
    #mm_locations {
        font-size: 0.8em;
        width: 150px !important;
        min-width: 150px !important;
    }
    #mm_locations_box {
        display: inline-block;
    }
    #mm_item_link, #mm_item_name, .mm_item_name, .mm_item_link {
        font-size: 0.8em;
        padding: 2px;
        width: 70% !important;
    }
    .mm_item_name_block {
        width: 50% !important;
    }
    input.mm_item_name::placeholder {
        color: #333 !important;
    }
    .mm_item_name_block_append{
        cursor: pointer;
    }
    .mm-hidden-item{
        display: none;
    }
    .item_breakpoint_hide .btn-secondary.active {
        background-color: #007bff !important;
    }
    .grip-lines-top:before{
        position: relative;
        top: -10px;
    }
    .grip-lines-bottom:before{
        position: relative;
        top: +10px;
    }
    /*Hide mega menu if on submenus*/
    #MenuItems ul .mm_mega_menu-control, #MenuItems ul .fa-th-large{
        display: none;
    }
</style>
