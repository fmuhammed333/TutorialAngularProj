<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

?>
<form method="post" action="zipur_menu_master.php" name="zipur_menu_master_new">
    <div class="container">
        <div class="row">
            <div class="col col-12">
                <h5><?= MM_NEW_HEADING ?></h5>
                <div class="border p-2 bg-light">
                    <div class="row">
                        <div class="col-6">
                            <?= MM_NEW_NAME ?>
                            <input type="text" class="form-control" id="mm_name" name="mm_name" value="" required/>
                        </div>
                        <div class="col-3">
                            <button type="button" onClick="formwatchsomethingChanged = false; document.zipur_menu_master_new.submit();" class="btn btn-sm border text-primary border-primary bg-light">
                                <?= MM_NEW_CREATE_NOW ?>
                            </button>
                        </div>
                        <div class="col-3 text-right">
                            <button type="button" class="btn btn-sm border text-secondary border-secondary bg-light" onClick="mm_main();">
                                <?= MM_CANCEL ?>
                            </button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <small class="text-muted"><?= MM_NEW_TIP ?></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" name="save" value="1"/>
    <input type="hidden" name="new" value="1"/>
</form>

<div class="row mt-4 p-4 border bg-light">
    <div class="col-12 text-left my-4 my-md-0">
        <a href="zipur_menu_master.php?backup=1" class="" style="color: #666;" data-toggle="tooltip" data-placement="top" title="<?= MM_BACKUP_RESTORE_TIP ?>"><i class="fas fa-archive"></i>
            <?= MM_BACKUP_RESTORE ?></a>
    </div>
</div>