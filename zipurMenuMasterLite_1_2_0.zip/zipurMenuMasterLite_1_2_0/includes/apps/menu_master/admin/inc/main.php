<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    if ( empty( $menuMaster->menus ) ) {
        ?>
        <div class="container p-4">
            <div class="border p-2 bg-light">
                <div class="row p-2">
                    <div class="col-12">
                        <h1><i class="fas fa-door-open text-primary"></i> <?= MM_WELCOME ?></h1>
                    </div>
                </div>
                <div class="row p-2">
                    <?= MM_WELCOME_DETAILS ?>
                    <div class="col-4 text-center">
                        <img src="<?= DIR_WS_CATALOG ?>includes/apps/menu_master/admin/images/menu_master.png" style="border: 0px; width: 100%; max-width: 100%; border-radius: 10px;"/>
                    </div>
                </div>

            </div>
        </div>
        <?php
    } else {
        ?>
        <div class="row">
            <div class="col-12 col-md-3">
                <?php
                    if ( ! empty( $_SESSION['menumaster']['id'] ) ) {
                        require( dirname( __FILE__ ) . '/menu_items.php' );
                    }
                ?>
            </div>
            <div class="col-12 col-md-9 my-4 my-md-0">
                <?php
                    require( dirname( __FILE__ ) . '/menu_layout.php' );
                ?>
            </div>
        </div>
        <div class="row mt-4 p-4 border bg-light">
            <div class="col-12 col-md-6 text-left my-4 my-md-0">
                <a href="zipur_menu_master.php?backup=1" class="" style="color: #666;" data-toggle="tooltip" data-placement="top" title="<?= MM_BACKUP_RESTORE_TIP ?>"><i class="fas fa-archive"></i>
                    <?= MM_BACKUP_RESTORE ?></a>
            </div>
            <div class="col-12 col-md-6 text-right my-4 my-md-0">
                <a href="zipur_menu_master.php?uninstall=1" class="" style="color: #bbb;" data-toggle="tooltip" data-placement="top" title="<?= MM_UNINSTALL_TIP ?>"><i class="fas fa-trash-alt"></i>
                    <?= MM_UNINSTALL ?></a>
            </div>
        </div>
        <?php
    }