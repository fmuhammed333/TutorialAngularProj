<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

?>
<h5><?= MM_ITEMS_ADD_TITLE ?></h5>
<div class="accordion" id="newMenuItems">

    <?php

        $categorystat = '';
        $categorystat2 = 'show';

        if ( zipCheckDBTableExists( 'pages' ) ) {

            $categorystat = 'collapsed';
            $categorystat2 = '';

            ?>
            <div class="card">
                <div class="card-header p-1" id="newMenuItems1">
                    <h2 class="mb-0">
                        <button class="btn btn-link btn-block text-left text-muted" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <i class="far fa-file-alt"></i> <?= MM_ITEMS_INFO_PAGES ?>
                        </button>
                    </h2>
                </div>

                <div id="collapseOne" class="collapse show" aria-labelledby="newMenuItems1" data-parent="#newMenuItems">
                    <div class="card-body px-3 py-2">
                        <div style="overflow: auto; max-height: 200px;">
                            <?php

                                //pages
                                $pages_query = tep_db_query( "SELECT p.pages_id, pd.navbar_title FROM pages p, pages_description pd  WHERE p.pages_id=pd.pages_id AND languages_id={$_SESSION['languages_id']} ORDER BY pd.navbar_title" );

                                while ( $result = tep_db_fetch_array( $pages_query ) ) {
                                    ?>
                                    <label class="p-0 m-0" for="info-page-item-<?= $result['pages_id'] ?>">
                                        <input type="checkbox" value="<?= $result['pages_id'] ?>" class="info-page-item" id="info-page-item-<?= $result['pages_id'] ?>" data-name="<?= $result['navbar_title'] ?>" data-id="<?= $result['pages_id'] ?>"/>
                                        <small><?= $result['navbar_title'] ?></small>
                                    </label>
                                    <br/>
                                    <?php
                                }
                            ?>
                        </div>
                        <div class="row border-top pt-2 mt-2">
                            <div class="col-12 col-lg-6">
                                <a href="javascript: mm_toggle_all('collapseOne');"><small><i class="far fa-square"></i> <?= MM_ITEMS_SELECT_ALL ?>
                                    </small></a>
                            </div>
                            <div class="col-12 col-lg-6">
                                <button type="button" class="btn btn-sm border text-primary border-primary bg-light" onClick="mm_add_selected('collapseOne');">
                                    <i class="fas fa-plus"></i> <?= MM_ITEMS_SELECTED ?>
                                </button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <?php
        }

    ?>
    <div class="card">
        <div class="card-header p-1" id="newMenuItems2">
            <h2 class="mb-0">
                <button class="btn btn-link btn-block text-left <?= $categorystat ?>  text-muted" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    <i class="fas fa-sitemap"></i> <?= MM_ITEMS_CATEGORIES ?>
                </button>
            </h2>
        </div>
        <div id="collapseTwo" class="collapse <?= $categorystat2 ?>" aria-labelledby="newMenuItems2" data-parent="#newMenuItems">
            <div class="card-body px-3 py-2">
               <?= mm_upgrade_this_pro_box() ?>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header p-1" id="newMenuItems3">
            <h2 class="mb-0">
                <button class="btn btn-link btn-block text-left collapsed  text-muted" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    <i class="fas fa-cubes"></i> <?= MM_ITEMS_PRODUCTS ?>
                </button>
            </h2>
        </div>
        <div id="collapseThree" class="collapse" aria-labelledby="newMenuItems3" data-parent="#newMenuItems">
            <div class="card-body px-3 py-2">
                <?= mm_upgrade_this_pro_box() ?>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header p-1" id="newMenuItems4">
            <h2 class="mb-0">
                <button class="btn btn-link btn-block text-left collapsed  text-muted" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                    <i class="fas fa-link"></i> <?= MM_ITEMS_CUSTOM ?>
                </button>
            </h2>
        </div>
        <div id="collapseFour" class="collapse" aria-labelledby="newMenuItems4" data-parent="#newMenuItems">
            <div class="card-body px-3 py-2">
                <div>
                    <div class="form-group row">
                        <label for="mm_item_name" class="text-muted pl-2 col-form-label"><small><?= MM_ITEMS_TEXT ?>
                                :</small></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="mm_item_name" style="width: 90% !important;" value="" placeholder="<?= MM_ITEMS_TEXT_TIP ?>"/>

                        </div>
                    </div>
                </div>
                <div>
                    <div class="form-group row">
                        <label for="mm_item_link" class="text-muted pl-2 col-form-label"><small><?= MM_ITEMS_URL ?>
                                :</small></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="mm_item_link" style="width: 90% !important;" value="" placeholder="https://www.test.com"/>
                        </div>
                    </div>
                </div>
                <div class="row border-top pt-2 mt-2">
                    <div class="col-6">
                    </div>
                    <div class="col-6">
                        <button type="button" class="btn btn-sm border text-primary border-primary bg-light" onClick="mm_add_selected('collapseFour');">
                            <i class="fas fa-plus"></i> <?= MM_ITEMS_ADD ?>
                        </button>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header p-1" id="newMenuItems5">
            <h2 class="mb-0">
                <button class="btn btn-link btn-block text-left collapsed  text-muted" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                    <i class="fas fa-puzzle-piece"></i> <?= MM_ITEMS_PHOENIX_PAGES ?>
                </button>
            </h2>
        </div>
        <div id="collapseFive" class="collapse" aria-labelledby="newMenuItems5" data-parent="#newMenuItems">
            <div class="card-body px-3 py-2">
                <div style="overflow: auto; max-height: 200px;">
                    <?php
                        //pages

                        $id = 1;
                        foreach ( $menuMaster->phoenix_pages as $item ) {
                            if ( ! empty( $item['id'] ) ) {
                                ?>
                                <label class="p-0 m-0" for="phoenix-item-<?= $id ?>">
                                    <input type="checkbox" value="<?= $id ?>" class="phoenix-item" id="phoenix-item-<?= $id ?>" data-name="<?= $item['name'] ?>" data-id="<?= $item['id'] ?>"/>
                                    <small><?= $item['name'] ?></small>
                                </label>
                                <br/>
                                <?php
                                $id ++;
                            }
                        }
                    ?>
                </div>
                <div class="row border-top pt-2 mt-2">
                    <div class="col-12 col-lg-6">
                        <a href="javascript: mm_toggle_all('collapseFive');"><small><i class="far fa-square"></i> <?= MM_ITEMS_SELECT_ALL ?>
                            </small></a>
                    </div>
                    <div class="col-12 col-lg-6">
                        <button type="button" class="btn btn-sm border text-primary border-primary bg-light" onClick="mm_add_selected('collapseFive');">
                            <i class="fas fa-plus"></i> <?= MM_ITEMS_SELECTED ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header p-1" id="newMenuItems6">
            <h2 class="mb-0">
                <button class="btn btn-link btn-block text-left collapsed  text-muted" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                    <i class="fas fa-cogs"></i> <?= MM_ITEMS_SPECIAL_ITEMS ?>
                </button>
            </h2>
        </div>
        <div id="collapseSix" class="collapse" aria-labelledby="newMenuItems6" data-parent="#newMenuItems">
            <div class="card-body px-3 py-2">
                <?= mm_upgrade_this_pro_box() ?>
            </div>
        </div>
    </div>
</div>
