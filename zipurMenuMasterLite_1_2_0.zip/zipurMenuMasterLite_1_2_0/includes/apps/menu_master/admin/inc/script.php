<?php
    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    if ( ! empty( $menuMaster->menu['color_type'] ) ) {
        $mm_color_alpha  = 'true';
        $mm_color_format = '"rgb"';
    } else {
        $mm_color_alpha  = 'false';
        $mm_color_format = '"hex"';
    }
?>

<script>

    function mm_color_pickers() {
        $('.mmcolorpicker input').colorpicker({
            useAlpha: <?= $mm_color_alpha ?>,
            format: <?= $mm_color_format ?>
        });

        $(".mmcolorpicker input").change(function () {
            $(this).parent().find('i').css('background', $(this).val());
        });
        $(".mmcolorpicker i").click(function () {
            $(this).parent().parent().parent().find('input').focus();
        });
    }
    var mm_menu_data = {};
    formwatchsomethingChanged = false;

    $(function () {
        var startwatch = setTimeout(function () {
            $("input, select, textarea").change(function () {
                formwatchsomethingChanged = true;
            });
        }, 1000);


        $("#mm_products_search").bind('keypress', function (e) {
            if (e.keyCode == 13) {
                mm_nav_products();
            }
        });

        //custom menu item link hover colors
        $(".mm-hover-link").bind("mouseover", function () {
            hcolor = $(this).attr("data-color-hover");
            bghcolor = $(this).attr("data-color-bg-hover");
            if (hcolor != '') {
                $(this).attr('style', function (i, s) {
                    return (s || '') + 'color: ' + hcolor + ' !important;'
                });
            }
            if (bghcolor != '') {
                $(this).attr('style', function (i, s) {
                    return (s || '') + 'background: ' + bghcolor + ' !important;'
                });
            }
        });
        $(".mm-hover-link").bind("mouseout", function () {
            oldcolor = $(this).attr("data-color-hover-backup");
            bgoldcolor = $(this).attr("data-color-bg-hover-backup");
            $(this).attr('style', function (i, s) {
                return (s || '') + 'color: ' + oldcolor + ' !important;'
            });
            $(this).attr('style', function (i, s) {
                return (s || '') + 'background: ' + bgoldcolor + ' !important;'
            });
        });


    });

    $(window).bind('beforeunload', function (e) {

        if (formwatchsomethingChanged) {
            return true;
        }
        e = null;
    });

    function mm_new() {
        window.location.href = 'zipur_menu_master.php?new=1';
    }

    function mm_config() {
        window.location.href = 'zipur_menu_master.php?config=1';
    }

    function mm_delete(menuid) {
        if (confirm('Delete this menu and all of it\'s data?')) {
            window.location.href = 'zipur_menu_master.php?delete=1&save=1&menuid=' + menuid;
        }
    }

    function mm_upgrade() {
        window.location.href = 'zipur_menu_master.php?upgrade=1';
    }

    function mm_duplicate() {
        window.location.href = 'zipur_menu_master.php?dupe=1';
    }

    function mm_export() {
        formwatchsomethingChanged = false;
        $("#mm_export").val('1');
        document.zipur_menu_master_settings.submit();
        $("#mm_export").val('0');
    }

    function mm_import() {
        $("#zipur_menu_master_importer").css("display", "flex");
    }

    function mm_import_now() {
        var mm_import_file = $("#mm_import_file").val();
        var mm_import_template = $("#mm_import_template").val();
        if (mm_import_file != '' || mm_import_template != '') {
            formwatchsomethingChanged = false;
            $("#zipur_menu_master_settings").attr("enctype", "multipart/form-data");
            $("#mm_import").val('1');
            document.zipur_menu_master_settings.submit();
        } else {
            alert('<?= MM_SCRIPT_CFG_ERROR ?>');
        }
    }

    function mm_preview(all) {
        window.location.href = 'zipur_menu_master.php?preview=1&previewall=' + all;
    }

    function mm_select(mm_id, preview) {
        window.location.href = 'zipur_menu_master.php?mm_id=' + mm_id + '&preview=' + preview;
    }

    function mm_main() {
        window.location.href = 'zipur_menu_master.php';
    }

    function mm_toggle_all(area) {
        $('#' + area + ' input[type=checkbox]').each(function () {
            if ($(this).is(':checked')) {
                $(this).prop('checked', false);
            } else {
                $(this).prop('checked', true);
            }
        });
    }

    function mm_update_item_title(identifier) {
        var mm_item_name = $("#mm_item_name" + identifier).val();
        var mm_item_name_lang = $("#mm_item_name" + identifier).attr("data-lang");
        $(".mm_item_name_block_hidden_" + identifier + "_" + mm_item_name_lang).val(mm_item_name);
        if (mm_item_name == '') {
            mm_item_name = $("#mm_item_name" + identifier).attr('placeholder');
        }
        $("#MenuItemTitle" + identifier).text(mm_item_name);
    }

    function mm_align_update(identifier, align) {
        $(".mm_align_" + identifier).removeClass("btn-secondary");
        $(".mm_align_" + identifier).addClass("bg-light");
        $("#mm_align_" + align + "_" + identifier).addClass("btn-secondary").removeClass("bg-light");
        $("#mm_item_align" + identifier).val(align);
    }

    function mm_valign_update(identifier, align) {
        $(".mm_valign_" + identifier).removeClass("btn-secondary");
        $(".mm_valign_" + identifier).addClass("bg-light");
        $("#mm_valign_" + align + "_" + identifier).addClass("btn-secondary").removeClass("bg-light");
        $("#mm_item_valign" + identifier).val(align);
    }

    function mm_update_item_icon(identifier) {
        var mm_fa_icon = $("#mm_fa_icon" + identifier).val();
        $(".mm_fa_icon_preview" + identifier).attr('class', "mx-2 mm_fa_icon_preview" + identifier);
        $(".mm_fa_icon_preview" + identifier).addClass(mm_fa_icon);
    }

    function mm_upload_image(identifier) {

        var postData = new FormData($("#mm_file_upload_form")[0]);

        $.ajax({
            type: 'POST',
            url: 'zipur_menu_master.php',
            processData: false,
            contentType: false,
            data: postData,
            dataType: 'json',
            success: function (json) {
                if (json.status == 1) {

                    formwatchsomethingChanged = false;
                    $(".mm-image-clicker" + identifier + " .mm-image-stat").removeClass('text-muted').addClass('text-danger');

                    $("#mm-image-name" + identifier).val(json.image);
                    $(".mm-image-clicker" + identifier).css('background', 'url(<?= DIR_WS_CATALOG ?>includes/apps/menu_master/images/' + json.image + ')');
                    $(".mm-image-clicker" + identifier + ' .mm-image-stat').text('X').css('line-height', '1.1em');
                    $("#MenuItemTitle" + identifier + " .mm-icons").append('<i class="fas fa-image text-warning"></i>');
                    $('#zipModal').modal('hide');

                } else {
                    mm_update_status('<?= MM_SCRIPT_IMAGE_ERROR ?>', 'danger');
                }
            }

        });

    }

    function mm_update_item_image(identifier, imageid, uuid) {

        $("#MenuItemTitle" + identifier + " .mm-icons i.fa-image").remove();

        if (imageid == '') {
            $('#zipModalLabel').text('<?= MM_SCRIPT_ADD_IMAGE ?>');

            $('#zipModal .modal-body').html('<?= MM_SCRIPT_UPLOAD_TEXT ?><br/><form enctype="multipart/form-data" id="mm_file_upload_form"  method="POST" ><input type="file" style="max-width: 80%;" name="mm_file_upload" /><input type="hidden" name="commtype" value="menu_image_upload"><input type="hidden" name="uuid" value="' + uuid + '"></form>');
            $('#zipModal .btn-primary').css("display", "inline-block");
            $('#zipModal .btn-primary').text('Upload Image Now').attr('onClick', 'mm_upload_image(\'' + identifier + '\');');
            $('#zipModal').modal('show');
        } else {
            $(".mm-image-clicker" + identifier + " .mm-image-stat").addClass('text-muted').addClass('border-muted');
            $(".mm-image-clicker" + identifier).css('background', 'none');
            $(".mm-image-clicker" + identifier + ' .mm-image-stat').text('+').css('line-height', '0.9em').attr('onclick', 'mm_update_item_image(\'' + identifier + '\', \'\', \'' + uuid + '\');');
            $("#mm-image-id" + identifier).val('');
            $("#mm-image-name" + identifier).val('');
        }

    }

    function mm_update_item_status(identifier) {
        var mm_item_status = $("#mm_item_status" + identifier).is(":checked");
        if (mm_item_status) {
            $("#MenuItemTitle" + identifier).removeClass('text-danger');
        } else {
            $("#MenuItemTitle" + identifier).addClass('text-danger');
        }
    }

    function mm_update_item_mobile(identifier) {
        var mm_item_mobile = $("#mm_item_mobile" + identifier).is(":checked");
        $("#MenuItemTitle" + identifier + " .mm-icons i.fa-mobile-alt").remove();
        if (!mm_item_mobile) {
            $("#MenuItemTitle" + identifier + " .mm-icons").append('<i class="fas fa-mobile-alt text-danger"></i>');
        }
    }

    function mm_update_restrict_basket(identifier) {
        var mm_restrict_basket = $("#mm_restrict_basket" + identifier).is(":checked");
        $("#MenuItemTitle" + identifier + " .mm-icons i.fa-shopping-cart").remove();
        if (mm_restrict_basket) {
            $("#MenuItemTitle" + identifier + " .mm-icons").append('<i class="fas fa-shopping-cart text-danger"></i>');
        }
    }

    function mm_update_mega_menu(identifier) {
        var mm_mega_menu = $("#mm_mega_menu" + identifier).is(":checked");
        $("#MenuItemTitle" + identifier + " .mm-icons i.fa-th-large").remove();
        if (mm_mega_menu) {
            $("#MenuItemTitle" + identifier + " .mm-icons").append('<i class="fas fa-th-large text-warning"></i>');
        }
    }

    function mm_update_restrict_loggedin(identifier) {
        var mm_restrict_loggedin1 = $("#mm_restrict_loggedin-1" + identifier).is(":checked");
        var mm_restrict_loggedin2 = $("#mm_restrict_loggedin-2" + identifier).is(":checked");
        $("#MenuItemTitle" + identifier + " .mm-icons i.fa-key").remove();
        if (!mm_restrict_loggedin1) {
            //guest
            $("#MenuItemTitle" + identifier + " .mm-icons").append('<i class="fas fa-key text-danger"></i>');
        }
        if (!mm_restrict_loggedin2) {
            //user
            $("#MenuItemTitle" + identifier + " .mm-icons").append('<i class="fas fa-key text-warning"></i>');
        }
    }

    function mm_delete_item(identifier) {
        $("#mm_item_card_" + identifier).fadeOut('slow', function () {
            $("#mm_item_card_" + identifier).remove();
        });
    }

    function mm_load_item_data(item, i, parent) {
        var tmpitem = {};
        tmpitem['id'] = $("#" + item).attr("data-id");
        tmpitem['type'] = $("#" + item).attr("data-type");
        tmpitem['uuid'] = $("#" + item).attr("data-uuid");

        $("#" + item + " > div .mm_item_name_block_hidden").each(function () {
            lang = $(this).attr('data-lang');
            tmpitem['name_' + lang] = $(this).val();
        });

        tmpitem['link'] = $("#" + item).find('input.mm_item_link:first').val();
        tmpitem['target'] = $("#" + item).find('input.mm_item_target:first').is(":checked");
        tmpitem['align'] = $("#" + item).find('input.mm_item_align:first').val();
        tmpitem['valign'] = $("#" + item).find('input.mm_item_valign:first').val();
        tmpitem['status'] = $("#" + item).find('input.mm_item_status:first').is(":checked");
        tmpitem['mobile'] = $("#" + item).find('input.mm_item_mobile:first').is(":checked");

        loggedin1 = $("#" + item).find('input.mm_restrict_loggedin-1:first').is(":checked");
        loggedin2 = $("#" + item).find('input.mm_restrict_loggedin-2:first').is(":checked");

        if (loggedin1 === false && loggedin2 === false) {
            loggedin = 3;
        } else if (loggedin1 === false) {
            //guest
            loggedin = 1;
        } else if (loggedin2 === false) {
            //user
            loggedin = 2;
        } else {
            loggedin = 0;
        }

        tmpitem['loggedin'] = loggedin;
        tmpitem['parent'] = parent;
        if (typeof mm_menu_data['items'][parent] === 'undefined') {
            mm_menu_data['items'][parent] = {};
            mm_menu_data['items'][parent]['items'] = {};
        }
        mm_menu_data['items'][parent]['items'][i] = tmpitem;

        var j = 1;
        var parentis = $("#" + item).attr("data-uuid");
        $("#" + item + " > ul > li").each(function () {
            mm_load_item_data($(this).attr('id'), j, parentis);
            j++;
        });

    }

    function mm_fade_alerts() {
        var mmfader = setTimeout(function () {
            jQuery(".alert").not(".alertstatic").fadeOut("slow", function () {
            });
        }, 2000);
    }

    function mm_update_status(text, status) {
        $("#mm-update-status").html('<div class="alert alert-' + status + ' p-1 m-1" role="alert">' + text + '</div>');
        mm_fade_alerts();
    }

    function mm_publish_menu(publishyn) {
        if (confirm('<?= MM_SCRIPT_PUBLISH_TEXT ?>')) {
            mm_save_menu(1);
        }
    }

    function mm_save_menu(publishyn) {

        //MenuItems
        mm_menu_data['items'] = {};

        var i = 1;
        $("#MenuItems > li").each(function () {
            mm_load_item_data($(this).attr('id'), i, '');
            i++;
        });

        var queryx = {};
        queryx['commtype'] = 'menu_items_save';
        queryx['publishyn'] = publishyn;
        queryx['mm_menu_data'] = JSON.stringify(mm_menu_data);

        $.ajax({
            type: "POST",
            url: "zipur_menu_master.php",
            data: queryx,
            dataType: 'json',
            success: function (json) {
                if (json.status == 1) {
                    formwatchsomethingChanged = false;
                    mm_update_status('<?= MM_SCRIPT_MENU_SAVED ?>', 'success');
                } else {
                    mm_update_status('<?= MM_SCRIPT_MENU_SAVE_FAIL ?>', 'danger');
                }
            }
        });

    }

    function mm_assign_sortable() {

        $("#MenuItems").disableSelection();

        $('#MenuItems').nestedSortable({
            listType: 'ul',
            maxLevels: 3,
            handle: '.fa-arrows-alt',
            items: 'li.card',
            toleranceElement: '> div',
            placeholder: "ui-state-highlight",
            forcePlaceholderSize: true,
            helper: 'clone',
            tabSize: 25,
            tolerance: 'pointer',
            update: function (event, ui) {
                formwatchsomethingChanged = true;

                parentclass = ui.item.parent('ul').parent('li').attr('id');
                if (parentclass.indexOf('special3') != -1 || parentclass.indexOf('special4') != -1) {
                    return false;
                }

                myclass = ui.item.attr('id');
                if (myclass.indexOf('special3') != -1 || myclass.indexOf('special4') != -1) {
                    return false;
                }

            }
        });
    }

    function mm_add_selected(area) {

        $(".mm-empty-menu-message").remove();
        if (area != 'collapseFour') {

            if (area == 'collapseOne') {
                areatype = 1;
            } else if (area == 'collapseTwo') {
                areatype = 2;
            } else if (area == 'collapseThree') {
                areatype = 3;
            } else if (area == 'collapseFive') {
                areatype = 5;
            } else if (area == 'collapseSix') {
                areatype = 6;
            }

            $("#" + area + " input").each(function () {
                if ($(this).is(':checked')) {
                    var id = $(this).attr('data-id');
                    name = '';//to use placeholder as default
                    mm_add_menu_item(areatype, id, name);
                }
            });
            $("#" + area + " input").prop('checked', false);

        } else {

            var name = $("#mm_item_name").val();
            var url = $("#mm_item_link").val();
            if (name != '' && url != '') {
                mm_add_menu_item(4, 0, name, url);
                $("#mm_item_name").val('');
                $("#mm_item_link").val('');
            }
        }


    }

    function mm_add_menu_item(type, id, name, url) {

        if (typeof url == 'undefined') {
            url = '';
        }

        var queryx = {};
        queryx['commtype'] = 'menu_item_add';
        queryx['mm_item_type'] = type;
        queryx['mm_item_id'] = id;
        queryx['mm_item_name'] = name;
        queryx['mm_item_url'] = url;

        $.ajax({
            type: "POST",
            url: "zipur_menu_master.php",
            data: queryx,
            success: function (data) {
                formwatchsomethingChanged = true;
                $("#MenuItems").append(data);
                mm_assign_sortable();
                mm_color_pickers();
            }
        });

    }

    function mm_remove_location(location) {
        var queryx = {};
        queryx['commtype'] = 'menu_remove_location';
        queryx['location'] = location;

        $.ajax({
            type: "POST",
            url: "zipur_menu_master.php",
            data: queryx,
            success: function (html) {
                $("#mm_locations_box").html('');
                formwatchsomethingChanged = false;
                mm_update_status('<?= MM_SCRIPT_LOCATION_REMOVED ?>', 'success');
                $("#mm_locations_box").html(html);

            }
        });
    }

    function mm_add_location() {
        var location = $("#mm_locations").val();
        var queryx = {};
        queryx['commtype'] = 'menu_add_location';
        queryx['location'] = location;

        $.ajax({
            type: "POST",
            url: "zipur_menu_master.php",
            data: queryx,
            success: function (html) {
                $("#mm_locations_box").html('');
                formwatchsomethingChanged = false;
                mm_update_status('<?= MM_SCRIPT_LOCATION_SAVED ?>', 'success');
                $("#mm_locations_box").html(html);

            }
        });
    }

    function mm_nav_category(parentid, fromparentid) {

        var queryx = {};
        queryx['commtype'] = 'menu_nav_category';
        queryx['parentid'] = parentid;
        queryx['fromparentid'] = fromparentid;

        $.ajax({
            type: "POST",
            url: "zipur_menu_master.php",
            data: queryx,
            success: function (html) {
                formwatchsomethingChanged = false;
                $("#mm_categories").html(html);

            }
        });

    }


    function mm_nav_products() {
        var mm_products_search = $("#mm_products_search").val();
        var queryx = {};
        queryx['commtype'] = 'menu_nav_products';
        queryx['search'] = mm_products_search;

        $.ajax({
            type: "POST",
            url: "zipur_menu_master.php",
            data: queryx,
            success: function (html) {
                formwatchsomethingChanged = false;
                $("#mm_products").html(html);

            }
        });

    }

    function mm_toggle_tooltips() {

        var onoff = $("#mm_setting_tooltips").is(":checked");

        if (onoff == 0) {
            $('[data-toggle=tooltip]').tooltip('disable')
        } else if (onoff == 1) {
            $('[data-toggle=tooltip]').tooltip('enable')
        }
    }

    function mm_update_setting(key, type) {
        if (type == 'checkbox') {
            var val = $("#mm_setting_" + key).is(":checked");
        }

        var queryx = {};
        queryx['commtype'] = 'menu_settings';
        queryx['key'] = key;
        queryx['val'] = val;
        queryx['type'] = type;

        $.ajax({
            type: "POST",
            url: "zipur_menu_master.php",
            data: queryx,
            success: function (data) {
                formwatchsomethingChanged = false;
                mm_update_status('<?= MM_SCRIPT_SETTING_SAVED ?>', 'success');
            }
        });

    }

    function mm_menu_item_lang_update(identifier, langid) {
        val = $(".mm_item_name_block_hidden_" + identifier + "_" + langid).val();
        $("#menuCollapse" + identifier + " .input-group-text").removeClass("bg-dark").removeClass("text-light").addClass("bg-light").addClass("text-dark");
        $("#menuCollapse" + identifier + " .mm_item_name_block_append" + langid + " .input-group-text").addClass("bg-dark").addClass("text-light").removeClass("bg-light").removeClass("text-dark");
        $("#mm_item_name" + identifier).val(val).attr("data-lang", langid);
        mm_update_item_title(identifier);
    }


</script>