<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    //load defaults if new menu
    if ( $menuMaster->menu['menu_style'] == '' ) {
        $menuMaster->loadDefaultData();
    }

    $mm_tab_id   = zipVarCheck( 'mm_tab_id', 1, 'FILTER_VALIDATE_INT', 1 );

?>
<style>
    .mm-hide-me{
        display: none;
    }
</style>

<script>
    function mm_menu_type_change(){
        mm_menu_style = $("#mm_menu_style").val();
        if (mm_menu_style == 0){
            $(".mm-hide-menu-tree").addClass('mm-hide-me');
            $(".mm-hide-menu-nav").removeClass('mm-hide-me');
        } else if (mm_menu_style == 1){
            $(".mm-hide-menu-tree").removeClass('mm-hide-me');
            $(".mm-hide-menu-nav").addClass('mm-hide-me');
        }
    }
    function mm_set_tab(tabnum){
        $("#mm_tab_id").val(tabnum);
    }
    function mm_load_tab(){
        $("#mm-menu<?= $mm_tab_id ?>-tab-item").click();
    }

    $(function(){
        mm_menu_type_change();
        mm_load_tab();
    });
</script>
<form method="post" action="zipur_menu_master.php" id="zipur_menu_master_settings" name="zipur_menu_master_settings">
    <div class="container mt-4">
        <div class="row my-4 p-3 border bg-dark text-light" style="display: none;" id="zipur_menu_master_importer">
            <div class="col-12 py-2">
                <?= zipAlert( MM_SETTING_IMPORT_ALERT, 'warning alertstatic' ) ?>
            </div>
            <div class="col-12 col-md-3">
                <?= MM_SETTING_IMPORT ?>:
            </div>
            <div class="col-12 col-md-6">
                <select name="mm_import_template" id="mm_import_template">
                    <option value=""><?= MM_SETTING_IMPORT_SELECT_TEMPLATE ?></option>
                    <?php
                        $mm_template_dir = DIR_FS_CATALOG . 'includes/apps/menu_master/admin/templates/';
                        $file_list = [];

                        if ( is_dir( $mm_template_dir ) ) {
                            $dir_handle = opendir( $mm_template_dir );
                            while ( $file = readdir( $dir_handle ) ) {
                                if ( $file != "." && $file != ".." ) {
                                    if ( ! is_dir( $mm_template_dir . "/" . $file ) ) {
                                        if ( substr( $file, - 3, 3 ) == 'cfg' && substr( $file, 0, 7 ) == 'mm_tpl_' ) {
                                            $filetext = str_replace( '.cfg', '', $file );
                                            $filetext = str_replace( 'mm_tpl_', '', $filetext );
                                            $filetext = str_replace( '_', ' ', $filetext );
                                            $filetext = ucwords( $filetext );
                                            $file_list["$file"] = $file . ';' . $filetext;
                                        }
                                    }
                                }
                            }
                            closedir( $dir_handle );
                        }
                        sort( $file_list );
                        foreach ( $file_list  as $file ) {

                            $file = explode( ';', $file );

                            echo '<option value="' . $file[0] . '">' . $file[1] . '</option>';
                        }
                    ?>
                </select>
                <br/>
                OR
                <br/>

                <input type="file" id="mm_import_file" name="mm_import_file" accept=".cfg"/>
            </div>

            <div class="col-12 col-md-3">
                <button type="button" class="btn btn-sm border text-success border-success bg-light mx-2" onClick="mm_import_now();" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_IMPORT_TIP ?>">
                    <i class="fas fa-file-import"></i> <?= MM_SETTING_IMPORT_NOW ?>
                </button>
            </div>
        </div>
        <div class="row">
            <div class="col col-12">
                <div class="row mb-2">
                    <div class="col-12">
                        <h5><i class="fas fa-cogs"></i> <?= MM_SETTING_MENU_SETTING_TITLE ?></h5>
                    </div>
                </div>

                <div class="border p-2 bg-light">
                    <div class="row my-2">
                        <div class="col-4  col-md-2 text-right">
                            <label for="mm_name"><small><?= MM_SETTING_MENU_NAME ?>:</small></label>
                        </div>
                        <div class="col-8 col-md-4">
                            <input type="text" class="form-control" id="mm_name" name="mm_name" value="<?= $menuMaster->menu['menu_name'] ?>" required data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_MENU_NAME_TIP ?>"/>
                        </div>
                        <div class="col-4  col-md-2 text-right">
                            <label for="mm_class"><small><?= MM_SETTING_MENU_CLASSES ?>:</small></label>
                        </div>
                        <div class="col-8 col-md-4">
                            <input type="text" class="form-control" id="mm_class" name="mm_class" placeholder="class1 class2" value="<?= $menuMaster->menu['menu_class'] ?>" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_MENU_CLASSES_TIP ?>"/>
                        </div>
                    </div>

                    <div class="row my-2">
                        <div class="col-4  col-md-2 text-right">
                            <label for="mm_menu_status"><small><?= MM_SETTING_MENU_DISPLAY ?>:</small></label>
                        </div>
                        <div class="col-8 col-md-4">
                            <div class="row">
                                <div class="col custom-control custom-switch" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_MENU_ENABLED_TIP ?>">
                                    <input type="checkbox" class="custom-control-input" id="mm_menu_status" name="mm_menu_status" value="1" <?php if ( $menuMaster->menu['menu_status'] == 1 ) {
                                        echo 'CHECKED';
                                    } ?>>
                                    <label class="custom-control-label" for="mm_menu_status"><small><?= MM_SETTING_MENU_ENABLED ?></small></label>
                                </div>

                                <div class="col custom-control custom-switch" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_MENU_STICKY_TIP ?>">
                                    <input type="checkbox" class="custom-control-input" id="mm_menu_sticky" name="mm_menu_sticky" value="1" <?php if ( $menuMaster->menu['menu_sticky'] == 1 ) {
                                        echo 'CHECKED';
                                    } ?> disabled>
                                    <label class="custom-control-label" for="mm_menu_sticky"><small><?= MM_SETTING_MENU_STICKY ?></small></label>
                                </div>

                                <div class="col custom-control custom-switch" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_MENU_MOBILE_TIP ?>">
                                    <input type="checkbox" class="custom-control-input" id="mm_show_on_mobile" name="mm_show_on_mobile" value="1" <?php if ( $menuMaster->menu['show_on_mobile'] == 1 ) {
                                        echo 'CHECKED';
                                    } ?>>
                                    <label class="custom-control-label" for="mm_show_on_mobile"><small><?= MM_SETTING_MENU_MOBILE ?></small></label>
                                </div>
                            </div>


                        </div>
                        <div class="col-4  col-md-2 text-right">
                            <label for="mm_label_text"><small><?= MM_SETTING_MENU_LABEL ?>:</small></label>
                        </div>
                        <div class="col-8 col-md-4">

                            <?php

                                foreach ( $menuMaster->languages as $languageitem ) {

                                    $label_text = empty( $menuMaster->menu_lang[ $languageitem['id'] ] ) ? '' : $menuMaster->menu_lang[ $languageitem['id'] ]['label_text'];
                                    ?>
                                    <div class="input-group mb-1 w-75">
                                        <input type="text" class="form-control" id="mm_label_text_<?= $languageitem['code'] ?>" name="mm_label_text_<?= $languageitem['code'] ?>" value="<?= $label_text ?>" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_MENU_LABEL_TIP ?>"/>
                                        <div class="input-group-append" data-toggle="tooltip" data-placement="right" title="<?= $languageitem['name'] ?>">
                                            <span class="input-group-text" id="basic-addon-<?= $languageitem['code'] ?>"><?= ' <small>(' . strtoupper( $languageitem['code'] ) . ')</small>' ?></span>
                                        </div>
                                    </div>
                                    <?php
                                }
                            ?>
                        </div>
                    </div>

                    <div class="row my-2">
                        <div class="col-4  col-md-2 text-right">
                            <label for="mm_color_type"><small><?= MM_SETTING_MENU_COLORS ?>:</small></label>
                        </div>
                        <div class="col-8 col-md-4">
                            <select class="form-control" name="mm_color_type" id="mm_color_type" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_MENU_COLORS_TIP ?>">
                                <option value="0" <?php if ( $menuMaster->menu['color_type'] == 0 ) {
                                    echo 'SELECTED';
                                } ?>>HEX
                                </option>
                                <option value="1" <?php if ( $menuMaster->menu['color_type'] == 1 ) {
                                    echo 'SELECTED';
                                } ?>>RGB/RGBA
                                </option>
                            </select>
                        </div>
                        <div class="col-4  col-md-2 text-right">
                            <label for="mm_sort_order"><small><?= MM_SETTING_MENU_SORT ?>:</small></label>
                        </div>
                        <div class="col-8 col-md-4">
                            <input type="number" style="width: 100px;" class="form-control" id="mm_sort_order" name="mm_sort_order" value="<?= $menuMaster->menu['sort_order'] ?>" required data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_MENU_SORT_TIP ?>"/>
                        </div>

                    </div>


                    <div class="row my-2">
                        <div class="col-4  col-md-2 text-right">
                            <label for="mm_menu_style"><small><?= MM_SETTING_MENU_TYPE ?>:</small></label>
                        </div>
                        <div class="col-8 col-md-4">
                            <select class="form-control" name="mm_menu_style" id="mm_menu_style" onChange="mm_menu_type_change();">
                                <option value="0" <?php if ( $menuMaster->menu['menu_style'] == 0 ) {
                                    echo 'SELECTED';
                                } ?>><?= MM_SETTING_MENU_TYPE_REGULAR ?>
                                </option>
                                <option value="1" <?php if ( $menuMaster->menu['menu_style'] == 1 ) {
                                    echo 'SELECTED';
                                } ?>><?= MM_SETTING_MENU_TYPE_TREE ?> (Requires Upgrade)
                                </option>
                            </select>
                        </div>
                        <div class="col-4  col-md-2 text-right">
                        </div>
                        <div class="col-8 col-md-4">
                        </div>
                    </div>
                    <div class="row my-2 mm-hide-menu-tree">

                        <div class="col-4  col-md-2 text-right">
                            <label for="mm_menu_icon_close"><small><?= MM_SETTING_MENU_TREE_CLOSED ?>:</small></label>
                        </div>
                        <div class="col-8 col-md-4">
                            <input type="text" class="form-control" id="mm_menu_icon_close" name="mm_menu_icon_close" value="<?= $menuMaster->menu['menu_icon_close'] ?>" placeholder="fa-plus" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_MENU_TREE_CLOSED_TIP ?>"/>
                        </div>

                        <div class="col-4  col-md-2 text-right">
                            <label for="mm_menu_icon_open"><small><?= MM_SETTING_MENU_TREE_OPENED ?>:</small></label>
                        </div>
                        <div class="col-8 col-md-4">
                            <input type="text" class="form-control" id="mm_menu_icon_open" name="mm_menu_icon_open" value="<?= $menuMaster->menu['menu_icon_open'] ?>" placeholder="fa-minus" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_MENU_TREE_OPENED_TIP ?>"/>
                        </div>
                    </div>

                </div>


                <ul class="nav nav-tabs p-0 mb-0 mt-4">
                    <li class="nav-item px-2 py-0 mx-3">
                        <a href="#mm-menu1" id="mm-menu1-tab-item" class="nav-link bg-light active py-1 px-2 border" data-toggle="tab" onClick="mm_set_tab(1);">
                            <?= MM_SETTING_TAB_MENU ?></a>
                    </li>
                    <li class="nav-item p-0 mx-3">
                        <a href="#mm-menu2" id="mm-menu2-tab-item" class="nav-link bg-light py-1 px-2 border" data-toggle="tab" onClick="mm_set_tab(2);"><?= MM_SETTING_TAB_MAIN ?></a>
                    </li>
                    <li class="nav-item p-0 mx-3">
                        <a href="#mm-menu3" id="mm-menu3-tab-item" class="nav-link bg-light py-1 px-2 border" data-toggle="tab" onClick="mm_set_tab(3);"><?= MM_SETTING_TAB_CHILD ?></a>
                    </li>
                    <li class="nav-item p-0 mx-3">
                        <a href="#mm-menu4" id="mm-menu4-tab-item" class="nav-link bg-light py-1 px-2 border" data-toggle="tab" onClick="mm_set_tab(4);"><?= MM_SETTING_TAB_CSS ?></a>
                    </li>
                </ul>
                <div class="tab-content border p-2 mt-0">
                    <div class="tab-pane fade show active" id="mm-menu1">
                        <div class="border p-3 my-3">
                            <div class="border-bottom bg-light text-muted">
                                <h6><?= MM_SETTING_TAB_MENU ?></h6>
                            </div>
                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_menu_bar_bg_color"><small><?= MM_SETTING_BAR_BG ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_menu_bar_bg_color', $menuMaster->menu['menu_bar_bg_color'] );
                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_menu_bar_border_color"><small><?= MM_SETTING_BAR_BORDER_COLOR ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_menu_bar_border_color', $menuMaster->menu['menu_bar_border_color'] );
                                    ?>
                                </div>
                            </div>
                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_hamburger_color"><small><?= MM_SETTING_HAM_COLOR ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_hamburger_color', $menuMaster->menu['hamburger_color'] );
                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_hamburger_bg_color"><small><?= MM_SETTING_HAM_BG ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_hamburger_bg_color', $menuMaster->menu['hamburger_bg_color'] );
                                    ?>
                                </div>
                            </div>
                            <div class="row my-2">
                                <div class="col-2 text-right">
                                    <label for="mm_hamburger_color"><small><?= MM_SETTING_HAM_CODE ?>:</small></label>
                                </div>
                                <div class="col-10 ">
                                    <input type="text" class="form-control" id="mm_hamburger_code" name="mm_hamburger_code" value="<?= str_replace('"', '&quot;', $menuMaster->menu['hamburger_code']) ?>" placeholder="<i class=&quot;fas fa-bars&quot;></i>" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_HAM_CODE_TIP ?>"/>
                                </div>

                            </div>

                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_menu_bar_padding"><small><?= MM_SETTING_PADDING ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zip4Pixel( 'mm_menu_bar_padding', $menuMaster->menu['menu_bar_padding'] );
                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_menu_bar_margin"><small><?= MM_SETTING_MARGIN ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zip4Pixel( 'mm_menu_bar_margin', $menuMaster->menu['menu_bar_margin'] );
                                    ?>
                                </div>
                            </div>


                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_menu_bar_border_radius"><small><?= MM_SETTING_CORNER ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php

                                        zip4Pixel( 'mm_menu_bar_border_radius', $menuMaster->menu['menu_bar_border_radius'] );

                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_menu_bar_border_width"><small><?= MM_SETTING_BORDER ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php

                                        zip4Pixel( 'mm_menu_bar_border_width', $menuMaster->menu['menu_bar_border_width'] );

                                    ?>
                                </div>
                            </div>


                        </div>
                    </div>
                    <div class="tab-pane fade show" id="mm-menu2">
                        <div class="border p-3 my-3">

                            <div class="border-bottom bg-light text-muted">
                                <h6><?= MM_SETTING_TAB_MAIN ?></h6>
                            </div>

                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_menu_font"><small><?= MM_SETTING_FONT ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <input type="text" class="form-control" id="mm_menu_font" name="mm_menu_font" value="<?= $menuMaster->menu['menu_font'] ?>" placeholder="font1, font2, font3" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_FONT_TIP ?>"/>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_menu_font_size"><small><?= MM_SETTING_FONT_SIZE ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <input type="text" class="form-control" id="mm_menu_font_size" name="mm_menu_font_size" value="<?= $menuMaster->menu['menu_font_size'] ?>" placeholder="1em" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_FONT_SIZE_TIP ?>"/>
                                </div>
                            </div>

                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_link_color"><small><?= MM_SETTING_COLOR ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_link_color', $menuMaster->menu['link_color'] );
                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_link_hover"><small><?= MM_SETTING_HOVER ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_link_hover', $menuMaster->menu['link_hover'] );
                                    ?>
                                </div>
                            </div>

                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_bg_color"><small><?= MM_SETTING_BG ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_bg_color', $menuMaster->menu['bg_color'] );
                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_bg_hover"><small><?= MM_SETTING_BG_HOVER ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_bg_hover', $menuMaster->menu['bg_hover'] );
                                    ?>
                                </div>
                            </div>


                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_border_color"><small><?= MM_SETTING_BORDER_COLOR ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_border_color', $menuMaster->menu['border_color'] );
                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_border_hover"><small><?= MM_SETTING_BORDER_HOVER_COLOR ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_border_hover', $menuMaster->menu['border_hover'] );
                                    ?>
                                </div>
                            </div>

                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_padding"><small><?= MM_SETTING_PADDING ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zip4Pixel( 'mm_padding', $menuMaster->menu['padding'] );
                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right mm-hide-menu-nav">
                                    <label for="mm_margin"><small><?= MM_SETTING_MARGIN ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4 mm-hide-menu-nav">
                                    <?php
                                        zip4Pixel( 'mm_margin', $menuMaster->menu['margin'] );
                                    ?>
                                </div>
                            </div>

                            <div class="row my-2 mm-hide-menu-nav">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_border_radius"><small><?= MM_SETTING_CORNER ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php

                                        zip4Pixel( 'mm_border_radius', $menuMaster->menu['border_radius'] );

                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_border_width"><small><?= MM_SETTING_BORDER ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php

                                        zip4Pixel( 'mm_border_width', $menuMaster->menu['border_width'] );

                                    ?>
                                </div>
                            </div>

                            <div class="row my-2 mm-hide-menu-nav">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_menu_align"><small><?= MM_SETTING_ALIGN ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <select class="form-control" name="mm_menu_align" id="mm_menu_align">
                                        <option value="left" <?php if ( $menuMaster->menu['menu_align'] == 'left' ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_ALIGN_LEFT ?>
                                        </option>
                                        <option value="center" <?php if ( $menuMaster->menu['menu_align'] == 'center' ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_ALIGN_CENTER ?>
                                        </option>
                                        <option value="right" <?php if ( $menuMaster->menu['menu_align'] == 'right' ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_ALIGN_RIGHT ?>
                                        </option>
                                    </select>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_border_width"><small><?= MM_SETTING_ITEM_WIDTH ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <select class="form-control" name="mm_menu_fill" id="mm_menu_fill">
                                        <option value="0" <?php if ( $menuMaster->menu['menu_fill'] == 0 ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_ITEM_WIDTH_AUTO ?>
                                        </option>
                                        <option value="1" <?php if ( $menuMaster->menu['menu_fill'] == 1 ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_ITEM_WIDTH_FILL ?>
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="row my-2 mm-hide-menu-nav">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_hamburger_placement"><small><?= MM_SETTING_HAM_ALIGN ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <select class="form-control" name="mm_hamburger_placement" id="mm_hamburger_placement">
                                        <option value="left" <?php if ( $menuMaster->menu['hamburger_placement'] == 'left' ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_ALIGN_LEFT ?>
                                        </option>
                                        <option value="center" <?php if ( $menuMaster->menu['hamburger_placement'] == 'center' ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_ALIGN_CENTER ?>
                                        </option>
                                        <option value="right" <?php if ( $menuMaster->menu['hamburger_placement'] == 'right' ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_ALIGN_RIGHT ?>
                                        </option>
                                    </select>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_hamburger_breakpoint"><small><?= MM_SETTING_HAM_SHOW ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <select class="form-control" name="mm_hamburger_breakpoint" id="mm_hamburger_breakpoint">
                                        <option value="" <?php if ( $menuMaster->menu['hamburger_breakpoint'] == '' ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_HAM_SHOW_NEVER ?>
                                        </option>
                                        <option value="sm" <?php if ( $menuMaster->menu['hamburger_breakpoint'] == 'sm' ) {
                                            echo 'Small Screen Width';
                                        } ?>><?= MM_SETTING_HAM_SHOW_SMALL ?>
                                        </option>
                                        <option value="md" <?php if ( $menuMaster->menu['hamburger_breakpoint'] == 'md' ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_HAM_SHOW_MEDIUM ?>
                                        </option>
                                        <option value="lg" <?php if ( $menuMaster->menu['hamburger_breakpoint'] == 'lg' ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_HAM_SHOW_LARGE ?>
                                        </option>
                                        <option value="xl" <?php if ( $menuMaster->menu['hamburger_breakpoint'] == 'xl' ) {
                                            echo 'SELECTED';
                                        } ?>><?= MM_SETTING_HAM_SHOW_XLARGE ?>
                                        </option>
                                    </select>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="tab-pane fade show" id="mm-menu3">
                        <div class="border p-3 my-3">
                            <div class="border-bottom bg-light text-muted">
                                <h6><?= MM_SETTING_TAB_CHILD ?></h6>
                            </div>

                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_child_menu_font"><small><?= MM_SETTING_SUB_FONT ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <input type="text" class="form-control" id="mm_child_menu_font" name="mm_child_menu_font" value="<?= $menuMaster->menu['child_menu_font'] ?>" placeholder="font1, font2, font3" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_SUB_FONT_TIP ?>"/>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_child_font_size"><small><?= MM_SETTING_SUB_FONT_SIZE ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <input type="text" class="form-control" id="mm_child_font_size" name="mm_child_font_size" value="<?= $menuMaster->menu['child_font_size'] ?>" placeholder="1em" data-toggle="tooltip" data-placement="top" title="<?= MM_SETTING_SUB_FONT_SIZE_TIP ?>"/>
                                </div>
                            </div>


                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_child_link_color"><small><?= MM_SETTING_COLOR ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">

                                    <?php
                                        zipColorPicker( 'mm_child_link_color', $menuMaster->menu['child_link_color'] );
                                    ?>

                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_child_link_hover"><small><?= MM_SETTING_HOVER ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">

                                    <?php
                                        zipColorPicker( 'mm_child_link_hover', $menuMaster->menu['child_link_hover'] );
                                    ?>

                                </div>
                            </div>


                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_child_bg_color"><small><?= MM_SETTING_BG ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">

                                    <?php
                                        zipColorPicker( 'mm_child_bg_color', $menuMaster->menu['child_bg_color'] );
                                    ?>

                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_child_bg_hover"><small><?= MM_SETTING_BG_HOVER ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">

                                    <?php
                                        zipColorPicker( 'mm_child_bg_hover', $menuMaster->menu['child_bg_hover'] );
                                    ?>

                                </div>
                            </div>


                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_child_border_color"><small><?= MM_SETTING_BORDER_COLOR ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_child_border_color', $menuMaster->menu['child_border_color'] );
                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_child_border_hover"><small><?= MM_SETTING_BORDER_HOVER_COLOR ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zipColorPicker( 'mm_child_border_hover', $menuMaster->menu['child_border_hover'] );
                                    ?>
                                </div>
                            </div>


                            <div class="row my-2">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_child_padding"><small><?= MM_SETTING_PADDING ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php
                                        zip4Pixel( 'mm_child_padding', $menuMaster->menu['child_padding'] );
                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right mm-hide-menu-nav">
                                    <label for="mm_child_margin"><small><?= MM_SETTING_MARGIN ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4 mm-hide-menu-nav">
                                    <?php
                                        zip4Pixel( 'mm_child_margin', $menuMaster->menu['child_margin'] );
                                    ?>
                                </div>
                            </div>

                            <div class="row my-2 mm-hide-menu-nav">
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_child_border_radius"><small><?= MM_SETTING_CORNER ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php

                                        zip4Pixel( 'mm_child_border_radius', $menuMaster->menu['child_border_radius'] );

                                    ?>
                                </div>
                                <div class="col-4  col-md-2 text-right">
                                    <label for="mm_child_border_width"><small><?= MM_SETTING_BORDER ?>:</small></label>
                                </div>
                                <div class="col-8 col-md-4">
                                    <?php

                                        zip4Pixel( 'mm_child_border_width', $menuMaster->menu['child_border_width'] );

                                    ?>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="tab-pane fade show" id="mm-menu4">
                        <?= MM_SETTING_CSS_DESC ?> #mm-navbar-drop-<?= $menuMaster->menu['menu_id']  ?>-<strong title="<?php
                            $locations = $menuMaster->getMenuLocations();
                            foreach ( $locations as $location ) {
                                echo '&#013;(' . $location['id'] . '-' . str_replace( ' ', '&nbsp;', $location['name'] ) . ') ' . "\n";
                            }
                        ?>">(location id)</strong>
                        <textarea rows="15" cols="100" id="mm_customcss" name="mm_customcss"><?= $menuMaster->menu['customcss'] ?></textarea>
                    </div>
                </div>


            </div>
        </div>
    </div>
    <input type="hidden" name="save" value="1"/>
    <input type="hidden" name="update" value="1"/>
    <input type="hidden" id="mm_tab_id" name="mm_tab_id" value="<?= $mm_tab_id ?>"/>
    <input type="hidden" id="mm_export" name="mm_export" value="0"/>
    <input type="hidden" id="mm_import" name="mm_import" value="0"/>
</form>
<div class="container-fluid">
    <?php
        include 'preview.php';

    ?>
</div>
