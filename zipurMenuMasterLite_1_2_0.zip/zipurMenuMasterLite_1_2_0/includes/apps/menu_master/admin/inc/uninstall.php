<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    if ( empty( $menuuninstall ) ) {
        ?>
        <div class="row">
            <div class="col m-4 text-center">
                <?= MM_UNINSTALL_WARNING ?><br/>
                <button type="button" onClick="window.location.href='zipur_menu_master.php?uninstall=1&menuuninstall=1';" class="btn btn-primary m-4  "><?= MM_UNINSTALL ?></button>
            </div>
        </div>
        <?php
    } else if ( $menuuninstall == 1 ) {

        tep_db_query( 'DROP TABLE IF EXISTS menu_master;' );
        tep_db_query( 'DROP TABLE IF EXISTS menu_master_items;' );
        tep_db_query( 'DROP TABLE IF EXISTS menu_master_to_location;' );
        tep_db_query( 'DROP TABLE IF EXISTS menu_master_settings;' );
        tep_db_query( 'DROP TABLE IF EXISTS menu_master_language;' );
        tep_db_query( 'DROP TABLE IF EXISTS menu_master_items_language;' );
        tep_db_query( "DELETE FROM configuration WHERE configuration_key LIKE 'MODULE_NAVBAR_MM_MENU_%'" );
        tep_db_query( "DELETE FROM configuration WHERE configuration_key LIKE 'MODULE_BOXES_MM_MENU_LEFT_%'" );
        tep_db_query( "DELETE FROM configuration WHERE configuration_key LIKE 'MODULE_BOXES_MM_MENU_RIGHT_%'" );
        tep_db_query( "DELETE FROM configuration WHERE configuration_key LIKE 'MODULE_CONTENT_HEADER_MM_MENU_%'" );
        tep_db_query( "DELETE FROM configuration WHERE configuration_key LIKE 'MODULE_CONTENT_PI_MM_MENU_%'" );
        tep_db_query( "DELETE FROM configuration WHERE configuration_key LIKE 'MODULE_CONTENT_SC_MM_MENU_%'" );
        tep_db_query( "DELETE FROM configuration WHERE configuration_key LIKE 'MODULE_CONTENT_CHECKOUT_SUCCESS_MM_MENU_%'" );
        tep_db_query( "DELETE FROM configuration WHERE configuration_key LIKE 'MODULE_CONTENT_IN_MM_MENU_%'" );
        tep_db_query( "DELETE FROM configuration WHERE configuration_key LIKE 'MODULE_CONTENT_IP_MM_MENU_%'" );
        tep_db_query( "DELETE FROM configuration WHERE configuration_key LIKE 'MODULE_HEADER_TAGS_MM_MENU_%'" );
        for ( $i = 1; $i <= 10; $i ++ ) {
            mm_menu_install( $i, 0 );
        }

        $cache_file = DIR_FS_CATALOG . 'includes/apps/menu_master/cache/menu_master.cache';
        if ( file_exists( $cache_file ) ) {
            unlink( $cache_file );
        }

        $cache_file = DIR_FS_CATALOG . 'includes/apps/menu_master/cache/temp_menu_master.cache';
        if ( file_exists( $cache_file ) ) {
            unlink( $cache_file );
        }

        unset( $_SESSION['menumaster'] );

        zipAlert( MM_UNINSTALL_DONE, 'warning' );

        ?>
        <script>
            $(function () {
                $(".mm-select-menu").remove();
            });
        </script>
        <?php

    }