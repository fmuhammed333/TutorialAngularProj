<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.1.3',
        'sql'     => [
            "ALTER TABLE menu_master_items ADD COLUMN mega_menu INT(2) NOT NULL DEFAULT 0;",
        ],
        'items'   => [
            [ 'text' => 'Added mega menu option to base-level items', ],
            [ 'text' => 'Added mega menu logic to menu system', ],
        ],

    ];

