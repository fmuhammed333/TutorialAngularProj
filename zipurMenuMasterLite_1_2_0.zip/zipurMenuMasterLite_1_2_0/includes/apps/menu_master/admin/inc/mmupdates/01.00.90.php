<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.0.9',
        'sql'     => [
        ],
        'items'   => [
            [ 'text' => 'Changed - Save Changes now only affects the admin previews of the menu.', ],
            [ 'text' => 'Added - Publish Menus button saves the changes and publishes them to the store so everyone can see them.', ],
            [ 'text' => 'Added - includes/apps/menu_master/admin/templates folder to store templates of pre-configured menu styles that can be imported.', ],
            [ 'text' => 'Added - logic on store menu to restrict access to menu items for guest/user.', ],
            [ 'text' => 'Added - logic on store menu to highlight active page with hover colors.', ],
            [ 'text' => 'Added - Menu Settings - Export to download selected menu cfg.', ],
            [ 'text' => 'Added - Menu Settings - Import to upload a cfg file to re-style the selected menu.', ],
            [ 'text' => 'Added - Menu Settings - Import to include a list of templates to re-style the selected menu.', ],
        ],

    ];

