<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [
        'version' => '1.1.6',
        'sql'     => [],
        'items'   => [
            [ 'text' => 'Added CSS into a new Header Tags Module for early load into DOM to stop code flashing', ],
            [ 'text' => 'Added img-fluid to menu image', ],
            [ 'text' => 'Adjusted CSS for Tree Menu Hovers & Text Sizing for each level', ],
        ],
    ];

