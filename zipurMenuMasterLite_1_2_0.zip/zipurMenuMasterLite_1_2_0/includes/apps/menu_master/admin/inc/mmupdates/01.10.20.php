<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.1.2',
        'sql'     => [
        ],
        'items'   => [
            [ 'text' => 'Fixed issue with mobile submenu clicks. Clicking twice will go to link. Clicking once will just expand the submenu.', ],
            [ 'text' => 'Fixed issue with hamburger menu code/text color not matching selected color.', ],
            [ 'text' => 'Reworked config area to use functions for easier code expansion going forward.', ],
            [ 'text' => 'Added new Module/Menu Location - Content - product_info.', ],
            [ 'text' => 'Added new Module/Menu Location - Content - shopping_cart.', ],
            [ 'text' => 'Added new Module/Menu Location - Content - checkout_success.', ],
            [ 'text' => 'Added new Module/Menu Location - Content - index_nested (Category Listing).', ],
            [ 'text' => 'Added new Module/Menu Location - Content - index_products (Product Listing).', ],
        ],

    ];

