<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [
        'version' => '1.1.4',
        'sql'     => [],
        'items'   => [
            [ 'text' => 'Added logic to setting page where after clicking SAVE CHANGES, tab being edited is re-opened. This helps when tweaking each menu area.', ],
            [ 'text' => 'Fixed several css style issues. Tested all, 1 setting at a time. Should be much better now.', ],
            [ 'text' => 'Fixed issue with images not saving correctly.', ],
            [ 'text' => 'Added image logic to menus. Maximum image sizes can be adjusted using custom css if needed.', ],
        ],
    ];

