<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [
        'version' => '1.1.5',
        'sql'     => [],
        'items'   => [
            [ 'text' => 'Moved all js and css logic to cached files to allow for faster loading in browser on front-end. Cache files deleted on publish and re-created on first page load. Admin does not use cached version of files.', ],
            [ 'text' => 'Code cleanup in all areas', ],
            [ 'text' => 'Moved all language to language files', ],
            [ 'text' => 'Miscellaneous improvements to installer - uninstaller - config.', ],
        ],
    ];

