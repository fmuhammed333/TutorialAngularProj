<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.0.8',
        'sql'     => [
            "ALTER TABLE menu_master ADD COLUMN customcss TEXT NOT NULL DEFAULT '';",
            "ALTER TABLE menu_master ADD COLUMN child_border_radius VARCHAR(20) NOT NULL DEFAULT '0px 0px 0px 0px';",
        ],
        'items'   => [
            [ 'text' => 'Added - uninstall button to upgrade page if needed.', ],
            [ 'text' => 'Added - back button to upgrade page if no upgrade needed.', ],
            [ 'text' => 'Added - back button to config page.', ],
            [ 'text' => 'Cleaned up a bunch of layout/action issues.', ],
            [ 'text' => 'CHANGED - saving menu settings will now remain on menu settings page. This makes editing menu settings while testing much easier. Clicking back will return to the menu layout.', ],
            [ 'text' => 'Fixed - "Menu Data Empty" message only shows in admin preview now.', ],
            [ 'text' => 'Added - Preview and Tabs to Menu Settings Page', ],
            [ 'text' => 'Fixed - "Special Item - Create Account Link.', ],
            [ 'text' => 'Fixed - "Special Item - Forgot Password Link.', ],
            [ 'text' => 'Added - New menu position - Above Header', ],
            [ 'text' => 'Added - New menu position - Below Header', ],
            [ 'text' => 'Added - Custom Css Tab to Menu Settings which allows override of anything.', ],
            [ 'text' => 'Added - Border Radius to Menu Settings Child Items.', ],
        ],

    ];

