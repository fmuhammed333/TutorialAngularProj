<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.1.0',
        'sql'     => [
            "ALTER TABLE menu_master_items ADD COLUMN item_icon_show INT(2) NOT NULL DEFAULT 0;",
        ],
        'items'   => [
            [ 'text' => 'Fixed issue with Phoenix Core Pages and local custom links not showing active when on that page.', ],
            [ 'text' => 'Fixed issue with center/right menu align not wrapping with same alignment.', ],
            [ 'text' => 'Added item setting for icons and how they should show.', ],
            [ 'text' => 'Added backup/restore functionality. Backup/Restore button added to main menu edit screen (bottom left)', ],
        ],

    ];

