<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [
        'version' => '1.2.0',
        'sql'     => [],
        'items'   => [
            [ 'text' => 'Fixed some admin errors with PHP 7.4', ],
        ],
    ];

