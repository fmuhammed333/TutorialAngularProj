<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [
        'version' => '1.1.7',
        'sql'     => [],
        'items'   => [
            [ 'text' => 'Adjusted sort orders on product categories to use sort_order and then category_name. This will allow the menu to be sorted based on sort orders in categories. *NOTE: Will have to re-save your menu and re-publish to see the change.', ],
        ],
    ];

