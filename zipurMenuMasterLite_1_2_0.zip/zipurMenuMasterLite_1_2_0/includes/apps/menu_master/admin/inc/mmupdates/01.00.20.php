<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.0.2',
        'sql'     => [],
        'items'   => [
            [ 'text' => 'Fixed issue with menu bar frame still showing on mobile, even if the menu is disabled on mobile.', ],
            [ 'text' => 'Added all preview menu locations for types: NAVBAR and PILL', ],
        ],

    ];

