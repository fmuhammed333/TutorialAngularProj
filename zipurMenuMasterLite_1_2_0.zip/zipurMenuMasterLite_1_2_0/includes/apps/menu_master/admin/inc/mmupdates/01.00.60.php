<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.0.6',
        'sql'     => [
            "ALTER TABLE menu_master_items ADD COLUMN item_valign VARCHAR(35) NOT NULL DEFAULT '';",
            "UPDATE menu_master_items SET item_valign='middle';",
        ],
        'items'   => [
            [ 'text' => 'Added verticle spacing setting to each menu item. This option does not work as menu height is conmsistant, so all items look the same anyway. Use padding and margin classes to adjust spacing where needed..', ],
            [ 'text' => 'Fixed - renamed Center to Small on Settings>Menu Items>Hamburger Show', ],
            [ 'text' => 'Fixed - if Settings>Menu Items>Hamburger Show is set to NONE - then show menu on all screen sizes', ],
            [ 'text' => 'Fixed - wrapping of long menus to stop screen overflow', ],
            [ 'text' => 'Fixed - issue with hamburger menu items not showing on small screensize', ],
            [ 'text' => 'Fixed - Menu Manager on welcome screen changed to Menu Master', ],
            [ 'text' => 'Fixed - Reworked the menu animation and delays', ],
            [ 'text' => 'Fixed - Categories now have propper nested cPath in URLs', ],
        ],

    ];

