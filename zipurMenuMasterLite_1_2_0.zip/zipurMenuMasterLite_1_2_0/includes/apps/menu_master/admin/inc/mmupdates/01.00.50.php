<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.0.5',
        'sql'     => [
            "ALTER TABLE menu_master ADD COLUMN menu_font VARCHAR(254) NOT NULL DEFAULT '';",
            "ALTER TABLE menu_master ADD COLUMN child_menu_font VARCHAR(254) NOT NULL DEFAULT '';",
            "ALTER TABLE menu_master ADD COLUMN menu_font_size VARCHAR(10) NOT NULL DEFAULT '1em';",
            "ALTER TABLE menu_master ADD COLUMN child_font_size VARCHAR(10) NOT NULL DEFAULT '1em';",
            "ALTER TABLE menu_master ADD COLUMN hamburger_color VARCHAR(35) NOT NULL DEFAULT '';",
            "ALTER TABLE menu_master ADD COLUMN hamburger_bg_color VARCHAR(35) NOT NULL DEFAULT '';",
            "ALTER TABLE menu_master ADD COLUMN hamburger_placement VARCHAR(6) NOT NULL DEFAULT 'right';",
            "ALTER TABLE menu_master ADD COLUMN hamburger_breakpoint VARCHAR(6) NOT NULL DEFAULT 'md';",
            "UPDATE menu_master SET hamburger_breakpoint='md';",
            "ALTER TABLE menu_master_items ADD COLUMN item_breakpoint_hide VARCHAR(10) NOT NULL DEFAULT 'smmdlgxl';",
        ],
        'items'   => [
            [ 'text' => 'Added tooltips to ? instead of using browser only title text.', ],
            [ 'text' => 'Added menu and submenu fonts.', ],
            [ 'text' => 'Added hamburger icon colors for mobile menu.', ],
            [ 'text' => 'Added align left/center/right for hamburger menu icon.', ],
            [ 'text' => 'Added multiple breakpoints for showing hamburger menu.', ],
            [ 'text' => 'Removed Pills and Tabs menu types as Navbar can do it all.', ],
            [ 'text' => 'Added item option for show/hide on screen sizes.', ],
            [ 'text' => 'Added product categories depth code to show subcategories.', ],
        ],

    ];
