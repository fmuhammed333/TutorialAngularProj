<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.0.7',
        'sql'     => [],
        'items'   => [
            [ 'text' => 'Added another menu area - Below Content', ],
            [ 'text' => 'Added - all areas added to front-end as hooks or modules', ],
            [ 'text' => 'Added Modules Config area to Menu Master (beside New Menu Button) to allow diagnositic of required hooks and modules as well as the ability to disable/enable them from the config page :)', ],
        ],

    ];

