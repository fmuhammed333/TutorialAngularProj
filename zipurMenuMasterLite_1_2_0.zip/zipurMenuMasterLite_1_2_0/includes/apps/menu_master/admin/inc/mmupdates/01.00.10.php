<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.0.1',
        'sql'     => ["ALTER TABLE menu_master ADD COLUMN sort_order INT(2) NOT NULL DEFAULT 0;",],
        'items'   => [
            [ 'text' => 'Added "Sort Order" to menu settings to allow menus sharing the same space to be ordered.', ],
            [ 'text' => 'Add tooltips to pixel settings for TOP RIGHT BOTTOM LEFT', ],
            [ 'text' => 'Add Special Item - Search - adds a store search to your menu.', ],
            [ 'text' => 'Add Special Item - Alignment - allows you to change alignment for main item menus that follow the alignment block.', ],
        ],

    ];
