<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.0.3',
        'sql'     => [],
        'items'   => [
            [ 'text' => 'Fixed several issues with layout.', ],
            [ 'text' => 'Added code for sticky menus. Only works in horizontal top menu positions.', ],
            [ 'text' => 'Added ? tips for Special Items to explain their purpose.', ],
            [ 'text' => 'Added updates folder and moved updates into new logic.', ],
            [ 'text' => 'Removed Button menu as Pills menu works the same and has the same look.', ],
            [ 'text' => 'Add logic for Tabs menu.', ],
        ],

    ];

