<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $update_settings = [

        'version' => '1.1.1',
        'sql'     => [
            "ALTER TABLE menu_master ADD COLUMN menu_icon_close VARCHAR(50) NOT NULL DEFAULT 'fa-plus';",
            "ALTER TABLE menu_master ADD COLUMN menu_icon_open VARCHAR(50) NOT NULL DEFAULT 'fa-minus';",
            "ALTER TABLE menu_master ADD COLUMN hamburger_code VARCHAR(254) NOT NULL DEFAULT '<i class=\"fas fa-bars\"></i>';",
        ],
        'items'   => [
            [ 'text' => 'Added Tree Menu Type (can only be used in left menu)', ],
            [ 'text' => 'Added Tree Menu Open/Close Icon Options', ],
            [ 'text' => 'Fixed issue with custom link not showing active in sub-directory store', ],
            [ 'text' => 'Fixed issue with cart limit on menu item not working', ],
            [ 'text' => 'Fixed issue custom css id not working in tooltip', ],
            [ 'text' => 'Added option for custom hamburger menu text/code', ],
            [ 'text' => 'Added new menu location - Inside Navbar - using module.', ],
        ],

    ];

