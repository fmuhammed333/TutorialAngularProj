<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

?>
<div class="row">
    <div class="col p-2 pb-4 mx-4">
        <?php
            if ( empty( $previewall ) ) {
                ?>
                <h5><i class="fas fa-eye"></i> <?= MM_PREVIEW_SINGLE_TITLE ?> -
                    <strong><?= $menuMaster->menu['menu_name'] ?></strong>
                </h5>
                <?php
            } else {
                ?>
                <h5><i class="fas fa-eye"></i> <strong><?= MM_PREVIEW_ALL_TITLE ?></strong>
                </h5>
                <?php
            }
        ?>
    </div>
</div>
<div class="container-fluid" style="min-height: 400px;">
    <?php
        $mmDraw = new menuMasterDraw();
        $mmDraw->loadJSON();

    ?>
    <div class="form-row">
        <div class="col-12 border bg-dark text-light" style="min-height: 50px; padding: 10px;">
            <div class="text-center">PHOENIX NAVBAR</div>
            <?php
                $mmDraw->drawMenus( 1, $previewall, $menuMaster->menu['menu_id'] );
            ?>
        </div>
        <div class="col-12 border bg-dark text-light" style="min-height: 50px; padding: 10px;">

            <div class="text-center">
                PHOENIX HEADER
                <div>
                    <?php
                        $mmDraw->drawMenus( 12, $previewall, $menuMaster->menu['menu_id'] );
                    ?>
                </div>
            </div>

        </div>
    </div>

    <div class="form-row">
        <div class="col-12 col-md-2 border">
            <div class="text-center bg-dark text-light">LEFT BAR</div>

            <?php
                $mmDraw->drawMenus( 2, $previewall, $menuMaster->menu['menu_id'] );
            ?>
        </div>
        <div class="col-12 col-md-8 border" style="min-height: 200px;">

            <div class="text-center bg-dark text-light">MAIN CONTENT AREA</div>

            <div class="text-center border p-2 my-2">
                PRODUCT PAGE
            </div>
            <div class="text-center border p-2 my-2">
                SHOPPING CART PAGE
            </div>
            <div class="text-center border p-2 my-2">
                CHECKOUT SUCCESS PAGE
            </div>
            <div class="text-center border p-2 my-2">
                CATEGORIES LISTING
            </div>
            <div class="text-center border p-2 my-2">
                PROUCT LISTING
            </div>
        </div>
        <div class="col-12 col-md-2  border">
            <div class="text-center bg-dark text-light">RIGHT BAR</div>

            <?php
                $mmDraw->drawMenus( 3, $previewall, $menuMaster->menu['menu_id'] );
            ?>
        </div>
    </div>
    <?php
        $mmDraw->drawMenus( 7, $previewall, $menuMaster->menu['menu_id'] );
    ?>
    <div class="form-row">
        <div class="col-12 border" style="min-height: 50px;">
            <div class="text-center bg-dark text-light">FOOTER</div>

        </div>
    </div>
</div>
<div class="container-fluid my-2 text-muted text-center mb-4">
    <?= MM_PREVIEW_NOTE ?>
</div>

