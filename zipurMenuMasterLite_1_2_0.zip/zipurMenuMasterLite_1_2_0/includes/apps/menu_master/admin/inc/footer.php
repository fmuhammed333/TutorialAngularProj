<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    //scripts to load at bottom
    if ( ! empty( $savestat ) && ! empty ( $menuMaster ) && ! empty( $menuMaster->menus ) && empty( $upgrade ) ) {
        ?>
        <script>
            mm_fade_alerts();
        </script>
        <?php
    }

?>
<script>
    $(function () {
        mm_color_pickers();
        mm_toggle_tooltips();
    });
</script>

<div class="modal fade" id="zipModal" tabindex="-1" role="dialog" aria-labelledby="zipModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="zipModalLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="<?= MM_CLOSE ?>">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary"
                        data-dismiss="modal"><?= MM_CLOSE ?>
                </button>
                <button type="button" class="btn btn-primary"
                        onClick=""><?= MM_SAVE_CHANGES ?>
                </button>
            </div>
        </div>
    </div>
</div>