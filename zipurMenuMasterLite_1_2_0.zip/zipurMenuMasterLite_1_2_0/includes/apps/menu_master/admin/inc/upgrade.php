<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $updates_path = DIR_FS_CATALOG . 'includes/apps/menu_master/admin/inc/mmupdates/';

    if ( empty( $upgradenow ) ) {
        ?>

        <div class="row">
            <div class="col m-4 text-center">
                <?= sprintf( MM_MENU_UPGRADE_TEXT, $menuMaster->settings['VERSION'], $mm_version ) ?>
                <br/>

                <?php

                    if ( $menuMaster->settings['VERSION'] != $mm_version ) {
                        if ( $dir = @dir( $updates_path ) ) {
                            while ( $file = $dir->read() ) {
                                if ( ! is_dir( "$updates_path/$file" ) ) {
                                    require $updates_path . '/' . $file;
                                    if ( version_compare( $menuMaster->settings['VERSION'], $update_settings['version'], '<' ) ) {

                                        ?>
                                        <div class="row my-4 border-top">
                                            <div class="col-12 col-md-8 col-xl-6 text-left pt-2 mx-auto">
                                                <strong><?= MM_MENU_UPGRADE_VERSION ?> <?= $update_settings['version'] ?>
                                                    <?= MM_MENU_UPGRADE_UPGRADES ?></strong><br/>
                                                <ul>
                                                    <?php
                                                        foreach ( $update_settings['items'] as $item ) {
                                                            ?>
                                                            <li class="m-2"><?= $item['text'] ?></li>
                                                            <?php
                                                        }
                                                    ?>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php

                                    }
                                }
                            }
                        }
                    } else {
                        ?>
                        <div class="col-12 p-4">
                            <button type="button" class="btn btn-sm border text-secondary border-secondary bg-light" onClick="window.location.href='zipur_menu_master.php';">
                                <i class="fas fa-arrow-left"></i> <?= MM_BACK_TO_MM ?>
                            </button>
                        </div>
                        <?php
                    }

                    if ( $menuMaster->settings['VERSION'] != $mm_version ) {
                        ?>
                        <button type="button" onClick="window.location.href='zipur_menu_master.php?upgrade=1&upgradenow=1';" class="btn btn-primary m-4">
                            <?= MM_MENU_UPGRADE_NOW ?>
                        </button>
                        <?php
                    }
                ?>

            </div>
        </div>
        <div class="row">
            <div class="col-12 text-right my-4 my-md-0">
                <a href="zipur_menu_master.php?uninstall=1" class="" style="color: #bbb;" data-toggle="tooltip" data-placement="top" title="<?= MM_UNINSTALL_TIP ?>"><i class="fas fa-trash-alt"></i>
                    <?= MM_UNINSTALL ?></a>
            </div>
        </div>
        <?php
    } else if ( $upgradenow == 1 ) {

        ?>
        <div class="row mb-4 text-center">
            <div class="col-12 p-4">
                <?php

                    if ( $menuMaster->settings['VERSION'] != $mm_version ) {
                        if ( $dir = @dir( $updates_path ) ) {
                            while ( $file = $dir->read() ) {
                                if ( ! is_dir( "$updates_path/$file" ) ) {
                                    require $updates_path . '/' . $file;
                                    if ( version_compare( $menuMaster->settings['VERSION'], $update_settings['version'], '<' ) ) {
                                        foreach ( $update_settings['sql'] as $sql ) {
                                            if ( ! empty( $sql ) ) {
                                                tep_db_query( $sql );
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    //update to latest code version
                    zipAlert( 'Menu Master (Lite) patched to version ' . $mm_version . '.', 'success' );
                    tep_db_query( "UPDATE menu_master_settings SET setting_val='$mm_version' WHERE setting_key='VERSION';" );

                    $query            = tep_db_query( "SELECT * FROM menu_master ORDER BY menu_id LIMIT 1" );
                    $menuMaster->menu = tep_db_fetch_array( $query );
                    if ( ! empty( $menuMaster->menu ) ) {
                        $menuMaster->loadMenu( $menuMaster->menu['menu_id'] );
                        $menuMaster->generateJSON();
                    }

                ?>
            </div>
            <div class="col-12 p-4">
                <button type="button" class="btn btn-sm border text-secondary border-secondary bg-light" onClick="window.location.href='zipur_menu_master.php';">
                    <i class="fas fa-arrow-left"></i> <?= MM_BACK_TO_MM ?>
                </button>
            </div>
        </div>
        <?php
    }


