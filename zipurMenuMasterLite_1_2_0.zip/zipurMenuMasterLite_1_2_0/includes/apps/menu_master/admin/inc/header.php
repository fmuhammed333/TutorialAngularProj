<?php
    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    //https://itsjavi.com/bootstrap-colorpicker/tutorial-Basics.html
    //Color Picker from https://github.com/itsjavi/bootstrap-colorpicker/
?>

    <link href="../includes/apps/menu_master/css/bootstrap-colorpicker.css" rel="stylesheet">
    <script src="../includes/apps/menu_master/js/bootstrap-colorpicker.js"></script>
    <script src="../includes/apps/menu_master/js/jquery.mjs.nestedSortable.js"></script>

<?php

    require( dirname( __FILE__ ) . '/style.php' );
    require( dirname( __FILE__ ) . '/script.php' );

    if ( ! empty( $menuMaster->menus ) && empty( $upgrade ) ) {

        ?>
        <div class="row mt-2 mx-2 py-2 mm-select-menu">
            <div class="col-8">
                <?php
                    if ( ! empty( $menuMaster->menus ) ) {
                ?>
                <div class="form-row align-items-center">
                    <?= MM_MENU_SELECT ?> <i class="fas fa-angle-double-right mt-1 mx-2"></i>
                    <div class="col-auto">
                        <?php
                            foreach ( $menuMaster->menus as $menu ) {
                                $selected_class = ( ! empty( $_SESSION['menumaster']['id'] ) && $_SESSION['menumaster']['id'] == $menu['menu_id'] ) ? 'success bg-success text-light' : 'border border-secondary text-secondary bg-light';
                                ?>
                                <button type="button" class="btn btn-sm <?= $selected_class ?>  mx-2 my-1 p-1 px-2" onClick="mm_select(<?= $menu['menu_id'] . ',' . $preview ?>);">
                                    <?= $menu['menu_name'] ?>
                                </button>
                                <?php
                            }
                            }
                        ?>
                    </div>
                    <div class="col-auto" id="mm-update-status"></div>
                    <?php
                        if ( $savestat != - 1 ) {
                            require( dirname( __FILE__ ) . '/savestat.php' );
                        }
                    ?>
                </div>

            </div>
            <div class="col-4 text-right">
                <div class="form-row align-items-center">
                    <div class="col-auto" data-toggle="tooltip" data-placement="bottom" title="<?= MM_MENU_TOOLTIPS_TIP ?>">
                        <div class="col custom-control custom-switch">
                            <input onChange="mm_update_setting('tooltips', 'checkbox'); mm_toggle_tooltips();" type="checkbox" class="custom-control-input mm_setting_tooltips" id="mm_setting_tooltips" name="mm_setting_tooltips" value="1" <?php if ( ! empty( $menuMaster->settings['TOOLTIPS'] ) ) {
                                echo 'CHECKED';
                            } ?>>
                            <label class="custom-control-label" for="mm_setting_tooltips"><small><?= MM_MENU_TOOLTIPS ?></small></label>
                        </div>
                    </div>
                    <div class="col-auto">
                        <button type="button" class="btn btn-sm border text-primary border-primary bg-light mx-2" onClick="mm_new();" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_NEW_TIP ?>">
                            <i class="fas fa-plus"></i> <?= MM_MENU_NEW ?>
                        </button>
                    </div>
                    <div class="col-auto">

                        <?php
                            $mods = mm_config_module_status( 'MODULE_NAVBAR_MM_MENU_STATUS', 1 );
                            $mods .= mm_config_module_status( 'MODULE_BOXES_MM_MENU_LEFT_STATUS', 2 );
                            $mods .= mm_config_module_status( 'MODULE_BOXES_MM_MENU_RIGHT_STATUS', 3 );
                            $mods .= mm_config_module_status( 'MODULE_CONTENT_HEADER_MM_MENU_STATUS', 4 );
                            $mods .= mm_config_module_status( 'MODULE_HEADER_TAGS_MM_MENU_STATUS', 10 );
                            if ( strpos( $mods, 'text-danger' ) !== false ) {
                                ?>
                                <button type="button" class="btn btn-sm border text-danger border-danger bg-light mx-2" onClick="mm_config();" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_MODULES_TIP ?>">
                                    <?php
                                        echo '<i class="fas fa-radiation fa-pulse text-warning"></i> ' . MM_MENU_MODULES_MISSING;
                                    ?>
                                </button>
                                <?php
                            } else {
                                ?>
                                <button type="button" class="btn btn-sm border text-secondary border-secondary bg-light mx-2" onClick="mm_config();" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_MODULES_TIP ?>">
                                    <?php

                                        echo '<i class="fas fa-cogs"></i> ' . MM_MENU_MODULES;
                                    ?>
                                </button>
                                <?php
                            }
                        ?>

                    </div>
                </div>


            </div>
            <hr/>
            <?php

            ?>
        </div>
        <?php

        $mm_show = [
            'save1'         => 1,
            'save2'         => 1,
            'publish'       => 1,
            'back'          => 0,
            'dupe'          => 1,
            'settings'      => 1,
            'delete'        => 0,
            'preview'       => 1,
            'previewall'    => 0,
            'previewsingle' => 0,
            'export'        => 0,
        ];

        if ( ! empty( $preview ) ) {
            $mm_show['save1']   = 0;
            $mm_show['save2']   = 0;
            $mm_show['dupe']    = 0;
            $mm_show['delete']  = 0;
            $mm_show['preview'] = 0;
            $mm_show['publish'] = 0;
            $mm_show['back']    = 1;

            if ( empty( $previewall ) ) {
                $mm_show['previewall'] = 1;
            } else {
                $mm_show['previewsingle'] = 1;
            }
        }
        if ( ! empty( $settings ) ) {
            $mm_show['save1']    = 0;
            $mm_show['settings'] = 0;
            $mm_show['delete']   = 1;
            $mm_show['back']     = 1;
            $mm_show['publish']  = 0;
            $mm_show['export']   = 1;
        }
        if ( ! empty( $upgrade ) ) {
            $mm_show['save1']    = 0;
            $mm_show['save2']    = 0;
            $mm_show['preview']  = 0;
            $mm_show['dupe']     = 0;
            $mm_show['settings'] = 0;
            $mm_show['publish']  = 0;
        }
        if ( ! empty( $upgradenow ) ) {
            $mm_show['back'] = 1;
        }
        if ( ! empty( $config ) ) {
            $mm_show['back']    = 1;
            $mm_show['save1']   = 0;
            $mm_show['save2']   = 0;
            $mm_show['dupe']    = 0;
            $mm_show['preview'] = 0;
            $mm_show['publish'] = 0;

        }

        if ( ! empty( $dupe ) ) {
            $mm_show['back']    = 1;
            $mm_show['save1']   = 0;
            $mm_show['save2']   = 0;
            $mm_show['dupe']    = 0;
            $mm_show['preview'] = 0;
            $mm_show['publish'] = 0;

        }
        if ( ! empty( $new ) ) {
            $mm_show['back']    = 1;
            $mm_show['save1']   = 0;
            $mm_show['save2']   = 0;
            $mm_show['dupe']    = 0;
            $mm_show['preview'] = 0;
            $mm_show['publish'] = 0;

        }
        if ( ! empty( $uninstall ) ) {
            $mm_show['back']    = 1;
            $mm_show['save1']   = 0;
            $mm_show['save2']   = 0;
            $mm_show['dupe']    = 0;
            $mm_show['preview'] = 0;
            $mm_show['publish'] = 0;

        }
        if ( ! empty( $backup ) ) {
            $mm_show['back']    = 1;
            $mm_show['save1']   = 0;
            $mm_show['save2']   = 0;
            $mm_show['dupe']    = 0;
            $mm_show['preview'] = 0;
            $mm_show['publish'] = 0;

        }

        ?>
        <div class="row mb-2 mx-2 border-top border-bottom p-2 mm-select-menu bg-light">

            <div class="col-12 col-md-4">
                <label for="mm_name" class="mr-4"><?= MM_MENU_SELECTED ?>:</label>
                <strong class="text-primary mr-4"><?= $menuMaster->menu['menu_name'] ?></strong>
                <?php
                    if ( ! empty( $mm_show['publish'] ) ) {
                        ?>
                        <button type="button" class="btn btn-sm btn-primary mx-2" onClick="mm_publish_menu(1);" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_PUBLISH_TIP ?>">
                            <i class="fas fa-upload"></i> <?= MM_MENU_PUBLISH ?>
                        </button>
                        <?php
                    }
                ?>
            </div>
            <div class="col-12 col-md-8 text-right">
                <?php
                    if ( ! empty( $mm_show['back'] ) ) {
                        ?>
                        <button type="button" class="btn btn-sm border text-secondary border-secondary bg-light mr-4" onClick="mm_main();">
                            <i class="fas fa-arrow-left"></i> <?= MM_MENU_BACK ?>
                        </button>
                        <?php
                    }

                    if ( ! empty( $mm_show['save1'] ) ) {
                        ?>
                        <button type="button" class="btn btn-sm border text-success border-success bg-light mx-2" onClick="mm_save_menu(0);" data-toggle="tooltip" data-placement="top" title="<?= MM_SAVE_CHANGES_TIP ?>">
                            <i class="fas fa-save"></i> <?= MM_SAVE_CHANGES ?>
                        </button>
                        <?php
                    } else if ( ! empty( $mm_show['save2'] ) ) {
                        ?>

                        <button type="button" onClick="formwatchsomethingChanged = false; document.zipur_menu_master_settings.submit();" class="btn btn-sm border text-success border-success bg-light mr-4">
                            <i class="fas fa-save"></i> <?= MM_SAVE_CHANGES ?>
                        </button>

                        <?php

                    }

                    if ( ! empty( $mm_show['preview'] ) ) {

                        ?>
                        <button type="button" class="btn btn-sm border text-muted border-muted bg-light m-2" onClick="mm_preview(0);" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_PREVIEW_TIP ?>">
                            <i class="fas fa-eye"></i> <?= MM_MENU_PREVIEW ?>
                        </button>
                        <?php
                    }

                    if ( ! empty( $mm_show['previewsingle'] ) ) {

                        ?>
                        <button type="button" class="btn btn-sm border text-muted border-muted bg-light m-2" onClick="mm_preview(0);" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_PREVIEW_TIP ?>">
                            <i class="fas fa-eye"></i> <?= MM_MENU_PREVIEW_SELECTED ?>
                        </button>
                        <?php
                    }

                    if ( ! empty( $mm_show['previewall'] ) ) {

                        ?>
                        <button type="button" class="btn btn-sm border text-muted border-muted bg-light m-2" onClick="mm_preview(1);" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_PREVIEW_ALL_TIP ?>">
                            <i class="fas fa-eye"></i> <?= MM_MENU_PREVIEW_ALL ?>
                        </button>
                        <?php
                    }
                    if ( ! empty( $mm_show['dupe'] ) ) {

                        ?>
                        <button type="button" class="btn btn-sm border text-muted border-muted bg-light mx-2" onClick="mm_duplicate();" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_DUPLICATE_TIP ?>">
                            <i class="fas fa-clone"></i> <?= MM_MENU_DUPLICATE ?>
                        </button>
                        <?php
                    }
                    if ( ! empty( $mm_show['export'] ) ) {

                        ?>
                        <button type="button" class="btn btn-sm border text-muted border-muted bg-light mx-2" onClick="mm_export();" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_EXPORT_TIP ?>">
                            <i class="fas fa-file-export"></i> <?= MM_MENU_EXPORT ?>
                        </button>
                        <?php
                    }
                    if ( ! empty( $mm_show['export'] ) ) {

                        ?>
                        <button type="button" class="btn btn-sm border text-muted border-muted bg-light mx-2" onClick="mm_import();" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_IMPORT_TIP ?>">
                            <i class="fas fa-file-import"></i> <?= MM_MENU_IMPORT ?>
                        </button>
                        <?php
                    }

                    if ( ! empty( $mm_show['settings'] ) ) {
                        ?>
                        <button type="button" class="btn btn-sm border text-muted border-muted bg-light mx-2" onClick="window.location.href='zipur_menu_master.php?settings=1';">
                            <i class="fas fa-cogs"></i> <?= MM_MENU_SETTINGS ?>
                        </button>
                        <?php

                    }

                    if ( ! empty( $mm_show['delete'] ) ) {
                        ?>
                        <button type="button" class="btn btn-sm border text-danger border-danger bg-light" onClick="mm_delete(<?= $menuMaster->menu['menu_id'] ?>);" data-toggle="tooltip" data-placement="top" title="<?= MM_MENU_DELETE_TIP ?>">
                            <i class="fas fa-trash"></i> <?= MM_MENU_DELETE ?>
                        </button>
                        <?php
                    }
                ?>
            </div>
        </div>
        <?php
    }

