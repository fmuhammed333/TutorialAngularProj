<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    if ( empty( $_SESSION['menumaster']['id'] ) ) {

        ?>
        <div class="container">
            <div class="p-2">
                <div class="row">
                    <div class="col-12">
                        <h3><?= MM_LAYOUT_WELCOME ?></h3>
                    </div>
                </div>
            </div>
            <div class="p-2">
                <div class="row">
                    <div class="col-12">
                        <?= MM_LAYOUT_CHOOSE ?>
                    </div>
                </div>

            </div>
        </div>
        <?php

    } else {
        ?>
        <div class="p-2">
            <div class="row">
                <div class="col-12 col-md-3">
                    <h5 class="m-0"><?= MM_LAYOUT_HEADING ?></h5>
                </div>
                <div class="col-12 col-md-9">
                    <div id="mm_locations_box" class="text-right w-100">
                        <?php
                            $menuMaster->drawMenuLocations();
                        ?>
                    </div>
                </div>
            </div>

        </div>
        <div class="p-2" style="font-size: 0.8em;">
            <?= MM_LAYOUT_TIP ?>
        </div>
        <div id="mm_layout" class="border p-2 col-12">
            <?php
                if ( empty( $menuMaster->menu['menu_id'] ) ) {
                    echo MM_LAYOUT_NONE_SELECTED;
                } else {
                    ?>
                    <ul class="accordion" id="MenuItems">
                        <?php
                            $menuMaster->drawItems( '' );
                        ?>
                    </ul>

                    <?php
                }
            ?>
        </div>
        <script>
            $(function () {
                mm_assign_sortable();
            });
        </script>
        <?php
    }