<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

?>

<form method="post" action="zipur_menu_master.php" name="zipur_menu_master_dupe">
    <div class="container">
        <div class="row">
            <div class="col col-12">
                <h5><?= MM_DUPE_MENU ?> - <?= $menuMaster->menu['menu_name'] ?></h5>
                <div class="border p-2 bg-light">
                    <div class="row">
                        <div class="col-6">
                            <?= MM_DUPE_NEW_NAME ?> <input type="text" class="form-control" id="mm_name" name="mm_name" value="" required disabled/>
                        </div>
                        <div class="col-3">
                           <?= mm_upgrade_this_pro_box() ?>
                        </div>
                        <div class="col-3 text-right">
                            <button type="button" class="btn btn-sm border text-secondary border-secondary bg-light" onClick="mm_main();">
                                <?= MM_CANCEL ?>
                            </button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <small class="text-muted"><?= sprintf(MM_DUPE_NEW_NAME_TIP, $menuMaster->menu['menu_name'] ) ?></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" name="save" value="1"/>
    <input type="hidden" name="dupe" value="1"/>
</form>