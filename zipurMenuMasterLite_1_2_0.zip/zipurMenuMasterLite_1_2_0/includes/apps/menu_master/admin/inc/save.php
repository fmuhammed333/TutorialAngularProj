<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    if ( ! empty( $new ) ) {
        //New Menu
        $mm_name = zipVarCheck( 'mm_name', '' );
        if ( empty( $mm_name ) ) {
            tep_redirect( tep_href_link( 'zipur_menu_master.php', 'savestat=0' ) );
        } else {
            $menuMaster->newMenu( $mm_name );


            $mods = '';
            $mods .= mm_config_module_status( 'MODULE_NAVBAR_MM_MENU_STATUS', 1 );
            $mods .= mm_config_module_status( 'MODULE_BOXES_MM_MENU_LEFT_STATUS', 2 );
            $mods .= mm_config_module_status( 'MODULE_BOXES_MM_MENU_RIGHT_STATUS', 3 );
            $mods .= mm_config_module_status( 'MODULE_CONTENT_HEADER_MM_MENU_STATUS', 4 );
            $mods .= mm_config_module_status( 'MODULE_CONTENT_PI_MM_MENU_STATUS', 5 );
            $mods .= mm_config_module_status( 'MODULE_CONTENT_SC_MM_MENU_STATUS', 6 );
            $mods .= mm_config_module_status( 'MODULE_CONTENT_CHECKOUT_SUCCESS_MM_MENU_STATUS', 7 );
            $mods .= mm_config_module_status( 'MODULE_CONTENT_IN_MM_MENU_STATUS', 8 );
            $mods .= mm_config_module_status( 'MODULE_CONTENT_IP_MM_MENU_STATUS', 9 );
            $mods .= mm_config_module_status( 'MODULE_HEADER_TAGS_MM_MENU_STATUS', 10 );

            if ( strpos( $mods, 'text-danger' ) !== false ) {
                tep_redirect( tep_href_link( 'zipur_menu_master.php', 'savestat=1&mm_id=' . $menuMaster->menu['menu_id'] . '&config=1' ) );
            } else {
                tep_redirect( tep_href_link( 'zipur_menu_master.php', 'savestat=1&mm_id=' . $menuMaster->menu['menu_id'] ) );

            }

        }
    } else if ( ! empty( $delete ) ) {
        //Duplicate Menu
        $menuid = zipVarCheck( 'menuid', 0, 'FILTER_VALIDATE_INT', 0 );
        if ( empty( $menuid ) ) {
            tep_redirect( tep_href_link( 'zipur_menu_master.php', 'savestat=0' ) );
        } else {
            $menuMaster->deleteMenu( $menuid );
            tep_redirect( tep_href_link( 'zipur_menu_master.php', 'savestat=1&mm_id=' . $menuMaster->menu['menu_id'] ) );
        }
    } else if ( ! empty( $update ) ) {

        if ( ! empty( $_SESSION['menumaster']['id'] ) ) {

            $mm_import_template = zipVarCheck( 'mm_import_template', '' );

            if ( ! empty( $mm_import_template ) ) {

                //IMPORT TEMPLATE
                $importing       = 1;
                $mm_template_dir = DIR_FS_CATALOG . 'includes/apps/menu_master/admin/templates/';
                $code            = '';
                if ( file_exists( $mm_template_dir . $mm_import_template ) ) {
                    $code = file_get_contents( $mm_template_dir . $mm_import_template );
                }

            } else if ( ! empty( $_FILES ) ) {
                //IMPORT
                $importing = 1;
                foreach ( $_FILES as $value ) {
                    $code = '';
                    if ( ! empty( $value['tmp_name'] ) ) {
                        if ( file_exists( $value['tmp_name'] ) ) {
                            $code = file_get_contents( $value['tmp_name'] );
                        }
                    }
                }

            } else {

                $menuMaster->loadMenu( $_SESSION['menumaster']['id'] );

                $menuMaster->menu['menu_name']      = zipVarCheck( 'mm_name', '' );
                $menuMaster->menu['menu_class']     = zipVarCheck( 'mm_class', '' );
                $menuMaster->menu['menu_status']    = zipVarCheck( 'mm_menu_status', 0, 'FILTER_VALIDATE_INT', 0 );
                $menuMaster->menu['sort_order']     = zipVarCheck( 'mm_sort_order', 0, 'FILTER_VALIDATE_INT', 0 );
                $menuMaster->menu['show_on_mobile'] = zipVarCheck( 'mm_show_on_mobile', 0, 'FILTER_VALIDATE_INT', 0 );
                $menuMaster->menu['menu_sticky']    = 0;
                $menuMaster->menu['menu_style']     = zipVarCheck( 'mm_menu_style', 0, 'FILTER_VALIDATE_INT', 0 );
                $menuMaster->menu['color_type']     = zipVarCheck( 'mm_color_type', 0, 'FILTER_VALIDATE_INT', 0 );
                $menuMaster->menu['menu_fill']      = zipVarCheck( 'mm_menu_fill', 0, 'FILTER_VALIDATE_INT', 0 );

                foreach ( $menuMaster->languages as $languageitem ) {
                    $menuMaster->menu[ 'label_text_' . $languageitem['code'] ] = zipVarCheck( 'mm_label_text_' . $languageitem['code'], '' );
                }

                $menuMaster->menu['menu_bar_bg_color']      = zipVarCheck( 'mm_menu_bar_bg_color', '' );
                $menuMaster->menu['menu_bar_border_color']  = zipVarCheck( 'mm_menu_bar_border_color', '' );
                $menuMaster->menu['menu_bar_padding']       = zipVarCheck4Pixel( 'mm_menu_bar_padding' );
                $menuMaster->menu['menu_bar_margin']        = zipVarCheck4Pixel( 'mm_menu_bar_margin' );
                $menuMaster->menu['menu_bar_border_radius'] = zipVarCheck4Pixel( 'mm_menu_bar_border_radius' );
                $menuMaster->menu['border_radius']          = zipVarCheck4Pixel( 'mm_border_radius' );
                $menuMaster->menu['menu_bar_border_width']  = zipVarCheck4Pixel( 'mm_menu_bar_border_width' );

                $menuMaster->menu['link_color'] = zipVarCheck( 'mm_link_color', '' );
                $menuMaster->menu['link_hover'] = zipVarCheck( 'mm_link_hover', '' );

                $menuMaster->menu['bg_color'] = zipVarCheck( 'mm_bg_color', '' );
                $menuMaster->menu['bg_hover'] = zipVarCheck( 'mm_bg_hover', '' );

                $menuMaster->menu['border_color'] = zipVarCheck( 'mm_border_color', '' );
                $menuMaster->menu['border_hover'] = zipVarCheck( 'mm_border_hover', '' );

                $menuMaster->menu['border_width'] = zipVarCheck4Pixel( 'mm_border_width' );
                $menuMaster->menu['padding']      = zipVarCheck4Pixel( 'mm_padding' );
                $menuMaster->menu['margin']       = zipVarCheck4Pixel( 'mm_margin' );

                $menuMaster->menu['menu_align']          = zipVarCheck( 'mm_menu_align', '' );
                $menuMaster->menu['child_link_color']    = zipVarCheck( 'mm_child_link_color', '' );
                $menuMaster->menu['child_link_hover']    = zipVarCheck( 'mm_child_link_hover', '' );
                $menuMaster->menu['child_bg_color']      = zipVarCheck( 'mm_child_bg_color', '' );
                $menuMaster->menu['child_bg_hover']      = zipVarCheck( 'mm_child_bg_hover', '' );
                $menuMaster->menu['child_border_color']  = zipVarCheck( 'mm_child_border_color', '' );
                $menuMaster->menu['child_border_hover']  = zipVarCheck( 'mm_child_border_hover', '' );
                $menuMaster->menu['child_border_width']  = zipVarCheck4Pixel( 'mm_child_border_width' );
                $menuMaster->menu['child_padding']       = zipVarCheck4Pixel( 'mm_child_padding' );
                $menuMaster->menu['child_margin']        = zipVarCheck4Pixel( 'mm_child_margin' );
                $menuMaster->menu['child_border_radius'] = zipVarCheck4Pixel( 'mm_child_border_radius' );

                $menuMaster->menu['menu_font']            = zipVarCheck( 'mm_menu_font', '' );
                $menuMaster->menu['menu_font_size']       = zipVarCheck( 'mm_menu_font_size', '' );
                $menuMaster->menu['child_menu_font']      = zipVarCheck( 'mm_child_menu_font', '' );
                $menuMaster->menu['child_font_size']      = zipVarCheck( 'mm_child_font_size', '' );
                $menuMaster->menu['hamburger_bg_color']   = zipVarCheck( 'mm_hamburger_bg_color', '' );
                $menuMaster->menu['hamburger_color']      = zipVarCheck( 'mm_hamburger_color', '' );
                $menuMaster->menu['hamburger_placement']  = zipVarCheck( 'mm_hamburger_placement', '' );
                $menuMaster->menu['hamburger_breakpoint'] = zipVarCheck( 'mm_hamburger_breakpoint', '' );
                $menuMaster->menu['menu_icon_close']      = zipVarCheck( 'mm_menu_icon_close', '' );
                $menuMaster->menu['menu_icon_open']       = zipVarCheck( 'mm_menu_icon_open', '' );
                $menuMaster->menu['customcss']            = zipVarCheck( 'mm_customcss', '' );
                $menuMaster->menu['hamburger_code']       = zipVarCheck( 'mm_hamburger_code', '' );
                $menuMaster->menu['hamburger_code']       = str_replace( '"', '&quot;', $menuMaster->menu['hamburger_code'] );

                $mm_export = zipVarCheck( 'mm_export', 0, 'FILTER_VALIDATE_INT', 0 );

                if ( empty( $menuMaster->menu['menu_name'] ) ) {
                    tep_redirect( tep_href_link( 'zipur_menu_master.php', 'savestat=0' ) );
                } else {
                    $menuMaster->saveMenu();

                    if ( empty( $mm_export ) ) {
                        $mm_tab_id   = zipVarCheck( 'mm_tab_id', 1, 'FILTER_VALIDATE_INT', 1 );

                        tep_redirect( tep_href_link( 'zipur_menu_master.php', 'settings=1&savestat=1&mm_id=' . $menuMaster->menu['menu_id'] . '&mm_tab_id=' . $mm_tab_id ) );
                    } else {
                        //create json file and download

                        $file_name = preg_replace( '/[^0-9a-zA-Z ]/', '', $menuMaster->menu['menu_name'] );
                        $file_name = str_replace( ' ', '_', $file_name );
                        $file_name = strtolower( $file_name );

                        $json = json_encode( $menuMaster->menu );
                        header( 'Content-Description: File Transfer' );
                        header( 'Content-Type: application/octet-stream' );
                        header( 'Content-disposition: attachment; filename=mm_tpl_' . $file_name . '.cfg' );
                        header( 'Content-Length: ' . strlen( $json ) );
                        header( 'Cache-Control: must-revalidate, post-check=0, pre-check=0' );
                        header( 'Expires: 0' );
                        header( 'Pragma: public' );
                        echo $json;
                        exit;
                    }
                }
            }

            //IMPORT
            if ( ! empty( $importing ) ) {
                if ( ! empty( $code ) ) {
                    $code = json_decode( $code );
                    $menuMaster->loadMenu( $_SESSION['menumaster']['id'] );
                    $menuMaster->importing = 1;
                    foreach ( $code as $key => $item ) {
                        if ( $key != 'menu_id' && $key != 'menu_name' ) {
                            $menuMaster->menu[ $key ] = $item;
                        }
                    }
                    $menuMaster->saveMenu();
                    tep_redirect( tep_href_link( 'zipur_menu_master.php', 'settings=1&savestat=1&mm_id=' . $menuMaster->menu['menu_id'] ) );
                } else {
                    zipAlert( 'Import Failed', 'danger' );
                }
            }
        }

    }

    $save = 0;