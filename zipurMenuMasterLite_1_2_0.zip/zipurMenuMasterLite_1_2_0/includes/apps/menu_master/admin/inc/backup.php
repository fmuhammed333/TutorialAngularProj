<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $mm_backup_dir = DIR_FS_CATALOG . 'includes/apps/menu_master/admin/backups/';
    $deletebu      = zipVarCheck( 'deletebu', 0, 'FILTER_VALIDATE_INT', 0 );
    $mm_restore    = zipVarCheck( 'mm_restore', '' );

    if ( ! empty( $deletebu ) ) {
        if ( substr( $mm_restore, - 4, 4 ) == 'mmbu' ) {
            unlink( $mm_backup_dir . $mm_restore );
        }
    }
?>


<form method="post" action="zipur_menu_master.php" name="zipur_menu_master_dupe">
    <div class="container">
        <div class="row">
            <div class="col col-12">
                <h5><?= MM_BACKUP_BACKUPS ?></h5>

                <?= mm_upgrade_this_pro_box() ?>


            </div>
        </div>
        <div class="row">
            <div class="col col-12 border mx-4 p-4">

                <?php
                    $hasbu = 0;

                    if ( empty( $hasbu )) {
                        echo 'No backups have been completed.';

                        ?>
                            <br/>
                            <br/>
                        <button type="button" class="btn btn-sm border text-secondary border-secondary bg-light mx-auto" onClick="mm_main();">
                            <i class="fas fa-arrow-left"></i> <?= MM_MENU_BACK ?>
                        </button>
                        <?php
                    }
                ?>
            </div>
        </div>
    </div>
    <input type="hidden" name="save" value="1"/>
    <input type="hidden" name="dupe" value="1"/>
</form>