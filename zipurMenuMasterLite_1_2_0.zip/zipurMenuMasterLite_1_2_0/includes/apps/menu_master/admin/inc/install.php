<?php

    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    if ( empty( $menuinstall ) ) {
        ?>
        <div class="row">
            <div class="col m-4 text-center">
                <?= MENU_MASTER_INSTALL_TEXT ?><br/>
                <button type="button" onClick="window.location.href='zipur_menu_master.php?menuinstall=1';" class="btn btn-primary m-4  "><?= MENU_MASTER_INSTALL_NOW ?></button>
            </div>
        </div>
        <?php
    } else if ( $menuinstall == 1 ) {

        tep_db_query( 'CREATE TABLE menu_master_settings
                    (
                        setting_key VARCHAR(20) NOT NULL,
                        setting_val VARCHAR(254) NOT NULL
                    )
                    DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;' );

        tep_db_query( "CREATE TABLE menu_master
                    (
                        menu_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                        menu_name VARCHAR(50) NOT NULL DEFAULT '',
                        menu_class VARCHAR(254) NOT NULL DEFAULT '',
                        menu_status INT(2) NOT NULL DEFAULT 1,
                        link_color VARCHAR(35) NOT NULL DEFAULT '#007BFF',
                        link_hover VARCHAR(35) NOT NULL DEFAULT '#024995',
                        bg_color VARCHAR(35) NOT NULL DEFAULT '#E9ECEF',
                        bg_hover VARCHAR(35) NOT NULL DEFAULT '#F5F5F5',
                        border_color VARCHAR(35) NOT NULL DEFAULT '#F5F5F5',
                        border_hover VARCHAR(35) NOT NULL DEFAULT '#E9ECEF',
                        menu_font VARCHAR(254) NOT NULL DEFAULT '',
                        child_menu_font VARCHAR(254) NOT NULL DEFAULT '',
                        menu_font_size VARCHAR(10) NOT NULL DEFAULT '1em',
                        child_font_size VARCHAR(10) NOT NULL DEFAULT '1em',
                        menu_bar_border_width VARCHAR(20) NOT NULL DEFAULT '1px 1px 1px 1px',
                        child_link_color VARCHAR(35) NOT NULL DEFAULT '#EEEEEE',
                        child_link_hover VARCHAR(35) NOT NULL DEFAULT '#DDDDDD',
                        hamburger_color VARCHAR(35) NOT NULL DEFAULT '#eeeeee',
                        hamburger_bg_color VARCHAR(35) NOT NULL DEFAULT '#333333',
                        child_bg_color VARCHAR(35) NOT NULL DEFAULT '#333333',
                        child_bg_hover VARCHAR(35) NOT NULL DEFAULT '#666666',
                        child_border_color VARCHAR(35) NOT NULL DEFAULT '#222222',
                        child_border_hover VARCHAR(35) NOT NULL DEFAULT '#444444',
                        child_border_width VARCHAR(20) NOT NULL DEFAULT '1px 1px 1px 1px',
                        menu_align VARCHAR(10) NOT NULL DEFAULT 'left',
                        menu_fill INT(2) NOT NULL DEFAULT 0,
                        show_on_mobile INT(2) NOT NULL DEFAULT 1,
                        menu_sticky INT(2) NOT NULL DEFAULT 0,
                        menu_style VARCHAR(35) NOT NULL DEFAULT '0',
                        menu_bar_bg_color  VARCHAR(35) NOT NULL DEFAULT '#E9ECEF',
                        menu_bar_border_color  VARCHAR(35) NOT NULL DEFAULT '#F5F5F5',
                        menu_bar_padding  VARCHAR(20) NOT NULL DEFAULT '1px 1px 1px 1px',
                        menu_bar_margin  VARCHAR(20) NOT NULL DEFAULT '0px 0px 0px 0px',
                        menu_bar_border_radius  VARCHAR(20) NOT NULL DEFAULT '0px 0px 0px 0px',
                        border_radius  VARCHAR(20) NOT NULL DEFAULT '0px 0px 0px 0px',
                        child_border_radius  VARCHAR(20) NOT NULL DEFAULT '0px 0px 0px 0px',
                        padding  VARCHAR(20) NOT NULL DEFAULT '1px 1px 1px 1px',
                        child_padding  VARCHAR(20) NOT NULL DEFAULT '1px 1px 1px 1px',
                        margin  VARCHAR(20) NOT NULL DEFAULT '1px 1px 1px 1px',
                        child_margin  VARCHAR(20) NOT NULL DEFAULT '1px 1px 1px 1px',
                        border_width VARCHAR(20) NOT NULL DEFAULT '1px 1px 1px 1px',
                        color_type INT(2) NOT NULL DEFAULT 0,
                        hamburger_placement VARCHAR(6) NOT NULL DEFAULT 'right',
                        hamburger_breakpoint VARCHAR(6) NOT NULL DEFAULT 'md',
                        menu_icon_close VARCHAR(50) NOT NULL DEFAULT 'fa-plus',
                        menu_icon_open VARCHAR(50) NOT NULL DEFAULT 'fa-minus',
                        customcss TEXT NOT NULL DEFAULT '',
                        hamburger_code VARCHAR(254) NOT NULL DEFAULT '<i class=\"fas fa-bars\"></i>',
                        sort_order INT(4) DEFAULT 0
                        
                    )
                    DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;" );

        tep_db_query( 'CREATE TABLE menu_master_to_location
                    (
                        menu_id INT(6),
                        menu_location VARCHAR(20) NOT NULL
                    )
                    DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;' );

        tep_db_query( 'CREATE TABLE menu_master_language
                    (
                        menu_id INT(6),
                        language_id INT(2),
                        label_text VARCHAR(100) NOT NULL
                    )
                    DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;' );

        tep_db_query( 'CREATE TABLE menu_master_items_language
                    (
                        menu_id INT(6),
                        menu_item_id INT(6),
                        language_id INT(2),
                        item_name VARCHAR(100) NOT NULL
                    )
                    DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;' );

        tep_db_query( "CREATE TABLE menu_master_items
                    (
                        menu_item_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                        menu_id INT(6) DEFAULT 0,
                        pages_id INT(6) DEFAULT 0,
                        phoenix_pages_id INT(2) DEFAULT 0,
                        special_items_id INT(2) DEFAULT 0,
                        categories_id INT(6) DEFAULT 0,
                        menu_levels INT(2) DEFAULT 1,
                        products_id INT(6) DEFAULT 0,
                        item_align VARCHAR(35) NOT NULL DEFAULT '',
                        item_valign VARCHAR(35) NOT NULL DEFAULT '',
                        parent_uuid VARCHAR(100) NOT NULL DEFAULT '',
                        sort_order INT(4) DEFAULT 0,
                        item_url VARCHAR(254) NOT NULL DEFAULT '',
                        item_target VARCHAR(35) NOT NULL DEFAULT '',
                        item_class VARCHAR(254) NOT NULL DEFAULT '',
                        item_status INT(2) NOT NULL DEFAULT 0,
                        link_color VARCHAR(35) NOT NULL DEFAULT '',
                        link_hover VARCHAR(35) NOT NULL DEFAULT '',
                        bg_color VARCHAR(35) NOT NULL DEFAULT '',
                        bg_hover VARCHAR(35) NOT NULL DEFAULT '',
                        show_on_mobile INT(2) NOT NULL DEFAULT 0,
                        restrict_basket INT(2) NOT NULL DEFAULT 0,
                        restrict_loggedin INT(2) NOT NULL DEFAULT 0,
                        item_image VARCHAR(254) NOT NULL DEFAULT '',
                        menu_has_children INT(2) NOT NULL DEFAULT 0,
                        uuid VARCHAR(100) NOT NULL DEFAULT '',
                        fa_icon VARCHAR(50) NOT NULL DEFAULT '',
                        item_breakpoint_hide VARCHAR(10) NOT NULL DEFAULT 'smmdlgxl',
                        item_icon_show INT(2) NOT NULL DEFAULT 0, 
                        mega_menu INT(2) NOT NULL DEFAULT 0, 
                        hamburger_code VARCHAR(254) NOT NULL DEFAULT '<i class=\"fas fa-bars\"></i>'
                        
                    )
                    DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;" );

        tep_db_query( "INSERT INTO menu_master_settings (setting_key, setting_val) VALUES  ('TOOLTIPS', '1');" );
        tep_db_query( "INSERT INTO menu_master_settings (setting_key, setting_val) VALUES  ('VERSION', '$mm_version');" );


        ?>
        <div class="container">
            <?php
                zipAlert( MENU_MASTER_INSTALLED . '<br/><button type="button" onClick="window.location.href=\'zipur_menu_master.php\';" class="btn btn-success p-2 mt-4">' . MENU_MASTER_INSTALL_CLICK . ' <i class="fas fa-arrow-right"></i></button>', 'success mx-auto p-4 text-center w-50' );

            ?>
        </div>
        <?php

    }