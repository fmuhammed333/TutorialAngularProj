<?php

    

/*
* $Id: base.php
* $Loc: /includes/apps/menu_master/admin/
*
* Name: zipurMenuMasterLite
* Version: 1.2.0
* Release Date: 01/08/2022
* Author: Preston Lord
* 	 phoenixaddons.com / @zipurman / plord@inetx.ca
*
* License: Commercial License
* 
* Cannot be distributed
*  
* Commercial use allowed
*  
* Cannot modify source-code for any purpose (cannot create derivative works)
*
* Comments: Copyright (c) 2021: Preston Lord - @zipurman - Intricate Networks Inc.
* 
* All rights reserved.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
* (Packaged with Zipur Bundler v2.0.2)
*/





    if ( ! defined( "MENU_MASTER" ) ) {
        die;
    }

    $mm_version = '1.2.0';

    require( dirname( __FILE__, 1 ) . '/functions/functions.php' );

    $mm_is_installed = zipCheckDBTableExists( 'menu_master' );

    if ( $mm_is_installed ) {
        $menuMaster = new menuMaster();
        $commtype   = zipVarCheck( "commtype", '' );
        $backup    = zipVarCheck( 'backup', 0, 'FILTER_VALIDATE_INT', 0 );
        $upgrade    = zipVarCheck( 'upgrade', 0, 'FILTER_VALIDATE_INT', 0 );
        $upgradenow = zipVarCheck( 'upgradenow', 0, 'FILTER_VALIDATE_INT', 0 );
        $menuuninstall = zipVarCheck( 'menuuninstall', 0, 'FILTER_VALIDATE_INT', 0 );
        $uninstall     = zipVarCheck( 'uninstall', 0, 'FILTER_VALIDATE_INT', 0 );
        zipVersionCleanUp( $upgrade );
    }

    if ( ! empty( $upgrade ) && empty( $menuuninstall ) ) {

        require( DIR_FS_ADMIN . 'includes/template_top.php' );
        require( dirname( __FILE__ ) . '/inc/upgrade.php' );

    } else {

        if ( ! empty( $commtype ) ) {
            if ( strpos( $commtype, '..' ) !== false ) {
                die();
            }
            if ( ! empty( $_SESSION['menumaster']['id'] ) ) {
                $menuMaster->loadMenu( $_SESSION['menumaster']['id'] );
            }
            require( DIR_FS_CATALOG . 'includes/apps/menu_master/admin/comm/' . $commtype . '.php' );

        } else {

            require( dirname( __FILE__ ) . '/inc/reg.php' );

            if ( ! empty( $save ) ) {
                require( dirname( __FILE__ ) . '/inc/save.php' );
            }

            require( DIR_FS_ADMIN . 'includes/template_top.php' );

            zipAdBanner();

            zipCEPBanner();

            require( dirname( __FILE__ ) . '/inc/header.php' );

            ?>
            <div class="container-fluid">
                <?php

                    if ( ! $mm_is_installed ) {
                        require( dirname( __FILE__ ) . '/inc/install.php' );
                    } else if ( ! empty( $uninstall ) ) {
                        require( dirname( __FILE__ ) . '/inc/uninstall.php' );
                    } else if ( ! empty( $preview ) ) {
                        require( dirname( __FILE__ ) . '/inc/preview.php' );
                    } else if ( ! empty( $dupe ) ) {
                        require( dirname( __FILE__ ) . '/inc/dupe.php' );
                    } else if ( ! empty( $new ) ) {
                        require( dirname( __FILE__ ) . '/inc/new.php' );
                    } else if ( ! empty( $settings ) ) {
                        require( dirname( __FILE__ ) . '/inc/settings.php' );
                    } else if ( ! empty( $config ) ) {
                        require( dirname( __FILE__ ) . '/inc/config.php' );
                    } else if ( ! empty( $backup ) ) {
                        require( dirname( __FILE__ ) . '/inc/backup.php' );
                    } else {
                        require( dirname( __FILE__ ) . '/inc/main.php' );
                    }

                ?>
            </div>
            <?php
            require( dirname( __FILE__ ) . '/inc/footer.php' );

            //make sure template_bottom and application_bottom load on initial page load
            unset( $commtype );
        }
    }