<?php



/*
* $Id: menuMasterDraw.php
* $Loc: /includes/apps/menu_master/classes/
*
* Name: zipurMenuMasterLite
* Version: 1.2.0
* Release Date: 01/08/2022
* Author: Preston Lord
* 	 phoenixaddons.com / @zipurman / plord@inetx.ca
*
* License: Commercial License
* 
* Cannot be distributed
*  
* Commercial use allowed
*  
* Cannot modify source-code for any purpose (cannot create derivative works)
*
* Comments: Copyright (c) 2021: Preston Lord - @zipurman - Intricate Networks Inc.
* 
* All rights reserved.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
* (Packaged with Zipur Bundler v2.0.2)
*/




    class menuMasterDraw {

        public $menus = [];
        public $langid = 0;
        public $menuid = 0;
        public $elements = [];
        public $css_only = 0;
        private $item_align = 0;
        private $location = 0;
        private $customer_id = 0;
        private $loadedstyles = [];
        private $thispage = '';
        private $script_building = 0;
        private $admin = 0;


        public function __construct(){
            GLOBAL $cfgModules;
            if (!empty($cfgModules)){
                $this->admin = 1;
            }
        }

        public function loadJSON() {


            $this->thispage = DIR_WS_CATALOG . basename( $_SERVER['SCRIPT_NAME'] );
            $this->thispage .= empty( $_SERVER['QUERY_STRING'] ) ? '' : '?' . $_SERVER['QUERY_STRING'];

            if ( empty( $this->admin ) ) {
                $cache_file = DIR_FS_CATALOG . 'includes/apps/menu_master/cache/menu_master.cache';
            } else {
                $cache_file = DIR_FS_CATALOG . 'includes/apps/menu_master/cache/temp_menu_master.cache';
            }

            if ( ! empty( $_SESSION['customer_id'] ) ) {
                $this->customer_id = $_SESSION['customer_id'];
            }

            if ( file_exists( $cache_file ) ) {
                $json        = file_get_contents( $cache_file );
                $obj         = json_decode( $json );
                $this->menus = $obj;
            }
        }

        /**
         * @param     $location
         * @param int $all
         * @param int $id
         */
        public function drawMenus( $location, $all = 0, $id = 0 ) {


            $this->location = $location;

            if ( ! empty( $this->menus->locations->$location ) ) {
                foreach ( $this->menus->locations->$location as $menu ) {
                    if ( empty( $all ) && $menu == $id || ! empty( $all ) ) {
                        $menu_settings = $this->menus->menus->$menu;
                        if ( ( $menu_settings->menu_status == 1 || ! empty( $this->admin ) ) && ( $menu_settings->menu_style == 0 || $menu_settings->menu_style == 1 && $location == 2 ) ) {
                            $this->drawOuter( $menu_settings );
                            $this->item_align = 0;
                        }
                    }
                }
            }

        }

        /**
         * @param $item
         * @param $link
         * @param $text
         * @param $source
         *
         * @return array|string|string[]
         */
        private function applyStyles( $item, $link, $text, $source ) {

            $item_html = $source;

            $item_align_class  = '';
            $item_valign_class = '';

                if ( empty( $item->show_on_mobile ) ) {
                    $item_align_class .= ' d-none d-md-block';
                }

                if ( $item->item_align == 'left' ) {
                    $item_align_class .= ' text-left';
                } else if ( $item->item_align == 'right' ) {
                    $item_align_class .= ' text-right';
                } else if ( $item->item_align == 'center' ) {
                    $item_align_class .= ' text-center';
                }

                if ( $item->item_valign == 'top' ) {
                    $item_valign_class .= ' align-top';
                } else if ( $item->item_valign == 'middle' ) {
                    $item_valign_class .= ' align-middle';
                } else if ( $item->item_valign == 'bottom' ) {
                    $item_valign_class .= ' align-bottom';
                }


            $hover_color = '';
            if ( ! empty( $item->link_hover ) ) {
                $item->item_class .= ' mm-hover-link';
                $hover_color      = $item->link_hover;
            }

            $bg_hover_color = '';
            if ( ! empty( $item->bg_hover ) ) {
                if ( ! strpos( $item->item_class, 'mm-hover-link' ) !== false ) {
                    $item->item_class .= ' mm-hover-link';
                }
                $bg_hover_color = $item->bg_hover;
            }

            if ( $this->thispage == $link || HTTP_SERVER . $this->thispage == $link ) {
                $item_align_class .= ' mm-selected';
            }

            if ( $this->menus->menus->{$this->menuid}->menu_style == 0 ) {

                $item_align_class .= ' mm-non-mega ';

            }

            $item_html = str_replace( '--data-color-hover--', $bg_hover_color, $item_html );
            $item_html = str_replace( '--data-color-bg-hover--', $hover_color, $item_html );
            $item_html = str_replace( '--item_align_class--', $item_align_class, $item_html );
            $item_html = str_replace( '--item_valign_class--', $item_valign_class, $item_html );
            $item_html = str_replace( '--item_class--', $item->item_class, $item_html );
            $item_html = str_replace( '--uuid--', $item->uuid, $item_html );
            $item_html = str_replace( '--parentid--', $item->parent_uuid, $item_html );
            $item_html = str_replace( '--link--', $link, $item_html );

            if ( ! empty( $item->item_image ) ) {
                $imagex = DIR_WS_CATALOG . 'includes/apps/menu_master/images/' . $item->item_image;
                $imagex = '<img class="mm-menu-image img-fluid" src="' . $imagex . '" />';
                $text   = $imagex . $text;
            }
            if ( $item->item_icon_show == 2 ) {
                $text = '';
            } else if ( $item->item_icon_show == 1 ) {
                $text = '<span class="mm-text-hide-mobile">' . $text . '</span>';
            }
            $item_html = str_replace( '--text--', $text, $item_html );

            $item_html = str_replace( '--target--', $item->item_target, $item_html );

            $fa_icon     = '';
            $icon_margin = 'mr-2';
            if ( $item->item_icon_show == 1 ) {
                $icon_margin = 'mr-0 mr-sm-2';
            } else if ( $item->item_icon_show == 2 ) {
                $icon_margin = '';
            }

            if ( ! empty( $item->fa_icon ) ) {
                $fa_icon = '<i class="' . $item->fa_icon . ' ' . $icon_margin . '"></i>';
            }
            $item_html = str_replace( '--fa_icon--', $fa_icon, $item_html );

            $style = '';
            if ( ! empty( $item->link_color ) ) {
                $style .= 'color: ' . $item->link_color . ' !important;';
            }
            if ( ! empty( $item->bg_color ) ) {
                $style .= 'background: ' . $item->bg_color . ' !important;';
            }

            return str_replace( '--style--', $style, $item_html );

        }



        /**
         * @param $item
         * @param $link
         * @param $text
         */
        private function drawSingleItem( $item, $link, $text ) {


                $item_html = $this->applyStyles( $item, $link, $text, $this->elements['single_item'] );


            echo $item_html;
        }

        /**
         * @param $item
         * @param $link
         * @param $text
         */
        private function drawSingleSubItem( $item, $link, $text ) {


            $item_html = $this->applyStyles( $item, $link, $text, $this->elements['single_sub_item'] );


            echo $item_html;

        }

        /**
         * @param        $item
         * @param string $parent_id
         * @param string $parent_string
         */
        private function drawItem( $item, $parent_id = '', $parent_string = '' ) {

            $itemid      = $item->menu_item_id;
            $langsetting = $itemid . '-' . $this->langid;
            $text        = '';
            $link        = '';
            $enabled     = 1;

            if ( ! empty( $this->menus->menuitem_lang->$langsetting->item_name ) ) {
                $text = $this->menus->menuitem_lang->$langsetting->item_name;
            }

            if ( ! empty( $item->pages_id ) ) {
                //info_pages
                //TYPE = 1;
                //if empty text - load from page meny based on language
                if ( empty( $text ) ) {
                    $text = $this->menus->info_pages->{$item->pages_id}->{$this->langid}->navbar_title;
                }
                //disable menu item if page is disabled
                if ( empty( $this->menus->info_pages->{$item->pages_id}->{$this->langid}->pages_status ) ) {
                    $enabled = 0;
                }
                $link = DIR_WS_CATALOG . 'info.php?pages_id=' . $item->pages_id;
            } else if ( ! empty( $item->phoenix_pages_id ) ) {
                //Phoenix Pages
                //TYPE = 5;

                $link = $this->menus->phoenix_pages[ $item->phoenix_pages_id ]->url;
                if ( empty( $text ) ) {
                    $text = $this->menus->phoenix_pages[ $item->phoenix_pages_id ]->name;
                }

            } else if ( ! empty( $item->special_items_id ) ) {
                //Special Items
                //TYPE = 6;

            } else {
                //Custom Links
                //TYPE = 4;
                $link = $item->item_url;
            }

            if ( $enabled == 1 && $item->item_status == 1 ) {
                if ( ! empty( $item->menu_has_children ) ) {
                    if ( empty( $parent_id ) ) {
                        echo $this->applyStyles( $item, $link, $text, $this->elements['dropdown_outer_start'] );
                        $parent_id = $item->uuid;
                        foreach ( $this->menus->items->{$this->menuid}->$parent_id as $uuid => $inner_item ) {
                            $this->drawItem( $inner_item, $parent_id, $parent_string . $item->categories_id . '_' );
                        }
                        echo $this->applyStyles( $item, $link, $text, $this->elements['dropdown_outer_end'] );
                    } else {
                        $parent_id = $item->uuid;
                        echo $this->applyStyles( $item, $link, $text, $this->elements['dropdown_inner_start'] );
                        foreach ( $this->menus->items->{$this->menuid}->$parent_id as $uuid => $inner_item ) {
                            $this->drawItem( $inner_item, $parent_id, $parent_string . $item->categories_id . '_' );
                        }
                        echo $this->applyStyles( $item, $link, $text, $this->elements['dropdown_inner_end'] );
                    }
                } else {
                    if ( empty( $parent_id ) ) {
                        $this->drawSingleItem( $item, $link, $text );
                    } else {
                        $this->drawSingleSubItem( $item, $link, $text );
                    }
                }
            }
        }

        /**
         * @param $ms
         *
         * @return array
         */
        private function getStyleValues( $ms ) {

            $styles = [];

            //MENU BAR
            $styles['menu_bar_bg_color']      = ( empty( $ms->menu_bar_bg_color ) ) ? '#e9ecef' : $ms->menu_bar_bg_color;
            $styles['menu_bar_border_color']  = ( empty( $ms->menu_bar_border_color ) ) ? '#f5f5f5' : $ms->menu_bar_border_color;
            $styles['menu_bar_padding']       = ( empty( $ms->menu_bar_padding ) ) ? '2px 2px 2px 2px' : $ms->menu_bar_padding;
            $styles['menu_bar_margin']        = ( empty( $ms->menu_bar_margin ) ) ? '2px 2px 2px 2px' : $ms->menu_bar_margin;
            $styles['menu_bar_border_radius'] = ( empty( $ms->menu_bar_border_radius ) ) ? '0px 0px 0px 0px' : $ms->menu_bar_border_radius;
            $styles['border_radius']          = ( empty( $ms->border_radius ) ) ? '0px 0px 0px 0px' : $ms->border_radius;
            $styles['menu_bar_border_width']  = ( empty( $ms->menu_bar_border_width ) ) ? '1px 1px 1px 1px' : $ms->menu_bar_border_width;
            $styles['menu_bar_border_width']  = explode( ' ', $styles['menu_bar_border_width'] );

            //MAIN
            $styles['hamburger_bg_color'] = ( empty( $ms->hamburger_bg_color ) ) ? '#fff' : $ms->hamburger_bg_color;
            $styles['hamburger_color']    = ( empty( $ms->hamburger_color ) ) ? '#333' : $ms->hamburger_color;
            $styles['bg_color']           = ( empty( $ms->bg_color ) ) ? '#e9ecef' : $ms->bg_color;
            $styles['bg_hover']           = ( empty( $ms->bg_hover ) ) ? '#f5f5f5' : $ms->bg_hover;
            $styles['border_color']       = ( empty( $ms->border_color ) ) ? '#f5f5f5' : $ms->border_color;
            $styles['border_hover']       = ( empty( $ms->border_hover ) ) ? '#e9ecef' : $ms->border_hover;
            $styles['margin']             = ( empty( $ms->margin ) ) ? '2px 2px 2px 2px' : $ms->margin;
            $styles['padding']            = ( empty( $ms->padding ) ) ? '2px 2px 2px 2px' : $ms->padding;
            $styles['link_color']         = ( empty( $ms->bg_color ) ) ? '#007bff' : $ms->link_color;
            $styles['link_hover']         = ( empty( $ms->link_hover ) ) ? '#024995' : $ms->link_hover;
            $styles['border_width']       = ( empty( $ms->border_width ) ) ? '1px 1px 1px 1px' : $ms->border_width;
            $styles['border_width']       = explode( ' ', $styles['border_width'] );

            //SUB ITEMS
            $styles['child_link_color']    = ( empty( $ms->child_link_color ) ) ? '#eeeeee' : $ms->child_link_color;
            $styles['child_link_hover']    = ( empty( $ms->child_link_hover ) ) ? '#dddddd' : $ms->child_link_hover;
            $styles['child_bg_hover']      = ( empty( $ms->child_bg_hover ) ) ? '#666666' : $ms->child_bg_hover;
            $styles['child_bg_color']      = ( empty( $ms->child_bg_color ) ) ? '#333333' : $ms->child_bg_color;
            $styles['child_border_color']  = ( empty( $ms->child_border_color ) ) ? '#222222' : $ms->child_border_color;
            $styles['child_border_hover']  = ( empty( $ms->child_border_hover ) ) ? '#444444' : $ms->child_border_hover;
            $styles['child_border_width']  = ( empty( $ms->child_border_width ) ) ? '1px 1px 1px 1px' : $ms->child_border_width;
            $styles['child_border_width']  = explode( ' ', $styles['child_border_width'] );
            $styles['child_margin']        = ( empty( $ms->child_margin ) ) ? '2px 0px 0px 0px' : $ms->child_margin;
            $styles['child_padding']       = ( empty( $ms->child_padding ) ) ? '2px 2px 2px 2px' : $ms->child_padding;
            $styles['child_border_radius'] = ( empty( $ms->child_border_radius ) ) ? '0px 0px 0px 0px' : $ms->child_border_radius;
            $styles['customcss']           = ( empty( $ms->customcss ) ) ? '' : $ms->customcss;
            $styles['hamburger_code']      = ( empty( $ms->hamburger_code ) ) ? '' : $ms->hamburger_code;
            $styles['menu_icon_open']      = ( empty( $ms->menu_icon_open ) ) ? '' : $ms->menu_icon_open;
            $styles['menu_icon_close']     = ( empty( $ms->menu_icon_close ) ) ? '' : $ms->menu_icon_close;

            return $styles;

        }

        /**
         * @param $ms
         */
        private function drawOuter( $ms ) {

            $this->menuid = $ms->menu_id;
            $this->langid = $_SESSION['languages_id'];

            $styles = $this->getStyleValues( $ms );

            if ( $this->menus->menus->{$this->menuid}->menu_style == 0 ) {
                $this->drawNavbarMenu( $ms, $styles );
            }

        }

        /**
         * @param $script
         */
        private function setScriptFile( $script ) {

            $js_file = DIR_FS_CATALOG . 'includes/apps/menu_master/js/mm-cached-' . $this->menuid . '.js';

            $script = str_replace( '<script>', '', $script );
            $script = str_replace( '</script>', '', $script );
            if ( ! file_exists( $js_file ) ) {
                touch( $js_file );
                $this->script_building = 1;
            }

            if ( ! empty( $this->script_building ) ) {
                file_put_contents( $js_file, $script, FILE_APPEND | LOCK_EX );
            }

        }

        /**
         * @param $style
         */
        private function setStyleFile( $style ) {

            $css_file = DIR_FS_CATALOG . 'includes/apps/menu_master/css/mm-cached-' . $this->menuid . '.css';

            $style = str_replace( '<style>', '', $style );
            $style = str_replace( '</style>', '', $style );
            $style = str_replace( "\f", '\\f', $style );
            if ( ! file_exists( $css_file ) ) {
                touch( $css_file );
                $this->script_building = 1;
            }

            if ( ! empty( $this->script_building ) ) {
                file_put_contents( $css_file, $style, FILE_APPEND | LOCK_EX );
            }

        }


        /**
         * @param $styles
         *
         * @return string
         */
        private function getNavbarStyle( $styles ) {

            $margin_left          = explode( ' ', $styles['margin'] )[3];
            $child_padding_bottom = explode( ' ', $styles['child_padding'] )[2];

            $sub_menu_caret_adjust = 5;
            $sub_menu_caret_adjust -= (int) str_replace( 'px', '', explode( ' ', $styles['child_padding'] )[1] );
            $sub_menu_caret_adjust .= 'px';



            $font_family_main = '';
            if ( ! empty( $this->menus->menus->{$this->menuid}->menu_font ) ) {
                $font_family_main = 'font-family: ' . $this->menus->menus->{$this->menuid}->menu_font . ';';
            }
            $font_size_main = '';
            if ( ! empty( $this->menus->menus->{$this->menuid}->menu_font_size ) ) {
                $font_size_main = 'font-size: ' . $this->menus->menus->{$this->menuid}->menu_font_size . ';';
            }

            $font_family_child = '';
            if ( ! empty( $this->menus->menus->{$this->menuid}->child_menu_font ) ) {
                $font_family_child = 'font-family: ' . $this->menus->menus->{$this->menuid}->child_menu_font . ';' . PHP_EOL;
            }
            $font_size_child = '';
            if ( ! empty( $this->menus->menus->{$this->menuid}->child_font_size ) ) {
                $font_size_child = 'font-size: ' . $this->menus->menus->{$this->menuid}->child_font_size . ';' . PHP_EOL;
            }

            $style = <<<STYLE
<style>
    /*Resets*/
    .mm-menu-style-id-$this->menuid .nav-link {
        padding: 0px;
        display: inline;
    }

    .mm-menu-style-id-$this->menuid .dropdown-item,
    .mm-menu-style-id-$this->menuid .dropdown-menu,
    .mm-menu-style-id-$this->menuid .navbar-expand-md .navbar-nav .nav-link,
    .mm-menu-style-id-$this->menuid .navbar-expand-sm .navbar-nav .nav-link {
        padding: unset;
        padding-right: unset;
        padding-left: unset;
        margin: unset;
        border: unset;
        background-color: unset;
        border-radius: unset;
    }

    .mm-menu-style-id-$this->menuid .mm-menu-image {
        max-width: 24px;
        margin-right: $margin_left;
    }

    .mm-menu-style-id-$this->menuid .navbar-nav {
        flex-wrap: wrap;
    }

    .mm-menu-style-id-$this->menuid {
        height: max-content;
        background: {$styles['menu_bar_bg_color']} !important;
        border-top: {$styles['menu_bar_border_width'][0]} !important;
        border-right: {$styles['menu_bar_border_width'][1]} !important;
        border-bottom: {$styles['menu_bar_border_width'][2]} !important;
        border-left: {$styles['menu_bar_border_width'][3]} !important;
        border-radius: {$styles['menu_bar_border_radius']} !important;
        padding: {$styles['menu_bar_padding']} !important;
        margin: {$styles['menu_bar_margin']} !important;
        border-color: {$styles['menu_bar_border_color']} !important;
        border-style: solid !important;
        $font_family_main
        $font_size_main
    }

    /*Main Menu Bar Links*/
    .mm-menu-style-id-$this->menuid .mm-item-main {
        background: {$styles['bg_color']} !important;
        border-top: {$styles['border_width'][0]} !important;
        border-right: {$styles['border_width'][1]} !important;
        border-bottom: {$styles['border_width'][2]} !important;
        border-left: {$styles['border_width'][3]} !important;
        border-radius: {$styles['border_radius']} !important;
        border-style: solid !important;
        padding: {$styles['padding']} !important;
        margin: {$styles['margin']} !important;
        border-color: {$styles['border_color']} !important;
    }

    .mm-menu-style-id-$this->menuid .mm-item-main:hover {
        border-color: {$styles['border_hover']} !important;
        background: {$styles['bg_hover']} !important;
    }

    .mm-menu-style-id-$this->menuid .mm-selected {
        border-color: {$styles['border_hover']} !important;
        background: {$styles['bg_hover']} !important;
    }

    /*Search Box*/
    .mm-menu-style-id-$this->menuid .mm-search-group {
        padding: {$styles['padding']} !important;
    }

    .mm-menu-style-id-$this->menuid .mm-search {
        color: {$styles['link_color']} !important;
    }

    .mm-menu-style-id-$this->menuid .btn-mm-search {
        background: {$styles['link_color']};
        color: {$styles['bg_color']};
    }

    /*Main Menu Links*/
    .mm-menu-style-id-$this->menuid .mm-item-main-link {
        color: {$styles['link_color']} !important;
    }

    .mm-menu-style-id-$this->menuid .mm-item-main-link:hover {
        color: {$styles['link_hover']} !important;
    }

    .mm-menu-style-id-$this->menuid .mm-selected > a {
        color: {$styles['link_hover']} !important;
    }

    /*Sub Menu Links*/
    .mm-menu-style-id-$this->menuid .mm-item-link {
        color: {$styles['child_link_color']} !important;
        display: block !important;
        width: 100%;
        padding: {$styles['child_padding']} !important;
        $font_family_child
        $font_size_child
    }

    .mm-menu-style-id-$this->menuid .mm-item-link:hover {
        color: {$styles['child_link_hover']} !important;
    }

    .mm-menu-style-id-$this->menuid .mm-item {
        background: {$styles['child_bg_color']} !important;
        border-top: {$styles['child_border_width'][0]} !important;
        border-right: {$styles['child_border_width'][1]} !important;
        border-bottom: {$styles['child_border_width'][2]} !important;
        border-left: {$styles['child_border_width'][3]} !important;
        border-style: solid !important;
        margin: {$styles['child_margin']} !important;
        border-color: {$styles['child_border_color']} !important;
        display: block;
    }

    .mm-menu-style-id-$this->menuid .mm-item:hover {
        background: {$styles['child_bg_hover']} !important;
        border-color: {$styles['child_border_hover']} !important;
    }

    .mm-menu-style-id-$this->menuid .mm-item:hover > a {
        color: {$styles['child_link_hover']} !important;
    }

    .mm-menu-style-id-$this->menuid .mm-dropdown:hover, .mm-menu-style-id-$this->menuid .mm-submenu-dropdown:hover {
        background: {$styles['child_border_hover']} !important;
    }

    .mm-menu-style-id-$this->menuid .navbar-toggler-icon, .mm-menu-style-id-$this->menuid .navbar-toggler-icon i {
        color: {$styles['hamburger_color']} !important;
        font-size: 1.3em;
    }

    /*Dropdown containers*/
    .mm-menu-style-id-$this->menuid .mm-dropdown, .mm-menu-style-id-$this->menuid .mm-submenu-dropdown {
        background: {$styles['child_border_color']} !important;
        border-radius: {$styles['child_border_radius']} !important;
    }

    .mm-menu-style-id-$this->menuid .mm-dropdown li, .mm-menu-style-id-$this->menuid .mm-submenu-dropdown li {
        border-radius: {$styles['child_border_radius']} !important;
    }

    /******** Special Items ************/

    /*Divider*/
    .mm-menu-style-id-$this->menuid .dropdown-divider {
        background: {$styles['child_border_hover']} !important;
        margin: 2px 0px;
        height: 1px;
    }

    /*Header*/
    .mm-menu-style-id-$this->menuid h5 {
        color: {$styles['child_link_color']} !important;
        text-align: left;
        font-size: 1.2em;
        margin: 10px 4px 0px;
    }
</style>
STYLE;

            $style .= <<<STYLE
<style>
    /*Alter Behaviours*/
    .mm-menu-style-id-$this->menuid .dropdown-submenu {
        position: relative;
        width: max-content !important;
        min-width: 100%;
    }
    .mm-menu-style-id-$this->menuid > div > ul > li > ul {
          min-width: 100%;
        width: max-content;
    }

    .mm-menu-style-id-$this->menuid .mm-right-menu > ul > li > ul > .dropdown-submenu {
        min-width: 100%;
    }

    .mm-menu-style-id-$this->menuid .mm-left-menu > ul > li > ul > .dropdown-submenu {
        min-width: 100%;
    }

    .mm-menu-style-id-$this->menuid .dropdown-submenu > a {
        break-inside: avoid;
        padding: 0px;
        margin: 0px;
    }

    /*Add caret to right of foldouts*/
    .mm-menu-style-id-$this->menuid .dropdown-submenu > a::after {
        content: "\f105";
        float: right;
        font-family: "Font Awesome 5 Free";
        -moz-osx-font-smoothing: grayscale;
        -webkit-font-smoothing: antialiased;
        display: inline-block;
        font-variant: normal;
        text-rendering: auto;
        line-height: 1;
        font-style: normal;
        font-weight: normal;
        font-size: 1em;
        font-weight: 900;
        position: relative;
        right: $sub_menu_caret_adjust;
        top: 5px;
    }

    .mm-menu-style-id-$this->menuid.navbar .mm-item-main > .dropdown-menu {
        top: 120% !important;
    }

    .mm-menu-style-id-$this->menuid .dropdown-submenu > .dropdown-menu {
        top: 0px;
        left: 102%;
        margin-top: 0px;
        margin-left: 0px;
    }

    .mm-menu-style-id-$this->menuid .mm-right-menu, .mm-menu-style-id-$this->menuid .mm-left-menu {
        width: 100%;
    }

    .mm-menu-style-id-$this->menuid .mm-right-menu .nav-item, .mm-menu-style-id-$this->menuid .mm-left-menu .nav-item {
        width: 100%;
    }


    .mm-menu-style-id-$this->menuid .mm-right-menu .dropdown-submenu .dropdown-menu {
        left: -110%;
        margin-top: 0px;
        margin-left: 0px;
    }

    .mm-menu-style-id-$this->menuid > div > ul > li.dropleft .dropdown-menu {
        right: 101%;
    }

    /*Right aligned items*/
    .mm-menu-style-id-$this->menuid > div > .ml-auto .dropdown-submenu .dropdown-menu {
        left: -105%;
        top: -3px;
        margin-top: 0px;
        margin-left: 0px;
    }

    .mm-menu-style-id-$this->menuid > div > .ml-auto > li > ul {
        right: 0px;
        left: unset;
    }

    /*Left Menu*/
    .mm-menu-style-id-$this->menuid .mm-left-menu > ul > li > a.dropdown-toggle::after {
        content: "\f105";
        float: right;
        font-family: "Font Awesome 5 Free";
        -moz-osx-font-smoothing: grayscale;
        -webkit-font-smoothing: antialiased;
        display: inline-block;
        font-variant: normal;
        text-rendering: auto;
        line-height: 1;
        font-style: normal;
        font-weight: normal;
        font-size: 1em;
        font-weight: 900;
        position: relative;
        border: none !important;
        top: 5px;
        /*right: -2px;*/
        
    }

    .mm-menu-style-id-$this->menuid > div > ul > li.dropright > .dropdown-menu {
        left: 101%;
    }

    .mm-menu-style-id-$this->menuid > div > ul > li.dropright a:after {
        margin-right: 10px;
    }

    /*Right Menu Bar*/
    .mm-navbar-loc-3 a:before {
        margin-left: 2px;
    }

    .mm-navbar-loc-3 a {
        margin-left: 2px;
    }

    .mm-navbar-loc-3 > div > ul > .dropleft > a:before {
        margin-left: 10px;
    }

    .mm-navbar-loc-3 > div > ul > .mm-item-main > a {
        margin-left: 10px;
    }

    .mm-navbar-loc-9 {
        position: absolute;
        bottom: 0px;
    }

    .mm-menu-style-id-$this->menuid .mm-left-menu .dropdown-submenu > a::after {
        /*right: -2px;*/
    }

    /*Right Menu*/
    .mm-menu-style-id-$this->menuid .mm-right-menu .dropdown-submenu > a::after,
    .mm-menu-style-id-$this->menuid > div .ml-auto .dropdown-submenu > a::after {
        content: "";
    }

    .mm-menu-style-id-$this->menuid > div > .ml-auto .dropdown-submenu > a::before,
    .mm-menu-style-id-$this->menuid .mm-right-menu > ul > li > a.dropdown-toggle::before,
    .mm-menu-style-id-$this->menuid .mm-right-menu .dropdown-submenu > a::before {
        content: "\f104";
        border: none !important;
        float: left;
        font-family: "Font Awesome 5 Free";
        -moz-osx-font-smoothing: grayscale;
        -webkit-font-smoothing: antialiased;
        display: inline-block;
        font-variant: normal;
        text-rendering: auto;
        line-height: 1;
        font-style: normal;
        font-weight: normal;
        font-size: 1em;
        font-weight: 900;
        position: relative;
        border: none !important;
        top: 5px;
        /*left: -2px;*/
    }

    .mm-menu-style-id-$this->menuid > div > .ml-auto .dropdown-submenu > a::before,
    .mm-menu-style-id-$this->menuid .mm-right-menu .dropdown-submenu > a::before {
        /*left: -2px;*/
    }

    .mm-menu-style-id-$this->menuid .mm-right-menu a {
        white-space: pre-wrap;
    }

    .mm-menu-style-id-$this->menuid .mm-left-menu a {
        white-space: pre-wrap;
    }

    div.mm-menu-style-id-$this->menuid > div.mm-left-menu .dropdown-submenu .dropdown-menu {
        right: 105%;
    }

    div.mm-menu-style-id-$this->menuid > div.mm-right-menu .dropdown-submenu .dropdown-menu {
        left: -105%;
    }

    /*hamburger colors*/
    .mm-menu-style-id-$this->menuid .navbar-toggler {
        background: {$styles['hamburger_bg_color']} !important;
    }

    .mm-menu-style-id-$this->menuid .navbar-toggler i {
        color: {$styles['hamburger_color']} !important;
    }

    /*Footer Menus*/
    .mm-menu-style-id-$this->menuid.mm-footer-navs > div > ul > li.dropdown > a::after {
        border-top: 0em solid;
        border-right: 0.3em solid transparent;
        border-bottom: 0.3em solid;
    }

    .mm-menu-style-id-$this->menuid.mm-footer-navs > div > ul > li.dropdown > ul.dropdown-menu {
        top: unset !important;
        bottom: 100% !important;
    }

    /* Make sure center align menu items wrap centered */
    .mm-menu-style-id-$this->menuid .navbar-nav.mx-auto > li {
        margin: auto !important;
    }

    /* Make sure right align menu items wrap right */
    .mm-menu-style-id-$this->menuid .navbar-nav.ml-auto > li {
        margin-left: auto !important;
        margin-right: unset !important;
    }
</style>
STYLE;

            $style .= <<<STYLE
<style>
    /* MEGA MENUS - requires upgrade */

    @media screen and (max-width: 768px) {
        /*Hide right arrow on mobile foldouts*/
        .mm-menu-style-id-$this->menuid .dropdown-submenu > a::after {
            display: inline-block;
            margin-left: .255em;
            vertical-align: .255em;
            content: "";
            border-top: .3em solid;
            border-right: .3em solid transparent;
            border-bottom: 0;
            right: 1em;
            border-left: .3em solid transparent;
        }
        .mm-mobilemenu-hide {
            display: none !important;
        }
    }

    @media screen and (max-width: 576px) {
        .mm-text-hide-mobile {
            display: none;
        }
    }

    {$styles['customcss']}
</style>
STYLE;

            return $style;

        }

        /**
         * @param $styles
         */
        private function drawCss( $styles ) {


            $id     = '';
            $script = '';

            if ( $this->menus->menus->{$this->menuid}->menu_style == 0 ) {
                $id = 'mm-navbar-' . $this->menuid . '-' . $this->location;
            }
            if ( empty( $this->loadedstyles[ $this->menuid ] ) ) {
                if ( $this->menus->menus->{$this->menuid}->menu_style == 0 ) {

                    $style = $this->getNavbarStyle( $styles );

                    $script .= <<<SCRIPT
<script>
    var mm_menu_clicked = '';
    $(function () {
        //fix mega menu assignments
        
        $('.mm-menu-style-id-$this->menuid .dropdown.mm-non-mega, .mm-menu-style-id-$this->menuid .dropdown-submenu.mm-non-mega, .mm-menu-style-id-$this->menuid .dropright, .mm-menu-style-id-$this->menuid .dropleft').hover(
            function () {
                $(this).children('.dropdown-menu:first').stop(true, true).delay(200).fadeIn();
            }, function () {
                $(this).find('.dropdown-menu:first').stop(true, true).delay(400).fadeOut();
            });

        $('.mm-menu-style-id-$this->menuid .dropdown a, .mm-menu-style-id-$this->menuid .dropright a, .mm-menu-style-id-$this->menuid .dropleft a').not(".mm-mega").click(
            function (e) {
                var toggled = $(".mm-menu-style-id-$this->menuid .navbar-toggler").css("display");
                url = $(this).attr('href');
                //for mobible - stop click dropdowns             
                if (toggled == 'none' || (url == mm_menu_clicked && mm_menu_clicked != '')){
                    $(this).parent().find('ul:first').css('display', 'none');
                    if (url != '#' || url != ''){
                        console.log('going1:'+url);
                        console.log('going2:'+mm_menu_clicked);
                        mm_menu_clicked = '';
                        window.location.href = url;
                    } else {
                        e.preventDefault();
                    }
                } else if (mm_menu_clicked == ''){
                    mm_menu_clicked = 'wait-until-next-click';
                } else{
                    console.log('no1:'+url);
                    console.log('no2:'+mm_menu_clicked);
                    e.preventDefault();
                    mm_menu_clicked = url;
                }
        });
    });
</script>
SCRIPT;

                    $this->setScriptFile( $script );
                    $this->setStyleFile( $style );

                    $style = str_replace( "\f", '\\f', $style );

                    if (isset($GLOBALS['oscTemplate'])) {

                        $script = '<script src="' . HTTP_SERVER . DIR_WS_CATALOG . 'includes/apps/menu_master/js/mm-cached-' . $this->menuid . '.js"></script>' . PHP_EOL;

                            $blocks = $GLOBALS['oscTemplate']->getBlocks( 'footer_scripts' );
                            if ( strpos( $blocks, $script ) === false ) {
                                $GLOBALS['oscTemplate']->addBlock( $script, 'footer_scripts' );
                            }

                    } else {
                        //ADMIN SITE PREVIEW
                        echo $script;
                        echo $style;
                    }

                }
            }
            $this->loadedstyles[ $this->menuid ] = 1;
        }

        /**
         * @param $ms
         * @param $styles
         */
        private function drawNavbarMenu( $ms, $styles ) {

            $vert_horiz_drop_class = 'dropdown';
            if ( $this->location == 2 ) {
                $vert_horiz_drop_class = 'dropright';
            } else if ( $this->location == 3 ) {
                $vert_horiz_drop_class = 'dropleft';
            }

            //ELEMENTS - SINGLE ITEM
            $this->elements['single_item'] = '<li class="nav-item mm-item-main --item_align_class--">' . PHP_EOL;
            $this->elements['single_item'] .= '<a data-color-hover="--data-color-hover--" data-color-bg-hover="--data-color-bg-hover--" data-color-hover-backup="' . $styles['link_color'] . '" data-color-bg-hover-backup="' . $styles['bg_hover'] . '" class="nav-link mm-item-main-link --item_class-- --item_valign_class--" href="--link--" target="--target--" style="--style--">--fa_icon----text--</a>' . PHP_EOL;
            $this->elements['single_item'] .= '</li>' . PHP_EOL;

            //ELEMENTS - SINGLE SUBMENU ITEM
            $this->elements['single_sub_item'] = PHP_EOL . '<li class="nav-item mm-item --item_class-- --item_align_class-- --item_valign_class--">' . PHP_EOL;
            $this->elements['single_sub_item'] .= '<a data-color-hover="--data-color-hover--" data-color-bg-hover="--data-color-bg-hover--" data-color-hover-backup="' . $styles['child_link_color'] . '" data-color-bg-hover-backup="' . $styles['child_bg_hover'] . '" class="dropdown-item mm-item-link" href="--link--" target="--target--" style="--style--">--fa_icon----text--</a>' . PHP_EOL;
            $this->elements['single_sub_item'] .= '</li>';

            //ELEMENTS - MAIN DROPDOWN ITEM START
            $this->elements['dropdown_outer_start'] = '<li class="nav-item ' . $vert_horiz_drop_class . ' mm-item-main --item_class-- --item_align_class--">' . PHP_EOL;
            $this->elements['dropdown_outer_start'] .= '<a data-color-hover="--data-color-hover--" data-color-bg-hover="--data-color-bg-hover--" data-color-hover-backup="' . $styles['child_link_color'] . '" data-color-bg-hover-backup="' . $styles['child_bg_hover'] . '" class="nav-link dropdown-toggle  mm-item-main-link --item_valign_class--" id="mm--uuid--" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="--link--" target="--target--" style="--style--">--fa_icon----text--</a>' . PHP_EOL;
            $this->elements['dropdown_outer_start'] .= '<ul class="dropdown-menu mm-dropdown" aria-labelledby="mm--uuid--">' . PHP_EOL;

            //ELEMENTS - MAIN DROPDOWN ITEM END
            $this->elements['dropdown_outer_end'] = '</ul>' . PHP_EOL;
            $this->elements['dropdown_outer_end'] .= '</li>' . PHP_EOL;

            //ELEMENTS - SUBMENU DROPDOWN ITEM START
            $this->elements['dropdown_inner_start'] = PHP_EOL . '<li class="nav-item dropdown-submenu mm-item --item_class-- --item_align_class--">' . PHP_EOL;
            $this->elements['dropdown_inner_start'] .= '<a data-color-hover="--data-color-hover--" data-color-bg-hover="--data-color-bg-hover--" data-color-hover-backup="' . $styles['child_link_color'] . '" data-color-bg-hover-backup="' . $styles['child_bg_hover'] . '" class="nav-link mm-item-link --item_valign_class--" id="mm--uuid--"  aria-haspopup="true" aria-expanded="false" href="--link--" target="--target--" style="--style--">--fa_icon----text--</a>' . PHP_EOL;
            $this->elements['dropdown_inner_start'] .= '<ul class="dropdown-menu mm-submenu-dropdown" aria-labelledby="mm--uuid--">' . PHP_EOL;

            //ELEMENTS - SUBMENU DROPDOWN ITEM END
            $this->elements['dropdown_inner_end'] = '</ul>' . PHP_EOL;
            $this->elements['dropdown_inner_end'] .= '</li>' . PHP_EOL;

            $this->elements['divider'] = '<li class="--item_class-- --item_align_class--"><hr class="dropdown-divider"></li>' . PHP_EOL;
            $this->elements['heading'] = '<li class="--item_class-- --item_align_class--"><h5>--fa_icon----text--</h5></li>' . PHP_EOL;

            $this->setSearch();

            $this->elements['alignment'] = '' . PHP_EOL;

            $this->drawCss( $styles );

            $label = ( empty( $this->menus->menu_lang->{$this->menuid} ) ) ? '' : $this->menus->menu_lang->{$this->menuid}->{$this->langid}->label_text;

            $align_class = 'mr-auto';
            if ( $this->location != 2 && $this->location != 3 ) {
                //ignore on left/right menus
                if ( $this->menus->menus->{$this->menuid}->menu_align == 'center' ) {
                    $align_class = 'mx-auto';
                } else if ( $this->menus->menus->{$this->menuid}->menu_align == 'right' ) {
                    $align_class = 'ml-auto';
                }
            }
            $navfill_class = empty( $this->menus->menus->{$this->menuid}->menu_fill ) ? '' : 'w-100 nav-justified';

            $hide_menubar_mobile = empty( $ms->show_on_mobile ) ? 'mm-mobilemenu-hide' : '';

            $vert_horiz_outer_div_class = 'collapse navbar-collapse';
            if ( empty( $ms->hamburger_breakpoint ) ) {
                //show menu if breakpoint is never show mobile menu
                $vert_horiz_outer_div_class = 'navbar-collapse';
            }
            if ( $this->location == 2 ) {
                $vert_horiz_outer_div_class = 'mm-left-menu';
            } else if ( $this->location == 3 ) {
                $vert_horiz_outer_div_class = 'mm-right-menu';
            }

            $vert_horiz_ul_class  = ( $this->location == 2 || $this->location == 3 ) ? 'nav flex-column' : 'navbar-nav';
            $vert_horiz_nav_class = ( $this->location == 2 || $this->location == 3 ) ? '' : 'navbar';

            $hamburger_breakpoint = 'navbar-expand';
            if ( ! empty( $ms->hamburger_breakpoint ) ) {
                $hamburger_breakpoint = 'navbar-expand-' . $ms->hamburger_breakpoint;
            }
            $vert_horiz_nav_class .= ' ' . $hamburger_breakpoint;

            $hamburger_placement = 'mr-auto';
            if ( $ms->hamburger_placement == 'center' ) {
                $hamburger_placement = 'mx-auto';
            } else if ( $ms->hamburger_placement == 'right' ) {
                $hamburger_placement = 'ml-auto';
            }

            if ( $this->location == 7 || $this->location == 8 || $this->location == 9 ) {
                //bottom navbars
                $ms->menu_class .= ' mm-footer-navs';
            }

            if ( empty( $this->admin ) && $this->location == 1 ) {
                echo '<li class="nav-item nb-mm-menu-outer-' . $this->menuid . '-' . $this->location . '">';
            }
            ?>

            <nav id="mm-navbar-<?= $this->menuid . '-' . $this->location ?>" class="mm-navbar-loc-<?= $this->location ?> <?= $vert_horiz_nav_class ?> mm-menu-style-id-<?= $this->menuid ?> <?= $ms->menu_class ?> <?= $hide_menubar_mobile ?>">
                <?php
                    if ( ! empty( $label ) ) {
                        ?>
                        <a class="navbar-brand mx-2" href="#"><?= $label ?></a>
                        <?php
                        //removed above
                    }

                    $ms->hamburger_code = str_replace( '&quot;', '"', $ms->hamburger_code );

                    if ( $ms->show_on_mobile == 1 && $this->location != 2 && $this->location != 3 ) {
                        ?>
                        <button class="navbar-toggler <?= $hamburger_placement ?>" type="button" data-toggle="collapse" data-target="#mm-navbar-drop-<?= $this->menuid . '-' . $this->location ?>" aria-controls="mm-navbar-<?= $this->menuid . '-' . $this->location ?>" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon w-auto"><?= $ms->hamburger_code ?></span>
                        </button>
                        <?php
                    }
                ?>
                <div class="<?= $vert_horiz_outer_div_class ?>" id="mm-navbar-drop-<?= $this->menuid . '-' . $this->location ?>">
                    <ul class="<?= $vert_horiz_ul_class ?> <?= $navfill_class ?> <?= $align_class ?>">
                        <?php

                            if ( ! empty( $this->menus->items->{$this->menuid} ) ) {

                                foreach ( $this->menus->items->{$this->menuid}->{''} as $uuid => $item ) {
                                    $this->drawItem( $item );
                                }
                            } else {
                                if ( ! empty( $this->admin ) ) {
                                    echo MM_MENU_EMPTY_DATA;
                                }
                            }
                        ?>
                    </ul>
                </div>
            </nav>
            <?php

            if ( empty( $this->admin ) && $this->location == 1 ) {
                echo '</li>';
            }

        }


        private function setSearch() {

            $this->elements['search'] = '';

        }

    }